import React, { useState } from "react";
import AppLayout from "@/layout/app-layout";
import Header from "@/components/layout/header";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle,
  CardDescription 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";
import { Skeleton } from "@/components/ui/skeleton";
import { DataTable } from "@/components/ui/data-table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { 
  LineChart, 
  Line, 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer 
} from 'recharts';
import { Download, Filter } from "lucide-react";
import { formatDateShort } from "@/lib/dates";
import { getLegendColors } from "@/lib/charts";

interface Event {
  id: number;
  name: string;
  userId: string;
  properties: any;
  timestamp: string;
}

export default function Events() {
  const [eventType, setEventType] = useState<string>("all");
  const [chartView, setChartView] = useState<string>("volume");
  
  const { data: events, isLoading: isEventsLoading } = useQuery<Event[]>({
    queryKey: ['/api/events', eventType],
  });

  const { data: eventStats, isLoading: isStatsLoading } = useQuery({
    queryKey: ['/api/events/stats', eventType],
  });

  const columns = [
    {
      accessorKey: "name",
      header: "Event",
      cell: ({ row }: any) => <div className="font-medium">{row.getValue("name")}</div>,
    },
    {
      accessorKey: "userId",
      header: "User ID",
    },
    {
      accessorKey: "properties",
      header: "Properties",
      cell: ({ row }: any) => {
        const properties = row.getValue("properties");
        if (!properties) return null;
        
        return (
          <div className="max-w-[300px] truncate">
            {Object.entries(properties).map(([key, value]: [string, any]) => (
              <span key={key} className="inline-block bg-gray-100 text-gray-800 text-xs px-2 py-1 rounded mr-1 mb-1">
                {key}: {typeof value === 'object' ? JSON.stringify(value) : value.toString()}
              </span>
            )).slice(0, 3)}
            {Object.keys(properties).length > 3 && (
              <span className="text-xs text-gray-500">+{Object.keys(properties).length - 3} more</span>
            )}
          </div>
        );
      },
    },
    {
      accessorKey: "timestamp",
      header: "Timestamp",
      cell: ({ row }: any) => <div>{formatDateShort(row.getValue("timestamp"))}</div>,
    },
  ];

  // Generate mock chart data
  const generateChartData = () => {
    const dates = Array.from({ length: 14 }, (_, i) => {
      const date = new Date();
      date.setDate(date.getDate() - 13 + i);
      return formatDateShort(date);
    });
    
    return dates.map(date => ({
      date,
      'app_open': Math.floor(Math.random() * 5000) + 1000,
      'product_view': Math.floor(Math.random() * 3000) + 500,
      'add_to_cart': Math.floor(Math.random() * 1000) + 200,
      'checkout': Math.floor(Math.random() * 500) + 100,
      'purchase': Math.floor(Math.random() * 300) + 50,
    }));
  };

  const chartData = generateChartData();

  return (
    <AppLayout>
      <Header 
        title="Event Analysis" 
        description="Track and analyze user events in your application"
      />

      <div className="py-6 px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 gap-6">
          <Card>
            <CardHeader>
              <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center space-y-2 sm:space-y-0">
                <div>
                  <CardTitle>Event Trends</CardTitle>
                  <CardDescription>
                    Volume of key events over time
                  </CardDescription>
                </div>
                <div className="flex flex-wrap gap-2">
                  <Tabs value={chartView} onValueChange={setChartView}>
                    <TabsList>
                      <TabsTrigger value="volume">Volume</TabsTrigger>
                      <TabsTrigger value="comparison">Comparison</TabsTrigger>
                    </TabsList>
                  </Tabs>
                  
                  <Button variant="outline" size="sm">
                    <Download className="h-4 w-4 mr-2" />
                    Export
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {isStatsLoading ? (
                <Skeleton className="h-[400px] w-full" />
              ) : (
                <div className="h-[400px]">
                  {chartView === 'volume' ? (
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart
                        data={chartData}
                        margin={{
                          top: 20,
                          right: 30,
                          left: 20,
                          bottom: 20,
                        }}
                      >
                        <CartesianGrid strokeDasharray="3 3" vertical={false} opacity={0.2} />
                        <XAxis 
                          dataKey="date" 
                          tick={{ fontSize: 12 }}
                          tickLine={false}
                          axisLine={{ stroke: '#e2e8f0' }}
                        />
                        <YAxis 
                          tickFormatter={(value) => value >= 1000 ? `${(value / 1000).toFixed(0)}k` : value}
                          tick={{ fontSize: 12 }}
                          tickLine={false}
                          axisLine={{ stroke: '#e2e8f0' }}
                        />
                        <Tooltip 
                          formatter={(value: number) => [value.toLocaleString(), '']}
                          labelFormatter={(label) => `Date: ${label}`}
                        />
                        <Legend />
                        <Line 
                          type="monotone" 
                          dataKey="app_open" 
                          name="App Open" 
                          stroke={getLegendColors()[0]} 
                          strokeWidth={2}
                          dot={false}
                          activeDot={{ r: 6 }}
                        />
                        <Line 
                          type="monotone" 
                          dataKey="product_view" 
                          name="Product View" 
                          stroke={getLegendColors()[1]} 
                          strokeWidth={2}
                          dot={false}
                          activeDot={{ r: 6 }}
                        />
                        <Line 
                          type="monotone" 
                          dataKey="add_to_cart" 
                          name="Add to Cart" 
                          stroke="hsl(160, 70%, 50%)" 
                          strokeWidth={2}
                          dot={false}
                          activeDot={{ r: 6 }}
                        />
                        <Line 
                          type="monotone" 
                          dataKey="purchase" 
                          name="Purchase" 
                          stroke="hsl(20, 70%, 50%)" 
                          strokeWidth={2}
                          dot={false}
                          activeDot={{ r: 6 }}
                        />
                      </LineChart>
                    </ResponsiveContainer>
                  ) : (
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart
                        data={chartData.slice(-7)}
                        margin={{
                          top: 20,
                          right: 30,
                          left: 20,
                          bottom: 20,
                        }}
                      >
                        <CartesianGrid strokeDasharray="3 3" vertical={false} opacity={0.2} />
                        <XAxis 
                          dataKey="date" 
                          tick={{ fontSize: 12 }}
                          tickLine={false}
                          axisLine={{ stroke: '#e2e8f0' }}
                        />
                        <YAxis 
                          tickFormatter={(value) => value >= 1000 ? `${(value / 1000).toFixed(0)}k` : value}
                          tick={{ fontSize: 12 }}
                          tickLine={false}
                          axisLine={{ stroke: '#e2e8f0' }}
                        />
                        <Tooltip 
                          formatter={(value: number) => [value.toLocaleString(), '']}
                          labelFormatter={(label) => `Date: ${label}`}
                        />
                        <Legend />
                        <Bar 
                          dataKey="app_open" 
                          name="App Open" 
                          fill={getLegendColors()[0]} 
                          radius={[4, 4, 0, 0]} 
                          barSize={16}
                        />
                        <Bar 
                          dataKey="product_view" 
                          name="Product View" 
                          fill={getLegendColors()[1]} 
                          radius={[4, 4, 0, 0]} 
                          barSize={16}
                        />
                        <Bar 
                          dataKey="add_to_cart" 
                          name="Add to Cart" 
                          fill="hsl(160, 70%, 50%)" 
                          radius={[4, 4, 0, 0]} 
                          barSize={16}
                        />
                        <Bar 
                          dataKey="purchase" 
                          name="Purchase" 
                          fill="hsl(20, 70%, 50%)" 
                          radius={[4, 4, 0, 0]} 
                          barSize={16}
                        />
                      </BarChart>
                    </ResponsiveContainer>
                  )}
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center space-y-2 sm:space-y-0">
                <div>
                  <CardTitle>Event Explorer</CardTitle>
                  <CardDescription>
                    Search and filter individual event records
                  </CardDescription>
                </div>
                <div className="flex items-center gap-2">
                  <Select
                    value={eventType}
                    onValueChange={setEventType}
                  >
                    <SelectTrigger className="w-[180px]">
                      <SelectValue placeholder="Select event type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Events</SelectItem>
                      <SelectItem value="app_open">App Open</SelectItem>
                      <SelectItem value="product_view">Product View</SelectItem>
                      <SelectItem value="add_to_cart">Add to Cart</SelectItem>
                      <SelectItem value="checkout">Checkout</SelectItem>
                      <SelectItem value="purchase">Purchase</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {isEventsLoading ? (
                <div className="space-y-4">
                  <Skeleton className="h-10 w-full" />
                  <Skeleton className="h-32 w-full" />
                  <Skeleton className="h-10 w-full" />
                </div>
              ) : (
                <DataTable 
                  columns={columns}
                  data={events || []}
                  searchColumn="name"
                  searchPlaceholder="Search events..."
                />
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </AppLayout>
  );
}
