import React from "react";
import AppLayout from "@/layout/app-layout";
import Header from "@/components/layout/header";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle,
  CardDescription,
  CardFooter
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";
import { Skeleton } from "@/components/ui/skeleton";
import { DataTable } from "@/components/ui/data-table";
import { Link } from "wouter";
import { 
  Bell, 
  ArrowUpRight, 
  Clock, 
  BarChart, 
  PieChart, 
  LineChart,
  Settings, 
  Smartphone,
  Users
} from "lucide-react";
import { formatDateShort } from "@/lib/dates";
import { formatNumber, formatPercentage } from "@/lib/utils";
import {
  LineChart as ReChartsLineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  PieChart as ReChartsPieChart,
  Pie,
  Cell
} from 'recharts';

export default function PushNotifications() {
  // Sample data for the charts
  const deliveryStats = [
    { name: 'Delivered', value: 85 },
    { name: 'Failed', value: 15 }
  ];
  
  const engagementStats = [
    { name: 'Opened', value: 42 },
    { name: 'Not Opened', value: 58 }
  ];
  
  const performanceData = [
    { date: 'Jan 1', sent: 1500, delivered: 1425, opened: 685, clicked: 320 },
    { date: 'Jan 8', sent: 1800, delivered: 1720, opened: 790, clicked: 380 },
    { date: 'Jan 15', sent: 2200, delivered: 2090, opened: 950, clicked: 460 },
    { date: 'Jan 22', sent: 1900, delivered: 1830, opened: 840, clicked: 410 },
    { date: 'Jan 29', sent: 2400, delivered: 2300, opened: 1050, clicked: 510 },
    { date: 'Feb 5', sent: 2800, delivered: 2700, opened: 1250, clicked: 620 },
    { date: 'Feb 12', sent: 3100, delivered: 2980, opened: 1390, clicked: 680 }
  ];
  
  const COLORS = ['#5046e5', '#e5e7eb', '#22c55e', '#f97316'];
  
  return (
    <AppLayout>
      <Header 
        title="Push Notifications" 
        description="Monitor and manage your mobile push notifications"
        actionButton={{
          label: "Create Push Campaign",
          href: "/campaigns/create?channel=push",
        }}
      />

      <div className="py-6 px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-500">Delivery Rate</p>
                  <h3 className="text-2xl font-semibold mt-1">96.4%</h3>
                </div>
                <div className="p-2 bg-blue-100 rounded-full">
                  <Bell className="h-5 w-5 text-blue-600" />
                </div>
              </div>
              <p className="text-xs text-green-600 mt-2">+2.1% vs. previous period</p>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-500">Open Rate</p>
                  <h3 className="text-2xl font-semibold mt-1">42.3%</h3>
                </div>
                <div className="p-2 bg-green-100 rounded-full">
                  <ArrowUpRight className="h-5 w-5 text-green-600" />
                </div>
              </div>
              <p className="text-xs text-green-600 mt-2">+3.4% vs. previous period</p>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-500">Click Rate</p>
                  <h3 className="text-2xl font-semibold mt-1">18.6%</h3>
                </div>
                <div className="p-2 bg-purple-100 rounded-full">
                  <BarChart className="h-5 w-5 text-purple-600" />
                </div>
              </div>
              <p className="text-xs text-red-600 mt-2">-1.2% vs. previous period</p>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-500">Active Subscribers</p>
                  <h3 className="text-2xl font-semibold mt-1">278,524</h3>
                </div>
                <div className="p-2 bg-amber-100 rounded-full">
                  <Users className="h-5 w-5 text-amber-600" />
                </div>
              </div>
              <p className="text-xs text-green-600 mt-2">+5.8% vs. previous period</p>
            </CardContent>
          </Card>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle>Performance Trends</CardTitle>
              <CardDescription>Push notification delivery and engagement metrics over time</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <ReChartsLineChart
                    data={performanceData}
                    margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" vertical={false} opacity={0.2} />
                    <XAxis dataKey="date" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Line type="monotone" dataKey="sent" stroke="#9ca3af" activeDot={{ r: 8 }} />
                    <Line type="monotone" dataKey="delivered" stroke="#5046e5" activeDot={{ r: 8 }} />
                    <Line type="monotone" dataKey="opened" stroke="#22c55e" activeDot={{ r: 8 }} />
                    <Line type="monotone" dataKey="clicked" stroke="#f97316" activeDot={{ r: 8 }} />
                  </ReChartsLineChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Delivery Statistics</CardTitle>
              <CardDescription>Push notification delivery performance</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-40">
                <ResponsiveContainer width="100%" height="100%">
                  <ReChartsPieChart>
                    <Pie
                      data={deliveryStats}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                      label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                    >
                      {deliveryStats.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                  </ReChartsPieChart>
                </ResponsiveContainer>
              </div>
              
              <div className="mt-6 h-40">
                <ResponsiveContainer width="100%" height="100%">
                  <ReChartsPieChart>
                    <Pie
                      data={engagementStats}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                      label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                    >
                      {engagementStats.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                  </ReChartsPieChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Recent Campaigns</CardTitle>
              <CardDescription>Your most recent push notification campaigns</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {[1, 2, 3].map((_, i) => (
                  <div key={i} className="flex items-start gap-3 border-b pb-4 last:border-b-0 last:pb-0">
                    <div className="flex h-10 w-10 items-center justify-center rounded-md bg-primary-100">
                      <Bell className="h-5 w-5 text-primary-600" />
                    </div>
                    <div className="flex-1">
                      <div className="flex justify-between items-start">
                        <div>
                          <h4 className="font-medium text-sm">Limited Time Offer</h4>
                          <p className="text-xs text-gray-500">Sent on {formatDateShort(new Date(Date.now() - i * 86400000).toISOString())}</p>
                        </div>
                        <div className="text-xs font-medium text-primary-600 px-2 py-1 bg-primary-50 rounded-full">
                          {formatPercentage(48.2 - i * 2.3)}
                        </div>
                      </div>
                      <div className="flex items-center gap-4 mt-2 text-xs text-gray-500">
                        <div>Sent: {formatNumber(35400 - i * 2300)}</div>
                        <div>Opened: {formatNumber(17500 - i * 1200)}</div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
              <Button variant="ghost" className="w-full mt-4" asChild>
                <Link href="/campaigns?channel=push">View all campaigns</Link>
              </Button>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Device Breakdown</CardTitle>
              <CardDescription>Push notification performance by device</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="p-2 bg-blue-100 rounded-full">
                      <Smartphone className="h-4 w-4 text-blue-600" />
                    </div>
                    <div>
                      <div className="text-sm font-medium">iOS</div>
                      <div className="text-xs text-gray-500">iPhone, iPad</div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-sm font-medium">58.2%</div>
                    <div className="text-xs text-gray-500">162,103 devices</div>
                  </div>
                </div>
                
                <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                  <div className="h-full bg-blue-500 rounded-full" style={{ width: '58.2%' }}></div>
                </div>
                
                <div className="flex items-center justify-between mt-6">
                  <div className="flex items-center gap-2">
                    <div className="p-2 bg-green-100 rounded-full">
                      <Smartphone className="h-4 w-4 text-green-600" />
                    </div>
                    <div>
                      <div className="text-sm font-medium">Android</div>
                      <div className="text-xs text-gray-500">Various devices</div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-sm font-medium">41.8%</div>
                    <div className="text-xs text-gray-500">116,421 devices</div>
                  </div>
                </div>
                
                <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                  <div className="h-full bg-green-500 rounded-full" style={{ width: '41.8%' }}></div>
                </div>
              </div>
              
              <div className="pt-4 mt-6 border-t">
                <h4 className="text-sm font-medium mb-2">Engagement by Device</h4>
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>iOS Open Rate:</span>
                    <span className="font-medium">44.7%</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Android Open Rate:</span>
                    <span className="font-medium">38.9%</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Quick Actions</CardTitle>
              <CardDescription>Manage your push notification settings</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <Button className="w-full justify-start" asChild>
                  <Link href="/campaigns/create?channel=push">
                    <Bell className="mr-2 h-4 w-4" />
                    Create New Campaign
                  </Link>
                </Button>
                
                <Button variant="outline" className="w-full justify-start">
                  <Settings className="mr-2 h-4 w-4" />
                  Manage Push Settings
                </Button>
                
                <Button variant="outline" className="w-full justify-start">
                  <LineChart className="mr-2 h-4 w-4" />
                  View Detailed Analytics
                </Button>
                
                <Button variant="outline" className="w-full justify-start">
                  <Clock className="mr-2 h-4 w-4" />
                  Schedule Push Campaign
                </Button>
              </div>
              
              <div className="border rounded-md p-4 mt-6">
                <h4 className="text-sm font-medium mb-2">Integration Status</h4>
                <div className="flex items-center">
                  <div className="h-2.5 w-2.5 rounded-full bg-green-500 mr-2"></div>
                  <span className="text-sm">FCM and APNS Connected</span>
                </div>
                <p className="text-xs text-gray-500 mt-2">Your push notification service is properly configured and working.</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </AppLayout>
  );
}