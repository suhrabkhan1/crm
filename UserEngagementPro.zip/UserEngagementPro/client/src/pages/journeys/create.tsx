import React, { useState } from "react";
import { useLocation } from "wouter";
import AppLayout from "@/layout/app-layout";
import Header from "@/components/layout/header";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle,
  CardDescription,
  CardFooter
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useToast } from "@/hooks/use-toast";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Route, 
  Plus, 
  MoreHorizontal, 
  CornerDownRight, 
  ChevronRight, 
  Info 
} from "lucide-react";

const formSchema = z.object({
  name: z.string().min(3, {
    message: "Journey name must be at least 3 characters.",
  }),
  description: z.string().optional(),
  goal: z.string({
    required_error: "Please select a goal for this journey.",
  }),
  entryCondition: z.string({
    required_error: "Please select an entry condition.",
  }),
  steps: z.array(z.object({
    type: z.string(),
    name: z.string(),
    content: z.record(z.any()),
    delay: z.number().optional(),
  })).min(1, {
    message: "Journey must have at least one step.",
  }),
});

type FormValues = z.infer<typeof formSchema>;

export default function CreateJourney() {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const [activeStep, setActiveStep] = useState<number>(0);
  const [steps, setSteps] = useState<any[]>([
    { 
      type: "message", 
      name: "Welcome Message", 
      content: { 
        channel: "push", 
        title: "Welcome to our app!", 
        body: "Thanks for joining. Let's get started on your journey." 
      },
      delay: 0
    }
  ]);
  
  // Default values for the form
  const defaultValues: Partial<FormValues> = {
    name: "",
    description: "",
    goal: "conversion",
    entryCondition: "newUsers",
    steps: steps,
  };
  
  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues,
  });
  
  const onSubmit = async (data: FormValues) => {
    try {
      // Update the steps data before submission
      data.steps = steps;
      
      // Convert the form data to match the API schema
      const payload = {
        name: data.name,
        description: data.description || "",
        goal: data.goal,
        entryCondition: data.entryCondition,
        steps: data.steps,
        status: "draft",
        createdBy: 1, // Using dummy user ID
        organizationId: 1 // Using dummy org ID
      };
      
      const response = await apiRequest("POST", "/api/journeys", payload);
      
      if (response.ok) {
        // Invalidate the journeys query cache
        queryClient.invalidateQueries({ queryKey: ['/api/journeys'] });
        
        toast({
          title: "Journey created successfully",
          description: "Your journey has been created as a draft.",
        });
        
        // Redirect to the journeys list page
        navigate("/journeys");
      }
    } catch (error) {
      console.error("Error creating journey:", error);
      toast({
        title: "Error creating journey",
        description: "Something went wrong. Please try again.",
        variant: "destructive",
      });
    }
  };
  
  const addStep = (type: string) => {
    let newStep;
    
    switch(type) {
      case "message":
        newStep = {
          type: "message",
          name: `Message ${steps.length + 1}`,
          content: {
            channel: "push",
            title: "Message Title",
            body: "Message body goes here"
          },
          delay: 24 // 24 hour delay by default
        };
        break;
      case "condition":
        newStep = {
          type: "condition",
          name: `Condition ${steps.length + 1}`,
          content: {
            condition: "eventOccurred",
            event: "app_opened",
            branches: []
          }
        };
        break;
      case "wait":
        newStep = {
          type: "wait",
          name: `Wait ${steps.length + 1}`,
          content: {
            duration: 24,
            unit: "hours"
          }
        };
        break;
      default:
        newStep = {
          type: "message",
          name: `Step ${steps.length + 1}`,
          content: {}
        };
    }
    
    setSteps([...steps, newStep]);
    setActiveStep(steps.length);
  };
  
  const StepIcon = ({ type }: { type: string }) => {
    switch(type) {
      case "message":
        return <div className="h-8 w-8 flex items-center justify-center rounded-full bg-blue-100 text-blue-600">M</div>;
      case "condition":
        return <div className="h-8 w-8 flex items-center justify-center rounded-full bg-purple-100 text-purple-600">C</div>;
      case "wait":
        return <div className="h-8 w-8 flex items-center justify-center rounded-full bg-amber-100 text-amber-600">W</div>;
      default:
        return <div className="h-8 w-8 flex items-center justify-center rounded-full bg-gray-100 text-gray-600">S</div>;
    }
  };
  
  return (
    <AppLayout>
      <Header 
        title="Create Journey" 
        description="Build multi-step personalized customer journeys"
      />

      <div className="py-6 px-4 sm:px-6 lg:px-8">
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Journey Details</CardTitle>
                <CardDescription>
                  Configure the basic information for your customer journey.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Journey Name</FormLabel>
                      <FormControl>
                        <Input placeholder="New User Onboarding" {...field} />
                      </FormControl>
                      <FormDescription>
                        Give your journey a descriptive name.
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="description"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Description (Optional)</FormLabel>
                      <FormControl>
                        <Textarea 
                          placeholder="Guide new users through the onboarding process with timely messages" 
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="goal"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Journey Goal</FormLabel>
                        <FormControl>
                          <select 
                            className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                            {...field}
                          >
                            <option value="conversion">Conversion</option>
                            <option value="engagement">Engagement</option>
                            <option value="retention">Retention</option>
                            <option value="education">Education</option>
                            <option value="feedback">Feedback</option>
                          </select>
                        </FormControl>
                        <FormDescription>
                          What's the primary goal of this journey?
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="entryCondition"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Entry Condition</FormLabel>
                        <FormControl>
                          <select 
                            className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                            {...field}
                          >
                            <option value="newUsers">New User Registration</option>
                            <option value="segment">User Segment</option>
                            <option value="eventTriggered">Event Triggered</option>
                            <option value="apiTriggered">API Triggered</option>
                            <option value="manual">Manual Entry</option>
                          </select>
                        </FormControl>
                        <FormDescription>
                          How do users enter this journey?
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Journey Flow</CardTitle>
                <CardDescription>
                  Design the steps of your customer journey
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex gap-4 mb-6">
                  <Button type="button" variant="outline" onClick={() => addStep("message")}>
                    <Plus className="h-4 w-4 mr-2" />
                    Add Message
                  </Button>
                  <Button type="button" variant="outline" onClick={() => addStep("condition")}>
                    <Plus className="h-4 w-4 mr-2" />
                    Add Condition
                  </Button>
                  <Button type="button" variant="outline" onClick={() => addStep("wait")}>
                    <Plus className="h-4 w-4 mr-2" />
                    Add Wait
                  </Button>
                </div>
                
                <div className="flex flex-col gap-4">
                  <div className="flex items-center gap-2 bg-blue-50 rounded-lg p-3 w-fit">
                    <Route className="h-5 w-5 text-blue-600" />
                    <span className="font-medium text-blue-700">Journey Entry Point</span>
                  </div>
                  
                  {steps.map((step, index) => (
                    <div key={index} className="flex items-start">
                      <div className="flex flex-col items-center mr-3">
                        <div className="h-10 border-l border-dashed border-gray-300"></div>
                        <ChevronRight className="h-4 w-4 text-gray-400 -mt-1 mb-1" />
                      </div>
                      
                      <div className={`flex-1 border rounded-lg p-4 ${index === activeStep ? 'ring-2 ring-primary ring-offset-2' : ''}`}>
                        <div className="flex justify-between items-center mb-3">
                          <div className="flex items-center gap-3">
                            <StepIcon type={step.type} />
                            <div>
                              <h4 className="font-medium">{step.name}</h4>
                              <p className="text-sm text-gray-500 capitalize">{step.type} step</p>
                            </div>
                          </div>
                          <div className="flex items-center gap-2">
                            {step.delay > 0 && (
                              <div className="text-xs bg-gray-100 px-2 py-1 rounded-full">
                                Delay: {step.delay}h
                              </div>
                            )}
                            <Button type="button" variant="ghost" size="icon">
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                        
                        {step.type === "message" && (
                          <div className="bg-gray-50 p-3 rounded-md text-sm">
                            <div className="mb-1 font-medium">{step.content.title || 'No title'}</div>
                            <div className="text-gray-600">{step.content.body || 'No content'}</div>
                            <div className="mt-2 text-xs text-gray-500">Channel: {step.content.channel || 'push'}</div>
                          </div>
                        )}
                        
                        {step.type === "condition" && (
                          <div className="bg-gray-50 p-3 rounded-md text-sm">
                            <div className="mb-1">Condition: {step.content.condition || 'event occurred'}</div>
                            <div className="text-gray-600">Event: {step.content.event || 'any'}</div>
                          </div>
                        )}
                        
                        {step.type === "wait" && (
                          <div className="bg-gray-50 p-3 rounded-md text-sm">
                            <div className="text-gray-600">Wait for: {step.content.duration || 24} {step.content.unit || 'hours'}</div>
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                  
                  <div className="flex items-start">
                    <div className="flex flex-col items-center mr-3">
                      <div className="h-10 border-l border-dashed border-gray-300"></div>
                    </div>
                    <div className="border border-dashed border-gray-300 rounded-lg p-4 text-center cursor-pointer hover:bg-gray-50 transition-colors" onClick={() => addStep("message")}>
                      <Plus className="h-5 w-5 text-gray-400 inline-block mb-1" />
                      <p className="text-sm text-gray-500">Add another step</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-2 bg-green-50 rounded-lg p-3 w-fit ml-10 mt-2">
                    <Route className="h-5 w-5 text-green-600 rotate-180" />
                    <span className="font-medium text-green-700">Journey End</span>
                  </div>
                </div>
              </CardContent>
              <CardFooter className="flex justify-between border-t p-6">
                <Button type="button" variant="outline" onClick={() => navigate("/journeys")}>
                  Cancel
                </Button>
                <div className="flex gap-2">
                  <Button type="submit">Save Journey as Draft</Button>
                </div>
              </CardFooter>
            </Card>
          </form>
        </Form>
      </div>
    </AppLayout>
  );
}