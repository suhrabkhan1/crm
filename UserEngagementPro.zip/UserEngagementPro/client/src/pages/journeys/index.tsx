import React, { useState } from "react";
import AppLayout from "@/layout/app-layout";
import Header from "@/components/layout/header";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle,
  CardDescription 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";
import { Skeleton } from "@/components/ui/skeleton";
import { DataTable } from "@/components/ui/data-table";
import { Link } from "wouter";
import { getStatusColor } from "@/lib/utils";
import { 
  Play, 
  Pause, 
  Calendar, 
  Route, 
  Edit, 
  Copy, 
  Trash, 
  AlertTriangle,
  Gauge,
  Activity,
  ArrowRight
} from "lucide-react";
import { formatDateShort } from "@/lib/dates";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

interface Journey {
  id: number;
  name: string;
  description: string;
  steps: any[];
  status: string;
  createdAt: string;
  stats?: {
    usersEntered: number;
    usersCompleted: number;
    conversionRate: number;
    activeUsers: number;
  };
}

export default function Journeys() {
  const [statusFilter, setStatusFilter] = useState<string>("all");
  
  const { data: journeys, isLoading, refetch } = useQuery<Journey[]>({
    queryKey: ['/api/journeys', statusFilter],
  });

  const filteredJourneys = journeys?.filter(journey => {
    if (statusFilter !== "all" && journey.status !== statusFilter) return false;
    return true;
  });

  const columns = [
    {
      accessorKey: "name",
      header: "Journey Name",
      cell: ({ row }: any) => (
        <div className="flex items-start gap-3">
          <div className="flex h-9 w-9 items-center justify-center rounded-md bg-purple-100">
            <Route className="h-5 w-5 text-purple-600" />
          </div>
          <div>
            <div className="font-medium">{row.getValue("name")}</div>
            <div className="text-sm text-gray-500 truncate max-w-[300px]">{row.original.description}</div>
          </div>
        </div>
      ),
    },
    {
      accessorKey: "steps",
      header: "Steps",
      cell: ({ row }: any) => (
        <div className="text-sm">{row.getValue("steps").length} steps</div>
      ),
    },
    {
      accessorKey: "status",
      header: "Status",
      cell: ({ row }: any) => (
        <div className={`w-fit px-2 py-1 text-xs rounded-full ${getStatusColor(row.getValue("status"))}`}>
          {row.getValue("status").charAt(0).toUpperCase() + row.getValue("status").slice(1)}
        </div>
      ),
    },
    {
      accessorKey: "stats",
      header: "Performance",
      cell: ({ row }: any) => {
        const stats = row.original.stats;
        if (!stats || row.original.status === 'draft') {
          return <span className="text-gray-500">-</span>;
        }
        
        return (
          <div className="flex items-center gap-2">
            <div className="flex flex-col">
              <span className="text-xs text-gray-500">Conversion</span>
              <span className="font-medium">{stats.conversionRate}%</span>
            </div>
            <ArrowRight className="h-3 w-3 text-gray-300" />
            <div className="flex flex-col">
              <span className="text-xs text-gray-500">Active</span>
              <span className="font-medium">{stats.activeUsers}</span>
            </div>
          </div>
        );
      },
    },
    {
      accessorKey: "createdAt",
      header: "Created",
      cell: ({ row }: any) => (
        <div className="flex items-center gap-1">
          <Calendar className="h-3 w-3 text-gray-500" />
          <span>{formatDateShort(row.getValue("createdAt"))}</span>
        </div>
      ),
    },
    {
      id: "actions",
      cell: ({ row }: any) => (
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" className="h-8 w-8 p-0">
              <span className="sr-only">Open menu</span>
              <div className="flex h-8 w-8 items-center justify-center">
                <div className="h-1 w-1 rounded-full bg-gray-500"></div>
                <div className="h-1 w-1 rounded-full bg-gray-500 ml-0.5"></div>
                <div className="h-1 w-1 rounded-full bg-gray-500 ml-0.5"></div>
              </div>
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuLabel>Actions</DropdownMenuLabel>
            <DropdownMenuItem 
              onClick={() => window.location.href = `/journeys/${row.original.id}`}
              className="cursor-pointer"
            >
              <Route className="mr-2 h-4 w-4" />
              View Journey
            </DropdownMenuItem>
            <DropdownMenuItem 
              onClick={() => window.location.href = `/journeys/${row.original.id}/edit`}
              className="cursor-pointer"
            >
              <Edit className="mr-2 h-4 w-4" />
              Edit
            </DropdownMenuItem>
            <DropdownMenuItem className="cursor-pointer">
              <Copy className="mr-2 h-4 w-4" />
              Duplicate
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            {row.original.status === 'active' ? (
              <DropdownMenuItem className="cursor-pointer">
                <Pause className="mr-2 h-4 w-4" />
                Pause Journey
              </DropdownMenuItem>
            ) : (
              <DropdownMenuItem className="cursor-pointer">
                <Play className="mr-2 h-4 w-4" />
                Activate Journey
              </DropdownMenuItem>
            )}
            <DropdownMenuSeparator />
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <DropdownMenuItem 
                  onSelect={(e) => e.preventDefault()}
                  className="text-red-600 cursor-pointer"
                >
                  <Trash className="mr-2 h-4 w-4" />
                  Delete
                </DropdownMenuItem>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
                  <AlertDialogDescription>
                    This action cannot be undone. This will permanently delete the journey
                    "{row.original.name}" and remove all users from this journey.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>Cancel</AlertDialogCancel>
                  <AlertDialogAction className="bg-red-600">Delete</AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          </DropdownMenuContent>
        </DropdownMenu>
      ),
    },
  ];
  
  // Quick stats for the overview
  const stats = {
    active: journeys?.filter(j => j.status === 'active').length || 0,
    draft: journeys?.filter(j => j.status === 'draft').length || 0,
    paused: journeys?.filter(j => j.status === 'paused').length || 0,
    total: journeys?.length || 0,
  };

  return (
    <AppLayout>
      <Header 
        title="Journeys" 
        description="Create and manage customer journey flows"
        actionButton={{
          label: "Create Journey",
          href: "/journeys/create",
        }}
      />

      <div className="py-6 px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <Card className={statusFilter === 'all' ? 'ring-2 ring-primary-500 ring-offset-2' : ''}>
            <CardContent className="pt-6">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-500">Total Journeys</p>
                  <h3 className="text-2xl font-semibold mt-1">{stats.total}</h3>
                </div>
                <div className="p-2 bg-purple-100 rounded-full">
                  <Route className="h-5 w-5 text-purple-600" />
                </div>
              </div>
              <Button 
                variant="ghost" 
                size="sm" 
                className="mt-2 w-full justify-start text-primary-600"
                onClick={() => setStatusFilter('all')}
              >
                View all
              </Button>
            </CardContent>
          </Card>
          
          <Card className={statusFilter === 'active' ? 'ring-2 ring-primary-500 ring-offset-2' : ''}>
            <CardContent className="pt-6">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-500">Active</p>
                  <h3 className="text-2xl font-semibold mt-1">{stats.active}</h3>
                </div>
                <div className="p-2 bg-green-100 rounded-full">
                  <Activity className="h-5 w-5 text-green-600" />
                </div>
              </div>
              <Button 
                variant="ghost" 
                size="sm" 
                className="mt-2 w-full justify-start text-primary-600"
                onClick={() => setStatusFilter('active')}
              >
                View active
              </Button>
            </CardContent>
          </Card>
          
          <Card className={statusFilter === 'draft' ? 'ring-2 ring-primary-500 ring-offset-2' : ''}>
            <CardContent className="pt-6">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-500">Drafts</p>
                  <h3 className="text-2xl font-semibold mt-1">{stats.draft}</h3>
                </div>
                <div className="p-2 bg-amber-100 rounded-full">
                  <Gauge className="h-5 w-5 text-amber-600" />
                </div>
              </div>
              <Button 
                variant="ghost" 
                size="sm" 
                className="mt-2 w-full justify-start text-primary-600"
                onClick={() => setStatusFilter('draft')}
              >
                View drafts
              </Button>
            </CardContent>
          </Card>
        </div>
        
        <Card>
          <CardHeader>
            <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center space-y-2 sm:space-y-0">
              <div>
                <CardTitle>Journey Management</CardTitle>
                <CardDescription>
                  Create multi-step customer journeys for better engagement
                </CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="space-y-4">
                <Skeleton className="h-10 w-full" />
                <Skeleton className="h-32 w-full" />
                <Skeleton className="h-10 w-full" />
              </div>
            ) : filteredJourneys && filteredJourneys.length > 0 ? (
              <DataTable 
                columns={columns}
                data={filteredJourneys}
                searchColumn="name"
                searchPlaceholder="Search journeys..."
              />
            ) : (
              <div className="flex flex-col items-center justify-center py-12 text-center">
                <div className="bg-purple-100 p-3 rounded-full mb-4">
                  <Route className="h-8 w-8 text-purple-600" />
                </div>
                <h3 className="text-lg font-medium text-gray-900 mb-1">No Journeys Found</h3>
                <p className="text-sm text-gray-500 max-w-sm mb-6">
                  Create your first journey to guide users through personalized experiences based on their behavior.
                </p>
                <Button asChild>
                  <Link href="/journeys/create">Create Journey</Link>
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
        
        <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Top Performing Journeys</CardTitle>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <Skeleton className="h-[250px] w-full" />
              ) : (
                <div className="space-y-4">
                  {journeys?.filter(j => j.status === 'active' && j.stats)
                    .sort((a, b) => (b.stats?.conversionRate || 0) - (a.stats?.conversionRate || 0))
                    .slice(0, 3)
                    .map((journey, idx) => (
                      <div key={idx} className="flex items-center gap-4 p-3 bg-gray-50 rounded-lg">
                        <div className="h-10 w-10 rounded-full bg-primary-100 flex items-center justify-center">
                          <span className="text-primary-700 font-semibold">{idx + 1}</span>
                        </div>
                        <div className="flex-1">
                          <h4 className="font-medium text-sm">{journey.name}</h4>
                          <p className="text-xs text-gray-500">{journey.steps.length} steps • Created {formatDateShort(journey.createdAt)}</p>
                        </div>
                        <div className="text-right">
                          <div className="text-lg font-medium text-primary-600">{journey.stats?.conversionRate}%</div>
                          <div className="text-xs text-gray-500">conversion rate</div>
                        </div>
                      </div>
                    ))}
                  
                  {(!journeys || journeys.filter(j => j.status === 'active').length === 0) && (
                    <div className="flex flex-col items-center justify-center py-8 text-center">
                      <AlertTriangle className="h-10 w-10 text-gray-300 mb-2" />
                      <p className="text-sm text-gray-500">No active journeys to display</p>
                    </div>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Journey Tips</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="p-3 bg-blue-50 rounded-lg border border-blue-100 flex gap-3">
                  <div className="flex-shrink-0 bg-blue-100 h-10 w-10 rounded-full flex items-center justify-center">
                    <Route className="h-5 w-5 text-blue-700" />
                  </div>
                  <div>
                    <h4 className="font-medium text-blue-800 text-sm">Start with clear goals</h4>
                    <p className="text-xs text-blue-700 mt-1">Define what you want users to accomplish in your journey, such as completing a purchase or onboarding process.</p>
                  </div>
                </div>
                
                <div className="p-3 bg-green-50 rounded-lg border border-green-100 flex gap-3">
                  <div className="flex-shrink-0 bg-green-100 h-10 w-10 rounded-full flex items-center justify-center">
                    <Route className="h-5 w-5 text-green-700" />
                  </div>
                  <div>
                    <h4 className="font-medium text-green-800 text-sm">Multi-channel coordination</h4>
                    <p className="text-xs text-green-700 mt-1">Combine different channels like push, email, and in-app messages for a cohesive experience.</p>
                  </div>
                </div>
                
                <div className="p-3 bg-amber-50 rounded-lg border border-amber-100 flex gap-3">
                  <div className="flex-shrink-0 bg-amber-100 h-10 w-10 rounded-full flex items-center justify-center">
                    <Route className="h-5 w-5 text-amber-700" />
                  </div>
                  <div>
                    <h4 className="font-medium text-amber-800 text-sm">Test and optimize</h4>
                    <p className="text-xs text-amber-700 mt-1">Regularly analyze performance and make adjustments to improve conversion rates.</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </AppLayout>
  );
}
