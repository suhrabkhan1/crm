import React from "react";
import AppLayout from "@/layout/app-layout";
import Header from "@/components/layout/header";
import QuickStats from "@/components/dashboard/quick-stats";
import EngagementChart from "@/components/dashboard/engagement-chart";
import ChannelPerformance from "@/components/dashboard/channel-performance";
import RecentCampaigns from "@/components/dashboard/recent-campaigns";
import FunnelAnalysis from "@/components/dashboard/funnel-analysis";
import UserSegments from "@/components/dashboard/user-segments";
import CohortRetention from "@/components/dashboard/cohort-retention";
import MessagePerformance from "@/components/dashboard/message-performance";
import TopEvents from "@/components/dashboard/top-events";

export default function Dashboard() {
  return (
    <AppLayout>
      <Header 
        title="Dashboard" 
        description="Overview of your app's performance and user engagement"
        actionButton={{
          label: "New Campaign",
          href: "/campaigns/create",
        }}
      />

      <div className="py-6 px-4 sm:px-6 lg:px-8">
        {/* Quick Stats */}
        <QuickStats />

        {/* Charts Section */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
          <EngagementChart />
          <ChannelPerformance />
        </div>

        {/* Recent Campaigns & Funnel Analysis */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
          <RecentCampaigns />
          <FunnelAnalysis />
        </div>
        
        {/* User Segments & Cohort Retention */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
          <UserSegments />
          <CohortRetention />
        </div>
        
        {/* Message Performance & Events */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <MessagePerformance />
          <TopEvents />
        </div>
      </div>
    </AppLayout>
  );
}
