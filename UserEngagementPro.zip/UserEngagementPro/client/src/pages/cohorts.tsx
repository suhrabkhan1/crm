import React, { useState } from "react";
import AppLayout from "@/layout/app-layout";
import Header from "@/components/layout/header";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle,
  CardDescription 
} from "@/components/ui/card";
import { 
  Tabs, 
  TabsContent, 
  TabsList, 
  TabsTrigger 
} from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useQuery } from "@tanstack/react-query";
import { Skeleton } from "@/components/ui/skeleton";
import { cohortRetentionData } from "@/lib/charts";

type CohortPeriod = 'weekly' | 'monthly' | 'quarterly';
type RetentionView = 'table' | 'heatmap';

export default function Cohorts() {
  const [period, setPeriod] = useState<CohortPeriod>('weekly');
  const [view, setView] = useState<RetentionView>('table');
  
  const { data, isLoading } = useQuery({
    queryKey: ['/api/analytics/cohort-retention', period],
    queryFn: () => Promise.resolve(cohortRetentionData)
  });

  const getColorClass = (value: number) => {
    if (value >= 80) return "bg-primary-600";
    if (value >= 60) return "bg-primary-500";
    if (value >= 40) return "bg-primary-400";
    if (value >= 20) return "bg-primary-300";
    return "bg-primary-100";
  };

  const getHeatmapStyle = (value: number) => {
    const opacity = value / 100;
    return {
      backgroundColor: `rgba(80, 70, 229, ${opacity})`,
      color: value > 50 ? 'white' : 'black'
    };
  };

  return (
    <AppLayout>
      <Header 
        title="Cohort Analysis" 
        description="Track user retention and engagement over time"
      />

      <div className="py-6 px-4 sm:px-6 lg:px-8">
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle>Retention Analysis</CardTitle>
                <CardDescription>
                  Measure how users from different cohorts continue using your app over time
                </CardDescription>
              </div>
              <div className="flex space-x-4">
                <Select
                  value={period}
                  onValueChange={(value) => setPeriod(value as CohortPeriod)}
                >
                  <SelectTrigger className="w-[120px]">
                    <SelectValue placeholder="Select period" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="weekly">Weekly</SelectItem>
                    <SelectItem value="monthly">Monthly</SelectItem>
                    <SelectItem value="quarterly">Quarterly</SelectItem>
                  </SelectContent>
                </Select>
                <Tabs value={view} onValueChange={(v) => setView(v as RetentionView)}>
                  <TabsList>
                    <TabsTrigger value="table">Table</TabsTrigger>
                    <TabsTrigger value="heatmap">Heatmap</TabsTrigger>
                  </TabsList>
                </Tabs>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <Skeleton className="h-[400px] w-full" />
            ) : view === 'table' ? (
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-300 border rounded-lg">
                  <thead className="bg-gray-50">
                    <tr>
                      <th scope="col" className="py-3 pl-4 pr-3 text-left text-sm font-semibold text-gray-900">Cohort</th>
                      <th scope="col" className="px-3 py-3 text-left text-sm font-semibold text-gray-900">Users</th>
                      <th scope="col" className="px-3 py-3 text-left text-sm font-semibold text-gray-900">Week 1</th>
                      <th scope="col" className="px-3 py-3 text-left text-sm font-semibold text-gray-900">Week 2</th>
                      <th scope="col" className="px-3 py-3 text-left text-sm font-semibold text-gray-900">Week 3</th>
                      <th scope="col" className="px-3 py-3 text-left text-sm font-semibold text-gray-900">Week 4</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-200 bg-white">
                    {data?.map((cohort, index) => (
                      <tr key={index}>
                        <td className="whitespace-nowrap py-3 pl-4 pr-3 text-sm font-medium text-gray-900">{cohort.cohort}</td>
                        <td className="whitespace-nowrap px-3 py-3 text-sm text-gray-500">{cohort.users.toLocaleString()}</td>
                        {cohort.retention.map((value, idx) => (
                          <td key={idx} className="whitespace-nowrap px-3 py-3 text-sm text-gray-500">
                            <div className={`${getColorClass(value)} rounded text-xs px-2 py-1 text-white font-medium`}>
                              {value}%
                            </div>
                          </td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="min-w-full border rounded-lg">
                  <thead className="bg-gray-50">
                    <tr>
                      <th scope="col" className="py-3 pl-4 pr-3 text-left text-sm font-semibold text-gray-900">Cohort</th>
                      <th scope="col" className="px-3 py-3 text-left text-sm font-semibold text-gray-900">Users</th>
                      <th scope="col" className="px-3 py-3 text-center text-sm font-semibold text-gray-900">Week 1</th>
                      <th scope="col" className="px-3 py-3 text-center text-sm font-semibold text-gray-900">Week 2</th>
                      <th scope="col" className="px-3 py-3 text-center text-sm font-semibold text-gray-900">Week 3</th>
                      <th scope="col" className="px-3 py-3 text-center text-sm font-semibold text-gray-900">Week 4</th>
                    </tr>
                  </thead>
                  <tbody>
                    {data?.map((cohort, index) => (
                      <tr key={index} className="hover:bg-gray-50">
                        <td className="whitespace-nowrap py-3 pl-4 pr-3 text-sm font-medium text-gray-900">{cohort.cohort}</td>
                        <td className="whitespace-nowrap px-3 py-3 text-sm text-gray-500">{cohort.users.toLocaleString()}</td>
                        {cohort.retention.map((value, idx) => (
                          <td key={idx} className="px-3 py-3">
                            <div 
                              className="h-10 flex items-center justify-center rounded"
                              style={getHeatmapStyle(value)}
                            >
                              {value}%
                            </div>
                          </td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}

            <div className="mt-6">
              <h3 className="text-sm font-medium text-gray-900 mb-2">How to read this chart:</h3>
              <ul className="list-disc list-inside text-sm text-gray-600 space-y-1">
                <li>Each row represents a cohort of users who started using your app in the given time period</li>
                <li>The percentages show how many users from the original cohort were still active in subsequent weeks</li>
                <li>Week 1 is always 100% as it represents the starting point for each cohort</li>
                <li>Lower retention in later weeks indicates that users are dropping off</li>
              </ul>
            </div>
          </CardContent>
        </Card>
      </div>
    </AppLayout>
  );
}
