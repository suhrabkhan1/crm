import React, { useState } from "react";
import AppLayout from "@/layout/app-layout";
import Header from "@/components/layout/header";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle,
  CardDescription 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  Select, 
  SelectContent, 
  SelectGroup, 
  SelectItem, 
  SelectLabel, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { useQuery } from "@tanstack/react-query";
import { Skeleton } from "@/components/ui/skeleton";
import { PlusCircle, Save, Download, Undo2, Redo2 } from "lucide-react";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { 
  Tabs, 
  TabsContent, 
  TabsList, 
  TabsTrigger 
} from "@/components/ui/tabs";
import { 
  BarChart, 
  Bar, 
  PieChart, 
  Pie, 
  Cell, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer 
} from 'recharts';

interface PivotOption {
  id: string;
  name: string;
}

const rowOptions: PivotOption[] = [
  { id: "country", name: "Country" },
  { id: "device", name: "Device" },
  { id: "channel", name: "Channel" },
  { id: "campaign", name: "Campaign" },
  { id: "os", name: "Operating System" },
  { id: "appVersion", name: "App Version" }
];

const columnOptions: PivotOption[] = [
  { id: "date", name: "Date" },
  { id: "eventType", name: "Event Type" },
  { id: "conversionStatus", name: "Conversion Status" },
  { id: "userType", name: "User Type" },
];

const valueOptions: PivotOption[] = [
  { id: "count", name: "Count" },
  { id: "uniqueUsers", name: "Unique Users" },
  { id: "averageSessionLength", name: "Avg. Session Length" },
  { id: "conversionRate", name: "Conversion Rate" },
  { id: "revenue", name: "Revenue" }
];

// Mock data for demonstration
const generatePivotData = () => {
  const devices = ['iOS', 'Android', 'Web'];
  const countries = ['United States', 'United Kingdom', 'Germany', 'France', 'Japan'];
  const results: any[] = [];
  
  countries.forEach(country => {
    devices.forEach(device => {
      results.push({
        country,
        device,
        count: Math.floor(Math.random() * 10000) + 1000,
        uniqueUsers: Math.floor(Math.random() * 8000) + 500,
        averageSessionLength: Math.floor(Math.random() * 300) + 60,
        conversionRate: (Math.random() * 10).toFixed(2),
        revenue: Math.floor(Math.random() * 10000) + 500
      });
    });
  });
  
  return results;
};

export default function Pivots() {
  const [rowDimension, setRowDimension] = useState<string>("country");
  const [columnDimension, setColumnDimension] = useState<string>("device");
  const [valueDimension, setValueDimension] = useState<string>("count");
  const [view, setView] = useState<string>("table");
  
  const { data, isLoading, refetch } = useQuery({
    queryKey: ['/api/analytics/pivot', rowDimension, columnDimension, valueDimension],
    queryFn: () => Promise.resolve(generatePivotData())
  });

  const aggregateData = (data: any[] | undefined) => {
    if (!data) return [];
    
    // Group by row dimension and aggregate values by column dimension
    const groupedData = data.reduce((acc, item) => {
      const rowKey = item[rowDimension];
      
      if (!acc[rowKey]) {
        acc[rowKey] = {};
      }
      
      const colKey = item[columnDimension];
      acc[rowKey][colKey] = item[valueDimension];
      
      return acc;
    }, {});
    
    // Convert to format needed for table
    return Object.entries(groupedData).map(([rowKey, colValues]: [string, any]) => ({
      [rowDimension]: rowKey,
      ...colValues
    }));
  };

  const prepareChartData = (data: any[] | undefined) => {
    if (!data) return [];
    
    // For bar chart, aggregate by row dimension
    const aggregated = data.reduce((acc, item) => {
      const key = item[rowDimension];
      
      if (!acc[key]) {
        acc[key] = {
          name: key,
          total: 0
        };
      }
      
      acc[key].total += parseFloat(item[valueDimension]) || 0;
      return acc;
    }, {});
    
    return Object.values(aggregated);
  };

  const pivotData = aggregateData(data);
  const chartData = prepareChartData(data);
  
  // Get unique column values for table headers
  const columnValues = data ? [...new Set(data.map(item => item[columnDimension]))] : [];

  return (
    <AppLayout>
      <Header 
        title="Pivot Tables" 
        description="Create custom cross-tabulations of your data"
      />

      <div className="py-6 px-4 sm:px-6 lg:px-8">
        <Card className="mb-6">
          <CardHeader>
            <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center space-y-2 sm:space-y-0">
              <div>
                <CardTitle>Custom Pivot</CardTitle>
                <CardDescription>
                  Select dimensions and measures to analyze your data
                </CardDescription>
              </div>
              <div className="flex flex-wrap gap-2">
                <Button variant="outline" size="sm">
                  <Save className="h-4 w-4 mr-2" />
                  Save Pivot
                </Button>
                <Button variant="outline" size="sm">
                  <Download className="h-4 w-4 mr-2" />
                  Export
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Rows</label>
                <Select 
                  value={rowDimension} 
                  onValueChange={setRowDimension}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select dimension" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectGroup>
                      <SelectLabel>Dimensions</SelectLabel>
                      {rowOptions.map(option => (
                        <SelectItem key={option.id} value={option.id}>
                          {option.name}
                        </SelectItem>
                      ))}
                    </SelectGroup>
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Columns</label>
                <Select 
                  value={columnDimension} 
                  onValueChange={setColumnDimension}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select dimension" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectGroup>
                      <SelectLabel>Dimensions</SelectLabel>
                      {columnOptions.map(option => (
                        <SelectItem key={option.id} value={option.id}>
                          {option.name}
                        </SelectItem>
                      ))}
                    </SelectGroup>
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Values</label>
                <Select 
                  value={valueDimension} 
                  onValueChange={setValueDimension}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select measure" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectGroup>
                      <SelectLabel>Measures</SelectLabel>
                      {valueOptions.map(option => (
                        <SelectItem key={option.id} value={option.id}>
                          {option.name}
                        </SelectItem>
                      ))}
                    </SelectGroup>
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            <div className="flex justify-between items-center mb-4">
              <Button variant="default" size="sm" onClick={() => refetch()}>
                Generate Pivot
              </Button>
              
              <Tabs value={view} onValueChange={setView}>
                <TabsList>
                  <TabsTrigger value="table">Table</TabsTrigger>
                  <TabsTrigger value="bar">Bar Chart</TabsTrigger>
                  <TabsTrigger value="pie">Pie Chart</TabsTrigger>
                </TabsList>
              </Tabs>
            </div>
            
            {isLoading ? (
              <Skeleton className="h-[400px] w-full" />
            ) : (
              <div>
                {view === 'table' && (
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead className="font-bold">
                            {rowOptions.find(o => o.id === rowDimension)?.name || rowDimension}
                          </TableHead>
                          {columnValues.map((colValue) => (
                            <TableHead key={colValue} className="text-right">
                              {colValue}
                            </TableHead>
                          ))}
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {pivotData.map((row, index) => (
                          <TableRow key={index}>
                            <TableCell className="font-medium">
                              {row[rowDimension]}
                            </TableCell>
                            {columnValues.map((colValue) => (
                              <TableCell key={colValue} className="text-right">
                                {valueDimension === 'conversionRate' 
                                  ? `${parseFloat(row[colValue] || 0).toFixed(2)}%`
                                  : (row[colValue] || 0).toLocaleString()}
                              </TableCell>
                            ))}
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                )}
                
                {view === 'bar' && (
                  <div className="h-[400px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart
                        data={chartData}
                        margin={{
                          top: 20,
                          right: 30,
                          left: 20,
                          bottom: 60,
                        }}
                      >
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis 
                          dataKey="name" 
                          angle={-45} 
                          textAnchor="end"
                          tick={{ fontSize: 12 }}
                          height={60}
                        />
                        <YAxis />
                        <Tooltip />
                        <Legend />
                        <Bar 
                          dataKey="total" 
                          name={valueOptions.find(o => o.id === valueDimension)?.name || valueDimension} 
                          fill="#5046e5" 
                        />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                )}
                
                {view === 'pie' && (
                  <div className="h-[400px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={chartData}
                          cx="50%"
                          cy="50%"
                          labelLine={false}
                          label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                          outerRadius={150}
                          fill="#8884d8"
                          dataKey="total"
                          nameKey="name"
                        >
                          {chartData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={`hsl(${(index * 30 + 240) % 360}, 70%, 60%)`} />
                          ))}
                        </Pie>
                        <Tooltip formatter={(value) => value.toLocaleString()} />
                        <Legend />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                )}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </AppLayout>
  );
}
