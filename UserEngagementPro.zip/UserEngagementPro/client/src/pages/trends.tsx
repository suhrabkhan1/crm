import React, { useState } from "react";
import AppLayout from "@/layout/app-layout";
import Header from "@/components/layout/header";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle,
  CardDescription 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useQuery } from "@tanstack/react-query";
import { Skeleton } from "@/components/ui/skeleton";
import { generateUserEngagementData, getLegendColors } from "@/lib/charts";
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer,
  AreaChart,
  Area 
} from 'recharts';
import { 
  Tabs, 
  TabsContent, 
  TabsList, 
  TabsTrigger 
} from "@/components/ui/tabs";
import { Download, Filter } from "lucide-react";

type Period = 'daily' | 'weekly' | 'monthly';
type ChartType = 'line' | 'area' | 'multiline';
type Metric = 'activeUsers' | 'sessions' | 'conversion' | 'retention';

export default function Trends() {
  const [period, setPeriod] = useState<Period>('daily');
  const [chartType, setChartType] = useState<ChartType>('line');
  const [metric, setMetric] = useState<Metric>('activeUsers');
  
  // In a real app, we would fetch based on the selected period and metric
  const { data, isLoading } = useQuery({
    queryKey: ['/api/analytics/trends', period, metric],
    queryFn: () => Promise.resolve(generateUserEngagementData(30))
  });

  const getMetricName = (metric: Metric) => {
    switch (metric) {
      case 'activeUsers': return 'Active Users';
      case 'sessions': return 'Sessions';
      case 'conversion': return 'Conversion Rate';
      case 'retention': return 'Retention Rate';
      default: return '';
    }
  };

  return (
    <AppLayout>
      <Header 
        title="Trends Analysis" 
        description="Track how metrics change over time"
      />

      <div className="py-6 px-4 sm:px-6 lg:px-8">
        <Card className="mb-6">
          <CardHeader>
            <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center space-y-2 sm:space-y-0">
              <div>
                <CardTitle>Metric Trends</CardTitle>
                <CardDescription>
                  Analyze how key metrics change over time
                </CardDescription>
              </div>
              <div className="flex flex-wrap gap-2">
                <Select
                  value={metric}
                  onValueChange={(value) => setMetric(value as Metric)}
                >
                  <SelectTrigger className="w-[160px]">
                    <SelectValue placeholder="Select metric" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="activeUsers">Active Users</SelectItem>
                    <SelectItem value="sessions">Sessions</SelectItem>
                    <SelectItem value="conversion">Conversion Rate</SelectItem>
                    <SelectItem value="retention">Retention Rate</SelectItem>
                  </SelectContent>
                </Select>
                
                <Select
                  value={period}
                  onValueChange={(value) => setPeriod(value as Period)}
                >
                  <SelectTrigger className="w-[140px]">
                    <SelectValue placeholder="Select period" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="daily">Daily</SelectItem>
                    <SelectItem value="weekly">Weekly</SelectItem>
                    <SelectItem value="monthly">Monthly</SelectItem>
                  </SelectContent>
                </Select>

                <Tabs value={chartType} onValueChange={(v) => setChartType(v as ChartType)}>
                  <TabsList>
                    <TabsTrigger value="line">Line</TabsTrigger>
                    <TabsTrigger value="area">Area</TabsTrigger>
                    <TabsTrigger value="multiline">Multi-line</TabsTrigger>
                  </TabsList>
                </Tabs>

                <Button variant="outline" size="icon">
                  <Download className="h-4 w-4" />
                  <span className="sr-only">Download</span>
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <Skeleton className="h-[500px] w-full" />
            ) : (
              <div className="h-[500px]">
                {chartType === 'line' && (
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart
                      data={data}
                      margin={{
                        top: 20,
                        right: 30,
                        left: 20,
                        bottom: 20,
                      }}
                    >
                      <CartesianGrid strokeDasharray="3 3" vertical={false} opacity={0.2} />
                      <XAxis 
                        dataKey="label" 
                        tick={{ fontSize: 12 }}
                        tickLine={false}
                        axisLine={{ stroke: '#e2e8f0' }}
                      />
                      <YAxis 
                        tickFormatter={(value) => value >= 1000 ? `${(value / 1000).toFixed(0)}k` : value}
                        tick={{ fontSize: 12 }}
                        tickLine={false}
                        axisLine={{ stroke: '#e2e8f0' }}
                      />
                      <Tooltip 
                        formatter={(value: number) => [value.toLocaleString(), getMetricName(metric)]}
                        labelFormatter={(label) => `Date: ${label}`}
                      />
                      <Legend />
                      <Line 
                        type="monotone" 
                        dataKey={metric} 
                        name={getMetricName(metric)}
                        stroke={getLegendColors()[0]} 
                        strokeWidth={2}
                        dot={false}
                        activeDot={{ r: 6 }}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                )}

                {chartType === 'area' && (
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart
                      data={data}
                      margin={{
                        top: 20,
                        right: 30,
                        left: 20,
                        bottom: 20,
                      }}
                    >
                      <CartesianGrid strokeDasharray="3 3" vertical={false} opacity={0.2} />
                      <XAxis 
                        dataKey="label" 
                        tick={{ fontSize: 12 }}
                        tickLine={false}
                        axisLine={{ stroke: '#e2e8f0' }}
                      />
                      <YAxis 
                        tickFormatter={(value) => value >= 1000 ? `${(value / 1000).toFixed(0)}k` : value}
                        tick={{ fontSize: 12 }}
                        tickLine={false}
                        axisLine={{ stroke: '#e2e8f0' }}
                      />
                      <Tooltip 
                        formatter={(value: number) => [value.toLocaleString(), getMetricName(metric)]}
                        labelFormatter={(label) => `Date: ${label}`}
                      />
                      <Legend />
                      <Area 
                        type="monotone" 
                        dataKey={metric} 
                        name={getMetricName(metric)}
                        stroke={getLegendColors()[0]} 
                        fill={`${getLegendColors()[0]}33`}
                      />
                    </AreaChart>
                  </ResponsiveContainer>
                )}

                {chartType === 'multiline' && (
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart
                      data={data}
                      margin={{
                        top: 20,
                        right: 30,
                        left: 20,
                        bottom: 20,
                      }}
                    >
                      <CartesianGrid strokeDasharray="3 3" vertical={false} opacity={0.2} />
                      <XAxis 
                        dataKey="label" 
                        tick={{ fontSize: 12 }}
                        tickLine={false}
                        axisLine={{ stroke: '#e2e8f0' }}
                      />
                      <YAxis 
                        tickFormatter={(value) => value >= 1000 ? `${(value / 1000).toFixed(0)}k` : value}
                        tick={{ fontSize: 12 }}
                        tickLine={false}
                        axisLine={{ stroke: '#e2e8f0' }}
                      />
                      <Tooltip 
                        formatter={(value: number) => [value.toLocaleString(), '']}
                        labelFormatter={(label) => `Date: ${label}`}
                      />
                      <Legend />
                      <Line 
                        type="monotone" 
                        dataKey="activeUsers" 
                        name="Active Users"
                        stroke={getLegendColors()[0]} 
                        strokeWidth={2}
                        dot={false}
                        activeDot={{ r: 6 }}
                      />
                      <Line 
                        type="monotone" 
                        dataKey="sessions" 
                        name="Sessions"
                        stroke={getLegendColors()[1]} 
                        strokeWidth={2}
                        dot={false}
                        activeDot={{ r: 6 }}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                )}
              </div>
            )}

            <div className="mt-6 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <Card>
                <CardContent className="pt-6">
                  <div className="text-sm font-medium text-gray-500">Average</div>
                  <div className="text-2xl font-semibold mt-1">
                    {isLoading ? (
                      <Skeleton className="h-8 w-20" />
                    ) : (
                      metric === 'activeUsers' || metric === 'sessions' ? 
                        Math.round(data.reduce((acc: number, val: any) => acc + val[metric], 0) / data.length).toLocaleString() :
                        `${(data.reduce((acc: number, val: any) => acc + val[metric], 0) / data.length).toFixed(2)}%`
                    )}
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="pt-6">
                  <div className="text-sm font-medium text-gray-500">Maximum</div>
                  <div className="text-2xl font-semibold mt-1">
                    {isLoading ? (
                      <Skeleton className="h-8 w-20" />
                    ) : (
                      metric === 'activeUsers' || metric === 'sessions' ? 
                        Math.max(...data.map((d: any) => d[metric])).toLocaleString() :
                        `${Math.max(...data.map((d: any) => d[metric])).toFixed(2)}%`
                    )}
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="pt-6">
                  <div className="text-sm font-medium text-gray-500">Minimum</div>
                  <div className="text-2xl font-semibold mt-1">
                    {isLoading ? (
                      <Skeleton className="h-8 w-20" />
                    ) : (
                      metric === 'activeUsers' || metric === 'sessions' ? 
                        Math.min(...data.map((d: any) => d[metric])).toLocaleString() :
                        `${Math.min(...data.map((d: any) => d[metric])).toFixed(2)}%`
                    )}
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="pt-6">
                  <div className="text-sm font-medium text-gray-500">Trend</div>
                  <div className="text-2xl font-semibold mt-1 flex items-center">
                    {isLoading ? (
                      <Skeleton className="h-8 w-20" />
                    ) : (
                      <>
                        {data[data.length - 1][metric] > data[0][metric] ? (
                          <span className="text-green-600">+</span>
                        ) : (
                          <span className="text-red-600">-</span>
                        )}
                        {(Math.abs((data[data.length - 1][metric] - data[0][metric]) / data[0][metric] * 100)).toFixed(1)}%
                      </>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>
          </CardContent>
        </Card>
      </div>
    </AppLayout>
  );
}
