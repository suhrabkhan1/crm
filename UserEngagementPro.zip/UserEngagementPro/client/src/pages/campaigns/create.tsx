import React, { useState } from "react";
import { useLocation } from "wouter";
import AppLayout from "@/layout/app-layout";
import Header from "@/components/layout/header";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle,
  CardDescription,
  CardFooter
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useToast } from "@/hooks/use-toast";
import { 
  Tabs, 
  TabsContent, 
  TabsList, 
  TabsTrigger 
} from "@/components/ui/tabs";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { Calendar as CalendarIcon, Bell, Globe, Smartphone, Layout, Mail, MessageSquare, MessageCircle, BookOpen, PlusCircle, UserPlus, X, Info, ChevronRight } from "lucide-react";
import { format } from "date-fns";
import { cn } from "@/lib/utils";
import { queryClient, apiRequest } from "@/lib/queryClient";

const formSchema = z.object({
  name: z.string().min(3, {
    message: "Campaign name must be at least 3 characters.",
  }),
  description: z.string().optional(),
  channel: z.string({
    required_error: "Please select a channel.",
  }),
  targetAudience: z.enum(["all", "segment", "custom"], {
    required_error: "Please select a target audience.",
  }),
  segmentId: z.number().optional(),
  content: z.object({
    title: z.string().min(1, "Title is required"),
    body: z.string().min(1, "Body content is required"),
    imageUrl: z.string().optional(),
    actionUrl: z.string().optional(),
    actionText: z.string().optional(),
  }),
  schedulingType: z.enum(["immediate", "scheduled", "recurring"]),
  scheduledAt: z.date().optional(),
  abtestEnabled: z.boolean().default(false),
});

type FormValues = z.infer<typeof formSchema>;

export default function CreateCampaign() {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const [step, setStep] = useState(1);
  const [previewData, setPreviewData] = useState<any>(null);
  
  // Default values for the form
  const defaultValues: Partial<FormValues> = {
    name: "",
    description: "",
    channel: "",
    targetAudience: "all",
    content: {
      title: "",
      body: "",
      imageUrl: "",
      actionUrl: "",
      actionText: ""
    },
    schedulingType: "immediate",
    abtestEnabled: false
  };
  
  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues,
  });
  
  const onSubmit = async (data: FormValues) => {
    try {
      console.log("Form data on submit:", data);
      
      if (step < 4) {
        // Validate the current step before advancing
        let canProceed = true;
        
        // Step 1: Basic details - validate name and channel
        if (step === 1 && (!data.name || !data.channel)) {
          form.setError("name", { message: "Name is required" });
          form.setError("channel", { message: "Channel is required" });
          canProceed = false;
        }
        
        // Step 2: Target audience - no special validation needed (defaults provided)
        
        // Step 3: Message content - validate title and body
        if (step === 3 && (!data.content.title || !data.content.body)) {
          form.setError("content.title", { message: "Title is required" });
          form.setError("content.body", { message: "Body is required" });
          canProceed = false;
        }
        
        if (canProceed) {
          console.log(`Advancing from step ${step} to ${step+1}`);
          setStep(step + 1);
        }
        return;
      }
      
      // Convert the form data to match the API schema
      const payload = {
        name: data.name,
        description: data.description || "",
        channel: data.channel,
        status: data.schedulingType === "immediate" ? "active" : "scheduled",
        content: data.content,
        filters: data.targetAudience === "all" ? null : { type: data.targetAudience, segmentId: data.segmentId },
        segmentId: data.targetAudience === "segment" ? data.segmentId : null,
        scheduledAt: data.schedulingType === "scheduled" ? data.scheduledAt : null,
        createdBy: 1, // Using dummy user ID
        organizationId: 1 // Using dummy org ID
      };
      
      const response = await apiRequest("POST", "/api/campaigns", payload);
      
      if (response.ok) {
        // Invalidate the campaigns query cache
        queryClient.invalidateQueries({ queryKey: ['/api/campaigns'] });
        
        toast({
          title: "Campaign created successfully",
          description: "Your campaign has been created and is ready to go.",
        });
        
        // Redirect to the campaigns list page
        navigate("/campaigns");
      }
    } catch (error) {
      console.error("Error creating campaign:", error);
      toast({
        title: "Error creating campaign",
        description: "Something went wrong. Please try again.",
        variant: "destructive",
      });
    }
  };
  
  const getChannelIcon = (channel: string) => {
    switch (channel) {
      case 'push':
        return <Bell className="h-5 w-5" />;
      case 'web-push':
        return <Globe className="h-5 w-5" />;
      case 'in-app':
        return <Smartphone className="h-5 w-5" />;
      case 'web-popup':
        return <Layout className="h-5 w-5" />;
      case 'email':
        return <Mail className="h-5 w-5" />;
      case 'sms':
        return <MessageSquare className="h-5 w-5" />;
      case 'whatsapp':
        return <MessageCircle className="h-5 w-5" />;
      default:
        return <Bell className="h-5 w-5" />;
    }
  };
  
  const generatePreview = () => {
    const data = form.getValues();
    setPreviewData({
      ...data,
      content: {
        ...data.content,
        // Add some default values for preview if needed
        imageUrl: data.content.imageUrl || "https://placehold.co/600x400/5046e5/ffffff?text=Campaign+Image"
      }
    });
  };
  
  const renderStepForm = () => {
    switch (step) {
      case 1:
        return (
          <>
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Campaign Name</FormLabel>
                  <FormControl>
                    <Input placeholder="Summer Sale Promotion" {...field} />
                  </FormControl>
                  <FormDescription>
                    Give your campaign a descriptive name.
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Description (Optional)</FormLabel>
                  <FormControl>
                    <Textarea 
                      placeholder="Promote our summer sale to all users" 
                      {...field} 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="channel"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Message Channel</FormLabel>
                  <Select 
                    onValueChange={field.onChange} 
                    defaultValue={field.value}
                  >
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select a channel" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="push">
                        <div className="flex items-center">
                          <Bell className="mr-2 h-4 w-4" />
                          Push Notifications
                        </div>
                      </SelectItem>
                      <SelectItem value="web-push">
                        <div className="flex items-center">
                          <Globe className="mr-2 h-4 w-4" />
                          Web Push
                        </div>
                      </SelectItem>
                      <SelectItem value="in-app">
                        <div className="flex items-center">
                          <Smartphone className="mr-2 h-4 w-4" />
                          In-App
                        </div>
                      </SelectItem>
                      <SelectItem value="web-popup">
                        <div className="flex items-center">
                          <Layout className="mr-2 h-4 w-4" />
                          Web Pop-up
                        </div>
                      </SelectItem>
                      <SelectItem value="email">
                        <div className="flex items-center">
                          <Mail className="mr-2 h-4 w-4" />
                          Email
                        </div>
                      </SelectItem>
                      <SelectItem value="sms">
                        <div className="flex items-center">
                          <MessageSquare className="mr-2 h-4 w-4" />
                          SMS
                        </div>
                      </SelectItem>
                      <SelectItem value="whatsapp">
                        <div className="flex items-center">
                          <MessageCircle className="mr-2 h-4 w-4" />
                          WhatsApp
                        </div>
                      </SelectItem>
                    </SelectContent>
                  </Select>
                  <FormDescription>
                    Choose which channel you want to use for this campaign.
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
          </>
        );
        
      case 2:
        return (
          <>
            <FormField
              control={form.control}
              name="targetAudience"
              render={({ field }) => (
                <FormItem className="space-y-3">
                  <FormLabel>Target Audience</FormLabel>
                  <FormControl>
                    <div className="space-y-2">
                      <div
                        className={cn(
                          "flex items-center justify-between p-4 border rounded-lg cursor-pointer",
                          field.value === "all" && "border-primary bg-primary/5"
                        )}
                        onClick={() => field.onChange("all")}
                      >
                        <div className="flex items-center space-x-3">
                          <div className={cn(
                            "w-5 h-5 rounded-full border-2 flex items-center justify-center",
                            field.value === "all" ? "border-primary" : "border-gray-300"
                          )}>
                            {field.value === "all" && <div className="w-3 h-3 rounded-full bg-primary" />}
                          </div>
                          <div>
                            <h4 className="font-medium">All Users</h4>
                            <p className="text-sm text-gray-500">Send to all users in your app</p>
                          </div>
                        </div>
                        <UserPlus className="h-5 w-5 text-gray-400" />
                      </div>
                      
                      <div
                        className={cn(
                          "flex items-center justify-between p-4 border rounded-lg cursor-pointer",
                          field.value === "segment" && "border-primary bg-primary/5"
                        )}
                        onClick={() => field.onChange("segment")}
                      >
                        <div className="flex items-center space-x-3">
                          <div className={cn(
                            "w-5 h-5 rounded-full border-2 flex items-center justify-center",
                            field.value === "segment" ? "border-primary" : "border-gray-300"
                          )}>
                            {field.value === "segment" && <div className="w-3 h-3 rounded-full bg-primary" />}
                          </div>
                          <div>
                            <h4 className="font-medium">User Segment</h4>
                            <p className="text-sm text-gray-500">Target a specific user segment</p>
                          </div>
                        </div>
                        <BookOpen className="h-5 w-5 text-gray-400" />
                      </div>
                      
                      <div
                        className={cn(
                          "flex items-center justify-between p-4 border rounded-lg cursor-pointer",
                          field.value === "custom" && "border-primary bg-primary/5"
                        )}
                        onClick={() => field.onChange("custom")}
                      >
                        <div className="flex items-center space-x-3">
                          <div className={cn(
                            "w-5 h-5 rounded-full border-2 flex items-center justify-center",
                            field.value === "custom" ? "border-primary" : "border-gray-300"
                          )}>
                            {field.value === "custom" && <div className="w-3 h-3 rounded-full bg-primary" />}
                          </div>
                          <div>
                            <h4 className="font-medium">Custom Filter</h4>
                            <p className="text-sm text-gray-500">Create a custom filter for this campaign</p>
                          </div>
                        </div>
                        <PlusCircle className="h-5 w-5 text-gray-400" />
                      </div>
                    </div>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            {form.watch("targetAudience") === "segment" && (
              <FormField
                control={form.control}
                name="segmentId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Select Segment</FormLabel>
                    <Select 
                      onValueChange={(value) => field.onChange(parseInt(value))} 
                      defaultValue={field.value?.toString()}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select a segment" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="1">Active Power Users</SelectItem>
                        <SelectItem value="2">Inactive (30+ days)</SelectItem>
                        <SelectItem value="3">Cart Abandoners</SelectItem>
                        <SelectItem value="4">Premium Subscribers</SelectItem>
                        <SelectItem value="5">New Users (7 days)</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormDescription>
                      Select a pre-defined segment of users to target.
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
            )}
            
            {form.watch("targetAudience") === "custom" && (
              <div className="p-4 bg-gray-50 rounded-lg space-y-2">
                <div className="flex items-center">
                  <Info className="h-4 w-4 text-blue-500 mr-2" />
                  <p className="text-sm text-gray-600">
                    Advanced filtering options will be available in a future update. 
                  </p>
                </div>
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="text-xs"
                  type="button"
                  onClick={() => navigate("/segments/create")}
                >
                  Create Segment Instead 
                  <ChevronRight className="h-3 w-3 ml-1" />
                </Button>
              </div>
            )}
          </>
        );
        
      case 3:
        return (
          <>
            <FormField
              control={form.control}
              name="content.title"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Message Title</FormLabel>
                  <FormControl>
                    <Input 
                      placeholder="Summer Sale Now Live!" 
                      {...field}
                      onChange={(e) => {
                        field.onChange(e);
                        if (previewData) {
                          setPreviewData({
                            ...previewData,
                            content: {
                              ...previewData.content,
                              title: e.target.value
                            }
                          });
                        }
                      }}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="content.body"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Message Body</FormLabel>
                  <FormControl>
                    <Textarea 
                      placeholder="Get up to 50% off on all summer items until the end of the month!"
                      className="min-h-[100px]"
                      {...field}
                      onChange={(e) => {
                        field.onChange(e);
                        if (previewData) {
                          setPreviewData({
                            ...previewData,
                            content: {
                              ...previewData.content,
                              body: e.target.value
                            }
                          });
                        }
                      }}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="content.imageUrl"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Image URL (Optional)</FormLabel>
                    <FormControl>
                      <Input 
                        placeholder="https://example.com/image.jpg" 
                        {...field}
                        onChange={(e) => {
                          field.onChange(e);
                          if (previewData) {
                            setPreviewData({
                              ...previewData,
                              content: {
                                ...previewData.content,
                                imageUrl: e.target.value
                              }
                            });
                          }
                        }}
                      />
                    </FormControl>
                    <FormDescription>
                      Add an image to make your message more engaging.
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="content.actionUrl"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Action URL (Optional)</FormLabel>
                    <FormControl>
                      <Input 
                        placeholder="https://example.com/sale" 
                        {...field}
                      />
                    </FormControl>
                    <FormDescription>
                      Where should users be directed when they click the message?
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            
            <FormField
              control={form.control}
              name="content.actionText"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Action Button Text (Optional)</FormLabel>
                  <FormControl>
                    <Input 
                      placeholder="Shop Now" 
                      {...field}
                      onChange={(e) => {
                        field.onChange(e);
                        if (previewData) {
                          setPreviewData({
                            ...previewData,
                            content: {
                              ...previewData.content,
                              actionText: e.target.value
                            }
                          });
                        }
                      }}
                    />
                  </FormControl>
                  <FormDescription>
                    Call-to-action text for your message button.
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <Button 
              type="button" 
              variant="outline" 
              className="w-full mt-2"
              onClick={generatePreview}
            >
              Preview Message
            </Button>
          </>
        );
        
      case 4:
        return (
          <>
            <FormField
              control={form.control}
              name="schedulingType"
              render={({ field }) => (
                <FormItem className="space-y-3">
                  <FormLabel>Scheduling</FormLabel>
                  <FormControl>
                    <div className="space-y-2">
                      <div
                        className={cn(
                          "flex items-center justify-between p-4 border rounded-lg cursor-pointer",
                          field.value === "immediate" && "border-primary bg-primary/5"
                        )}
                        onClick={() => field.onChange("immediate")}
                      >
                        <div className="flex items-center space-x-3">
                          <div className={cn(
                            "w-5 h-5 rounded-full border-2 flex items-center justify-center",
                            field.value === "immediate" ? "border-primary" : "border-gray-300"
                          )}>
                            {field.value === "immediate" && <div className="w-3 h-3 rounded-full bg-primary" />}
                          </div>
                          <div>
                            <h4 className="font-medium">Send Immediately</h4>
                            <p className="text-sm text-gray-500">Message will be sent as soon as you create the campaign</p>
                          </div>
                        </div>
                      </div>
                      
                      <div
                        className={cn(
                          "flex items-center justify-between p-4 border rounded-lg cursor-pointer",
                          field.value === "scheduled" && "border-primary bg-primary/5"
                        )}
                        onClick={() => field.onChange("scheduled")}
                      >
                        <div className="flex items-center space-x-3">
                          <div className={cn(
                            "w-5 h-5 rounded-full border-2 flex items-center justify-center",
                            field.value === "scheduled" ? "border-primary" : "border-gray-300"
                          )}>
                            {field.value === "scheduled" && <div className="w-3 h-3 rounded-full bg-primary" />}
                          </div>
                          <div>
                            <h4 className="font-medium">Schedule for Later</h4>
                            <p className="text-sm text-gray-500">Choose a specific date and time to send the message</p>
                          </div>
                        </div>
                      </div>
                      
                      <div
                        className={cn(
                          "flex items-center justify-between p-4 border rounded-lg cursor-pointer",
                          field.value === "recurring" && "border-primary bg-primary/5"
                        )}
                        onClick={() => field.onChange("recurring")}
                      >
                        <div className="flex items-center space-x-3">
                          <div className={cn(
                            "w-5 h-5 rounded-full border-2 flex items-center justify-center",
                            field.value === "recurring" ? "border-primary" : "border-gray-300"
                          )}>
                            {field.value === "recurring" && <div className="w-3 h-3 rounded-full bg-primary" />}
                          </div>
                          <div>
                            <h4 className="font-medium">Recurring Schedule</h4>
                            <p className="text-sm text-gray-500">Set a repeating schedule for this campaign</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            {form.watch("schedulingType") === "scheduled" && (
              <FormField
                control={form.control}
                name="scheduledAt"
                render={({ field }) => (
                  <FormItem className="flex flex-col">
                    <FormLabel>Schedule Date</FormLabel>
                    <Popover>
                      <PopoverTrigger asChild>
                        <FormControl>
                          <Button
                            variant={"outline"}
                            className={cn(
                              "w-full pl-3 text-left font-normal",
                              !field.value && "text-muted-foreground"
                            )}
                          >
                            {field.value ? (
                              format(field.value, "PPP")
                            ) : (
                              <span>Pick a date</span>
                            )}
                            <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                          </Button>
                        </FormControl>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <Calendar
                          mode="single"
                          selected={field.value}
                          onSelect={field.onChange}
                          initialFocus
                        />
                      </PopoverContent>
                    </Popover>
                    <FormDescription>
                      When should this campaign be sent?
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
            )}
            
            {form.watch("schedulingType") === "recurring" && (
              <div className="p-4 bg-gray-50 rounded-lg space-y-2">
                <div className="flex items-center">
                  <Info className="h-4 w-4 text-blue-500 mr-2" />
                  <p className="text-sm text-gray-600">
                    Recurring campaign scheduling will be available in a future update.
                  </p>
                </div>
              </div>
            )}
            
            <FormField
              control={form.control}
              name="abtestEnabled"
              render={({ field }) => (
                <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4">
                  <FormControl>
                    <div className={cn(
                      "w-5 h-5 rounded border-2 flex items-center justify-center cursor-pointer",
                      field.value ? "border-primary bg-primary/10" : "border-gray-300"
                    )}
                    onClick={() => field.onChange(!field.value)}
                    >
                      {field.value && (
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" className="h-4 w-4 text-primary">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                        </svg>
                      )}
                    </div>
                  </FormControl>
                  <div className="space-y-1 leading-none">
                    <FormLabel>
                      Enable A/B Testing
                    </FormLabel>
                    <FormDescription>
                      Test different variations of your message to optimize performance.
                    </FormDescription>
                  </div>
                </FormItem>
              )}
            />
            
            {form.watch("abtestEnabled") && (
              <div className="p-4 bg-gray-50 rounded-lg space-y-2">
                <div className="flex items-center">
                  <Info className="h-4 w-4 text-blue-500 mr-2" />
                  <p className="text-sm text-gray-600">
                    A/B testing configuration will be available in a future update.
                  </p>
                </div>
              </div>
            )}
          </>
        );
        
      default:
        return <p>Unknown step</p>;
    }
  };
  
  const renderStepDescription = () => {
    switch (step) {
      case 1:
        return "Basic information about your campaign";
      case 2:
        return "Choose who should receive your message";
      case 3:
        return "Design your message content";
      case 4:
        return "Set when your campaign should be sent";
      default:
        return "";
    }
  };
  
  return (
    <AppLayout>
      <div className="pb-12">
        <Header 
          title="Create Campaign" 
          description="Create a new campaign to engage with your users"
          showDateRangePicker={false}
        />
        
        <div className="mx-auto px-4 sm:px-6 lg:px-8 max-w-7xl mt-8">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6">
            <div>
              <h3 className="text-lg font-medium">Step {step} of 4: {renderStepDescription()}</h3>
              <p className="text-sm text-gray-500">{renderStepDescription()}</p>
            </div>
            <div className="flex items-center space-x-2">
              <div className="flex items-center">
                {Array.from({ length: 4 }).map((_, i) => (
                  <div key={i} className="flex items-center">
                    <div
                      className={cn(
                        "flex items-center justify-center rounded-full h-6 w-6 text-xs",
                        step > i
                          ? "bg-primary text-white"
                          : step === i + 1
                          ? "border-2 border-primary text-primary"
                          : "border border-gray-300 text-gray-400"
                      )}
                    >
                      {i + 1}
                    </div>
                    {i < 3 && (
                      <div
                        className={cn(
                          "h-px w-8",
                          step > i + 1 ? "bg-primary" : "bg-gray-300"
                        )}
                      />
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2">
              <Card>
                <CardContent className="pt-6">
                  <Form {...form}>
                    <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                      {renderStepForm()}
                      
                      <div className="flex justify-between pt-4 border-t">
                        <Button
                          type="button"
                          variant="outline"
                          onClick={() => step > 1 && setStep(step - 1)}
                          disabled={step === 1}
                        >
                          Back
                        </Button>
                        <Button type="submit">
                          {step < 4 ? 'Continue' : 'Create Campaign'}
                        </Button>
                      </div>
                    </form>
                  </Form>
                </CardContent>
              </Card>
            </div>
            
            <div>
              <Card>
                <CardHeader>
                  <CardTitle>Preview</CardTitle>
                  <CardDescription>
                    How your message will appear to users
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {previewData ? (
                    <div className="space-y-4">
                      <div className="bg-gray-100 p-4 rounded-lg">
                        {previewData.channel === 'push' && (
                          <div className="border border-gray-300 rounded-lg bg-white shadow-sm overflow-hidden">
                            <div className="flex items-center justify-between p-2 bg-gray-800 text-white text-xs">
                              <div>Your App</div>
                              <div>Just now</div>
                            </div>
                            <div className="p-3">
                              <h4 className="font-medium text-sm">{previewData.content.title}</h4>
                              <p className="text-xs text-gray-700 mt-1">{previewData.content.body}</p>
                            </div>
                            {previewData.content.imageUrl && (
                              <img 
                                src={previewData.content.imageUrl} 
                                alt="Preview" 
                                className="w-full h-32 object-cover"
                              />
                            )}
                          </div>
                        )}
                        
                        {previewData.channel === 'in-app' && (
                          <div className="border border-gray-300 rounded-lg bg-white shadow-sm overflow-hidden">
                            <div className="p-3">
                              <div className="flex justify-between items-start">
                                <h4 className="font-medium">{previewData.content.title}</h4>
                                <button className="text-gray-400 hover:text-gray-600">
                                  <X className="h-4 w-4" />
                                </button>
                              </div>
                              <p className="text-sm text-gray-700 mt-1">{previewData.content.body}</p>
                              {previewData.content.imageUrl && (
                                <img 
                                  src={previewData.content.imageUrl} 
                                  alt="Preview" 
                                  className="w-full h-40 object-cover mt-2 rounded"
                                />
                              )}
                              {previewData.content.actionText && (
                                <button className="mt-3 w-full px-4 py-2 bg-primary text-white rounded text-sm">
                                  {previewData.content.actionText}
                                </button>
                              )}
                            </div>
                          </div>
                        )}
                        
                        {previewData.channel === 'email' && (
                          <div className="border border-gray-300 rounded-lg bg-white shadow-sm overflow-hidden">
                            <div className="flex items-center justify-between p-2 bg-gray-100 text-xs">
                              <div>From: Your Company</div>
                              <div>Today</div>
                            </div>
                            <div className="p-3">
                              <h4 className="font-medium">{previewData.content.title}</h4>
                              <div className="text-sm text-gray-700 mt-2 space-y-2">
                                <p>{previewData.content.body}</p>
                                {previewData.content.imageUrl && (
                                  <img 
                                    src={previewData.content.imageUrl} 
                                    alt="Preview" 
                                    className="w-full h-40 object-cover mt-2 rounded"
                                  />
                                )}
                                {previewData.content.actionText && (
                                  <div className="pt-2">
                                    <button className="px-4 py-2 bg-primary text-white rounded text-sm">
                                      {previewData.content.actionText}
                                    </button>
                                  </div>
                                )}
                              </div>
                            </div>
                          </div>
                        )}
                        
                        {['web-push', 'web-popup', 'sms', 'whatsapp'].includes(previewData.channel) && (
                          <div className="text-sm text-center text-gray-500 py-4">
                            Preview available after content creation
                          </div>
                        )}
                      </div>
                      
                      <div className="bg-gray-50 p-3 rounded-md">
                        <h5 className="text-xs font-medium uppercase text-gray-500 mb-2">Channel</h5>
                        <div className="flex items-center">
                          {getChannelIcon(previewData.channel)}
                          <span className="ml-2 capitalize">{previewData.channel.replace('-', ' ')}</span>
                        </div>
                      </div>
                      
                      <div className="text-xs text-gray-500">
                        Note: Actual appearance may vary based on user's device and settings.
                      </div>
                    </div>
                  ) : (
                    <div className="flex flex-col items-center justify-center h-64 text-center">
                      <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mb-4">
                        <Bell className="h-8 w-8 text-gray-400" />
                      </div>
                      <h3 className="text-lg font-medium text-gray-700 mb-1">No Preview Available</h3>
                      <p className="text-sm text-gray-500 max-w-xs">
                        Complete the campaign details and click "Preview Message" to see how your message will look.
                      </p>
                    </div>
                  )}
                </CardContent>
                <CardFooter className="border-t bg-gray-50 flex justify-center">
                  <Button 
                    variant="link" 
                    className="text-xs"
                    onClick={generatePreview}
                  >
                    Refresh Preview
                  </Button>
                </CardFooter>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </AppLayout>
  );
}