import React, { useState } from "react";
import AppLayout from "@/layout/app-layout";
import Header from "@/components/layout/header";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle,
  CardDescription,
  CardFooter 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";
import { Skeleton } from "@/components/ui/skeleton";
import { DataTable } from "@/components/ui/data-table";
import { Link } from "wouter";
import { getStatusColor, formatNumber } from "@/lib/utils";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { 
  Bell, 
  Globe, 
  Smartphone, 
  Layout, 
  Mail, 
  MessageSquare, 
  MessageCircle,
  Calendar,
  Edit,
  Copy,
  Trash,
  ArrowUpRight,
  Clock,
  BarChart,
  Eye 
} from "lucide-react";
import { formatDateShort } from "@/lib/dates";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

interface Campaign {
  id: number;
  name: string;
  description: string;
  channel: string;
  status: string;
  content: any;
  createdAt: string;
  scheduledAt: string | null;
  stats?: {
    sent: number;
    delivered: number;
    opened: number;
    clicked: number;
    converted: number;
  };
}

export default function Campaigns() {
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [channelFilter, setChannelFilter] = useState<string>("all");
  
  const { data: campaigns, isLoading, refetch } = useQuery<Campaign[]>({
    queryKey: ['/api/campaigns', statusFilter, channelFilter],
  });

  const getChannelIcon = (channel: string) => {
    switch (channel.toLowerCase()) {
      case 'push':
        return <Bell className="h-4 w-4" />;
      case 'web-push':
        return <Globe className="h-4 w-4" />;
      case 'in-app':
        return <Smartphone className="h-4 w-4" />;
      case 'web-popup':
        return <Layout className="h-4 w-4" />;
      case 'email':
        return <Mail className="h-4 w-4" />;
      case 'sms':
        return <MessageSquare className="h-4 w-4" />;
      case 'whatsapp':
        return <MessageCircle className="h-4 w-4" />;
      default:
        return <Bell className="h-4 w-4" />;
    }
  };

  const filteredCampaigns = campaigns?.filter(campaign => {
    if (statusFilter !== "all" && campaign.status !== statusFilter) return false;
    if (channelFilter !== "all" && campaign.channel !== channelFilter) return false;
    return true;
  });

  const columns = [
    {
      accessorKey: "name",
      header: "Campaign Name",
      cell: ({ row }: any) => (
        <div className="flex items-start gap-3">
          <div className="flex h-9 w-9 items-center justify-center rounded-md bg-gray-100">
            {getChannelIcon(row.original.channel)}
          </div>
          <div>
            <div className="font-medium">{row.getValue("name")}</div>
            <div className="text-sm text-gray-500 truncate max-w-[300px]">{row.original.description}</div>
          </div>
        </div>
      ),
    },
    {
      accessorKey: "channel",
      header: "Channel",
      cell: ({ row }: any) => (
        <div className="flex items-center gap-2">
          {getChannelIcon(row.getValue("channel"))}
          <span className="capitalize">{row.getValue("channel")}</span>
        </div>
      ),
    },
    {
      accessorKey: "status",
      header: "Status",
      cell: ({ row }: any) => (
        <div className={`w-fit px-2 py-1 text-xs rounded-full ${getStatusColor(row.getValue("status"))}`}>
          {row.getValue("status").charAt(0).toUpperCase() + row.getValue("status").slice(1)}
        </div>
      ),
    },
    {
      accessorKey: "scheduledAt",
      header: "Scheduled",
      cell: ({ row }: any) => {
        const scheduledAt = row.getValue("scheduledAt");
        return scheduledAt ? (
          <div className="flex items-center gap-1">
            <Calendar className="h-3 w-3 text-gray-500" />
            <span>{formatDateShort(scheduledAt)}</span>
          </div>
        ) : (
          <span className="text-gray-500">-</span>
        );
      },
    },
    {
      accessorKey: "stats",
      header: "Performance",
      cell: ({ row }: any) => {
        const stats = row.original.stats;
        if (!stats || row.original.status === 'scheduled' || row.original.status === 'draft') {
          return <span className="text-gray-500">-</span>;
        }
        
        return (
          <div className="space-y-1">
            <div className="h-1.5 w-full bg-gray-100 rounded-full overflow-hidden">
              <div 
                className="h-full bg-primary-600 rounded-full" 
                style={{ width: `${(stats.opened / stats.delivered * 100).toFixed(1)}%` }}
              ></div>
            </div>
            <div className="flex justify-between text-xs text-gray-500">
              <span>Opened: {(stats.opened / stats.delivered * 100).toFixed(1)}%</span>
              <span>CTR: {(stats.clicked / stats.delivered * 100).toFixed(1)}%</span>
            </div>
          </div>
        );
      },
    },
    {
      id: "actions",
      cell: ({ row }: any) => (
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" className="h-8 w-8 p-0">
              <span className="sr-only">Open menu</span>
              <div className="flex h-8 w-8 items-center justify-center">
                <div className="h-1 w-1 rounded-full bg-gray-500"></div>
                <div className="h-1 w-1 rounded-full bg-gray-500 ml-0.5"></div>
                <div className="h-1 w-1 rounded-full bg-gray-500 ml-0.5"></div>
              </div>
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuLabel>Actions</DropdownMenuLabel>
            <DropdownMenuItem 
              onClick={() => window.location.href = `/campaigns/${row.original.id}`}
              className="cursor-pointer"
            >
              <Eye className="mr-2 h-4 w-4" />
              View
            </DropdownMenuItem>
            <DropdownMenuItem 
              onClick={() => window.location.href = `/campaigns/${row.original.id}/edit`}
              className="cursor-pointer"
            >
              <Edit className="mr-2 h-4 w-4" />
              Edit
            </DropdownMenuItem>
            <DropdownMenuItem className="cursor-pointer">
              <Copy className="mr-2 h-4 w-4" />
              Duplicate
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <DropdownMenuItem 
                  onSelect={(e) => e.preventDefault()}
                  className="text-red-600 cursor-pointer"
                >
                  <Trash className="mr-2 h-4 w-4" />
                  Delete
                </DropdownMenuItem>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
                  <AlertDialogDescription>
                    This action cannot be undone. This will permanently delete the campaign
                    "{row.original.name}" and all of its data.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>Cancel</AlertDialogCancel>
                  <AlertDialogAction className="bg-red-600">Delete</AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          </DropdownMenuContent>
        </DropdownMenu>
      ),
    },
  ];
  
  // Quick stats for the overview
  const stats = {
    active: campaigns?.filter(c => c.status === 'active').length || 0,
    scheduled: campaigns?.filter(c => c.status === 'scheduled').length || 0,
    completed: campaigns?.filter(c => c.status === 'completed').length || 0,
    draft: campaigns?.filter(c => c.status === 'draft').length || 0,
  };

  return (
    <AppLayout>
      <Header 
        title="Campaigns" 
        description="Create and manage multi-channel communication campaigns"
        actionButton={{
          label: "Create Campaign",
          href: "/campaigns/create",
        }}
      />

      <div className="py-6 px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <Card className={statusFilter === 'all' ? 'ring-2 ring-primary-500 ring-offset-2' : ''}>
            <CardContent className="pt-6">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-500">All Campaigns</p>
                  <h3 className="text-2xl font-semibold mt-1">{campaigns?.length || 0}</h3>
                </div>
                <div className="p-2 bg-blue-100 rounded-full">
                  <BarChart className="h-5 w-5 text-blue-600" />
                </div>
              </div>
              <Button 
                variant="ghost" 
                size="sm" 
                className="mt-2 w-full justify-start text-primary-600"
                onClick={() => setStatusFilter('all')}
              >
                View all
              </Button>
            </CardContent>
          </Card>
          
          <Card className={statusFilter === 'active' ? 'ring-2 ring-primary-500 ring-offset-2' : ''}>
            <CardContent className="pt-6">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-500">Active</p>
                  <h3 className="text-2xl font-semibold mt-1">{stats.active}</h3>
                </div>
                <div className="p-2 bg-green-100 rounded-full">
                  <ArrowUpRight className="h-5 w-5 text-green-600" />
                </div>
              </div>
              <Button 
                variant="ghost" 
                size="sm" 
                className="mt-2 w-full justify-start text-primary-600"
                onClick={() => setStatusFilter('active')}
              >
                View active
              </Button>
            </CardContent>
          </Card>
          
          <Card className={statusFilter === 'scheduled' ? 'ring-2 ring-primary-500 ring-offset-2' : ''}>
            <CardContent className="pt-6">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-500">Scheduled</p>
                  <h3 className="text-2xl font-semibold mt-1">{stats.scheduled}</h3>
                </div>
                <div className="p-2 bg-amber-100 rounded-full">
                  <Clock className="h-5 w-5 text-amber-600" />
                </div>
              </div>
              <Button 
                variant="ghost" 
                size="sm" 
                className="mt-2 w-full justify-start text-primary-600"
                onClick={() => setStatusFilter('scheduled')}
              >
                View scheduled
              </Button>
            </CardContent>
          </Card>
          
          <Card className={statusFilter === 'completed' ? 'ring-2 ring-primary-500 ring-offset-2' : ''}>
            <CardContent className="pt-6">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-500">Completed</p>
                  <h3 className="text-2xl font-semibold mt-1">{stats.completed}</h3>
                </div>
                <div className="p-2 bg-purple-100 rounded-full">
                  <Eye className="h-5 w-5 text-purple-600" />
                </div>
              </div>
              <Button 
                variant="ghost" 
                size="sm" 
                className="mt-2 w-full justify-start text-primary-600"
                onClick={() => setStatusFilter('completed')}
              >
                View completed
              </Button>
            </CardContent>
          </Card>
        </div>
        
        <Card>
          <CardHeader>
            <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center space-y-2 sm:space-y-0">
              <div>
                <CardTitle>Campaign Management</CardTitle>
                <CardDescription>
                  View and manage all your messaging campaigns
                </CardDescription>
              </div>
              <div className="flex items-center gap-2">
                <Select
                  value={channelFilter}
                  onValueChange={setChannelFilter}
                >
                  <SelectTrigger className="w-[160px]">
                    <SelectValue placeholder="Filter by channel" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Channels</SelectItem>
                    <SelectItem value="push">Push Notifications</SelectItem>
                    <SelectItem value="web-push">Web Push</SelectItem>
                    <SelectItem value="in-app">In-App</SelectItem>
                    <SelectItem value="web-popup">Web Pop-up</SelectItem>
                    <SelectItem value="email">Email</SelectItem>
                    <SelectItem value="sms">SMS</SelectItem>
                    <SelectItem value="whatsapp">WhatsApp</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="space-y-4">
                <Skeleton className="h-10 w-full" />
                <Skeleton className="h-32 w-full" />
                <Skeleton className="h-10 w-full" />
              </div>
            ) : (
              <DataTable 
                columns={columns}
                data={filteredCampaigns || []}
                searchColumn="name"
                searchPlaceholder="Search campaigns..."
              />
            )}
          </CardContent>
        </Card>
      </div>
    </AppLayout>
  );
}
