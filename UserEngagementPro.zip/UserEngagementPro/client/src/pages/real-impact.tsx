import React, { useState } from "react";
import AppLayout from "@/layout/app-layout";
import Header from "@/components/layout/header";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle,
  CardDescription 
} from "@/components/ui/card";
import { 
  Tabs, 
  TabsContent, 
  TabsList, 
  TabsTrigger 
} from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useQuery } from "@tanstack/react-query";
import { Skeleton } from "@/components/ui/skeleton";
import { 
  PieChart, 
  Pie, 
  BarChart,
  Bar,
  LineChart,
  Line,
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer,
  Cell
} from 'recharts';
import { Download, Calendar } from "lucide-react";
import { getLegendColors } from "@/lib/charts";

export default function RealImpact() {
  const [metric, setMetric] = useState<string>("revenue");
  const [campaign, setCampaign] = useState<string>("all");
  const [period, setPeriod] = useState<string>("last30days");
  
  const { data, isLoading } = useQuery({
    queryKey: ['/api/analytics/real-impact', campaign, metric, period],
  });

  // Sample data for visualization
  const revenueData = [
    { name: 'Jun 1', revenue: 1200, baseline: 980 },
    { name: 'Jun 5', revenue: 1350, baseline: 1020 },
    { name: 'Jun 10', revenue: 1500, baseline: 1100 },
    { name: 'Jun 15', revenue: 1750, baseline: 1150 },
    { name: 'Jun 20', revenue: 1840, baseline: 1230 },
    { name: 'Jun 25', revenue: 2100, baseline: 1300 },
    { name: 'Jun 30', revenue: 2400, baseline: 1350 }
  ];

  const retentionData = [
    { name: 'Jun 1', retention: 84, baseline: 72 },
    { name: 'Jun 5', retention: 86, baseline: 73 },
    { name: 'Jun 10', retention: 85, baseline: 74 },
    { name: 'Jun 15', retention: 87, baseline: 75 },
    { name: 'Jun 20', retention: 89, baseline: 74 },
    { name: 'Jun 25', retention: 92, baseline: 76 },
    { name: 'Jun 30', retention: 93, baseline: 77 }
  ];

  const conversionData = [
    { name: 'Jun 1', conversion: 3.2, baseline: 2.7 },
    { name: 'Jun 5', conversion: 3.4, baseline: 2.8 },
    { name: 'Jun 10', conversion: 3.6, baseline: 2.9 },
    { name: 'Jun 15', conversion: 3.8, baseline: 3.0 },
    { name: 'Jun 20', conversion: 4.1, baseline: 3.1 },
    { name: 'Jun 25', conversion: 4.3, baseline: 3.2 },
    { name: 'Jun 30', conversion: 4.5, baseline: 3.2 }
  ];

  const getChartData = () => {
    switch(metric) {
      case 'revenue': return revenueData;
      case 'retention': return retentionData;
      case 'conversion': return conversionData;
      default: return revenueData;
    }
  };

  const getMetricTitle = () => {
    switch(metric) {
      case 'revenue': return 'Revenue';
      case 'retention': return 'Retention Rate';
      case 'conversion': return 'Conversion Rate';
      default: return 'Revenue';
    }
  };

  const formatYAxisTick = (value: number) => {
    if (metric === 'revenue') {
      return `$${value}`;
    } else if (metric === 'retention' || metric === 'conversion') {
      return `${value}%`;
    }
    return value;
  };

  const chartData = getChartData();
  const campaignPerformance = [
    { name: 'Summer Sale', value: 45 },
    { name: 'New Feature', value: 25 },
    { name: 'Re-engagement', value: 15 },
    { name: 'Premium Upgrade', value: 10 },
    { name: 'App Update', value: 5 }
  ];

  const revenueByChannel = [
    { name: 'Push', value: 4200 },
    { name: 'Email', value: 3600 },
    { name: 'In-App', value: 2900 },
    { name: 'SMS', value: 1800 },
    { name: 'WhatsApp', value: 1200 }
  ];

  return (
    <AppLayout>
      <Header 
        title="Real Impact" 
        description="Measure the true business impact of your marketing campaigns"
      />

      <div className="py-6 px-4 sm:px-6 lg:px-8">
        <Card className="mb-6">
          <CardHeader>
            <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center space-y-2 sm:space-y-0">
              <div>
                <CardTitle>Campaign Impact</CardTitle>
                <CardDescription>
                  Quantify how your campaigns drive business metrics
                </CardDescription>
              </div>
              <div className="flex flex-wrap gap-2">
                <Select
                  value={metric}
                  onValueChange={setMetric}
                >
                  <SelectTrigger className="w-[140px]">
                    <SelectValue placeholder="Select metric" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="revenue">Revenue</SelectItem>
                    <SelectItem value="retention">Retention</SelectItem>
                    <SelectItem value="conversion">Conversion</SelectItem>
                  </SelectContent>
                </Select>
                
                <Select
                  value={campaign}
                  onValueChange={setCampaign}
                >
                  <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="Select campaign" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Campaigns</SelectItem>
                    <SelectItem value="summer_sale">Summer Sale</SelectItem>
                    <SelectItem value="new_feature">New Feature</SelectItem>
                    <SelectItem value="reengagement">Re-engagement</SelectItem>
                    <SelectItem value="premium_upgrade">Premium Upgrade</SelectItem>
                  </SelectContent>
                </Select>
                
                <Select
                  value={period}
                  onValueChange={setPeriod}
                >
                  <SelectTrigger className="w-[160px]">
                    <SelectValue placeholder="Select period" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="last7days">Last 7 days</SelectItem>
                    <SelectItem value="last30days">Last 30 days</SelectItem>
                    <SelectItem value="last90days">Last 90 days</SelectItem>
                    <SelectItem value="ytd">Year to date</SelectItem>
                  </SelectContent>
                </Select>
                
                <Button variant="outline" size="icon">
                  <Download className="h-4 w-4" />
                  <span className="sr-only">Download</span>
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <Skeleton className="h-[400px] w-full" />
            ) : (
              <div className="h-[400px]">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart
                    data={chartData}
                    margin={{
                      top: 20,
                      right: 30,
                      left: 20,
                      bottom: 20,
                    }}
                  >
                    <CartesianGrid strokeDasharray="3 3" vertical={false} opacity={0.2} />
                    <XAxis 
                      dataKey="name" 
                      tick={{ fontSize: 12 }}
                      tickLine={false}
                      axisLine={{ stroke: '#e2e8f0' }}
                    />
                    <YAxis 
                      tickFormatter={formatYAxisTick}
                      tick={{ fontSize: 12 }}
                      tickLine={false}
                      axisLine={{ stroke: '#e2e8f0' }}
                    />
                    <Tooltip 
                      formatter={(value: number) => [
                        metric === 'revenue' ? `$${value}` : `${value}%`,
                        ''
                      ]}
                      labelFormatter={(label) => `Date: ${label}`}
                    />
                    <Legend />
                    <Line 
                      type="monotone" 
                      dataKey={metric} 
                      name={`With Campaigns (${getMetricTitle()})`}
                      stroke={getLegendColors()[0]} 
                      strokeWidth={2}
                      dot={false}
                      activeDot={{ r: 6 }}
                    />
                    <Line 
                      type="monotone" 
                      dataKey="baseline" 
                      name={`Baseline (No Campaigns)`}
                      stroke="#94a3b8" 
                      strokeWidth={2}
                      strokeDasharray="4 4"
                      dot={false}
                      activeDot={{ r: 6 }}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            )}

            <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-4">
              <Card>
                <CardContent className="pt-6">
                  <div className="text-sm font-medium text-gray-500">Lift Over Baseline</div>
                  <div className="text-2xl font-semibold mt-1 text-green-600">
                    {metric === 'revenue' ? '+$850' : '+16%'}
                  </div>
                  <div className="text-sm text-gray-500 mt-1">
                    {period === 'last30days' ? 'Last 30 days' : 'Selected period'}
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="pt-6">
                  <div className="text-sm font-medium text-gray-500">ROI</div>
                  <div className="text-2xl font-semibold mt-1">
                    425%
                  </div>
                  <div className="text-sm text-gray-500 mt-1">
                    {campaign === 'all' ? 'All campaigns' : campaign.replace('_', ' ')}
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="pt-6">
                  <div className="text-sm font-medium text-gray-500">Incremental Gain</div>
                  <div className="text-2xl font-semibold mt-1">
                    {metric === 'revenue' ? '$42,500' : metric === 'retention' ? '4,250 users' : '1,875 conversions'}
                  </div>
                  <div className="text-sm text-gray-500 mt-1">
                    Attributed to campaigns
                  </div>
                </CardContent>
              </Card>
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Campaign Performance</CardTitle>
              <CardDescription>
                Impact contribution by campaign
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={campaignPerformance}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                      outerRadius={120}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      {campaignPerformance.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={`hsl(${(index * 30 + 240) % 360}, 70%, 60%)`} />
                      ))}
                    </Pie>
                    <Tooltip formatter={(value) => `${value}%`} />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Channel Impact</CardTitle>
              <CardDescription>
                {metric === 'revenue' ? 'Revenue generated' : metric === 'retention' ? 'User retention' : 'Conversions'} by channel
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={revenueByChannel}
                    layout="vertical"
                    margin={{
                      top: 20,
                      right: 30,
                      left: 60,
                      bottom: 5,
                    }}
                  >
                    <CartesianGrid strokeDasharray="3 3" horizontal={true} vertical={false} />
                    <XAxis
                      type="number"
                      tickFormatter={(value) => metric === 'revenue' ? `$${value}` : value.toString()}
                    />
                    <YAxis
                      dataKey="name"
                      type="category"
                      tick={{ fontSize: 12 }}
                    />
                    <Tooltip
                      formatter={(value) => [
                        metric === 'revenue' ? `$${value}` : value.toString(),
                        'Value'
                      ]}
                    />
                    <Bar
                      dataKey="value"
                      name={metric === 'revenue' ? 'Revenue' : metric === 'retention' ? 'Retention' : 'Conversion'}
                      fill="#5046e5"
                      radius={[0, 4, 4, 0]}
                    />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </AppLayout>
  );
}
