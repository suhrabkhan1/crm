import React, { useState } from "react";
import AppLayout from "@/layout/app-layout";
import Header from "@/components/layout/header";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle,
  CardDescription 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";
import { Skeleton } from "@/components/ui/skeleton";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Download, Settings, PlusCircle } from "lucide-react";

export default function Flows() {
  const [flowType, setFlowType] = useState<string>("event");
  const [timeRange, setTimeRange] = useState<string>("last30days");
  
  // In a real app, we would fetch from API based on the selected flow type and time range
  const { data, isLoading } = useQuery({
    queryKey: ['/api/analytics/flows', flowType, timeRange],
    queryFn: () => Promise.resolve(null)
  });

  return (
    <AppLayout>
      <Header 
        title="User Flows" 
        description="Analyze how users navigate through your application"
      />

      <div className="py-6 px-4 sm:px-6 lg:px-8">
        <Card className="mb-6">
          <CardHeader>
            <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center space-y-2 sm:space-y-0">
              <div>
                <CardTitle>Flow Analysis</CardTitle>
                <CardDescription>
                  Visualize the paths users take through your application
                </CardDescription>
              </div>
              <div className="flex flex-wrap gap-2">
                <Button variant="outline" size="sm">
                  <Download className="h-4 w-4 mr-2" />
                  Export Flow
                </Button>
                <Button variant="outline" size="sm">
                  <Settings className="h-4 w-4 mr-2" />
                  Settings
                </Button>
                <Button size="sm">
                  <PlusCircle className="h-4 w-4 mr-2" />
                  New Flow
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center space-y-2 sm:space-y-0 mb-6">
              <Tabs value={flowType} onValueChange={setFlowType}>
                <TabsList>
                  <TabsTrigger value="event">Event Flow</TabsTrigger>
                  <TabsTrigger value="screen">Screen Flow</TabsTrigger>
                  <TabsTrigger value="funnel">Funnel Flow</TabsTrigger>
                </TabsList>
              </Tabs>
              
              <Select
                value={timeRange}
                onValueChange={setTimeRange}
              >
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Select time range" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="today">Today</SelectItem>
                  <SelectItem value="yesterday">Yesterday</SelectItem>
                  <SelectItem value="last7days">Last 7 days</SelectItem>
                  <SelectItem value="last30days">Last 30 days</SelectItem>
                  <SelectItem value="thisMonth">This Month</SelectItem>
                  <SelectItem value="lastMonth">Last Month</SelectItem>
                  <SelectItem value="custom">Custom Range</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            {isLoading ? (
              <Skeleton className="h-[500px] w-full" />
            ) : (
              <div className="h-[500px] bg-gray-50 border-2 border-dashed border-gray-200 rounded-lg flex items-center justify-center">
                <div className="text-center max-w-md p-6">
                  <h3 className="text-lg font-medium text-gray-900 mb-2">No Flow Data Available</h3>
                  <p className="text-gray-500 mb-4">
                    To use Flows, you need to track events in your application. Set up tracking for user actions like screen views, button clicks, and form submissions.
                  </p>
                  <Button>
                    <PlusCircle className="h-4 w-4 mr-2" />
                    Create Your First Flow
                  </Button>
                </div>
              </div>
            )}
            
            <div className="mt-6">
              <h3 className="text-sm font-medium text-gray-900 mb-2">How to use Flows:</h3>
              <ul className="list-disc list-inside text-sm text-gray-600 space-y-1">
                <li>Event Flow: See the series of events users trigger in sequence</li>
                <li>Screen Flow: Track the navigation paths between screens and pages</li>
                <li>Funnel Flow: Analyze conversion paths through your defined funnels</li>
                <li>Use the tools to drill down into specific segments or time periods</li>
              </ul>
            </div>
          </CardContent>
        </Card>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Popular Paths</CardTitle>
              <CardDescription>
                Most common user journeys through your application
              </CardDescription>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <Skeleton className="h-[200px] w-full" />
              ) : (
                <div className="space-y-4">
                  <div className="p-4 bg-gray-50 rounded-lg">
                    <p className="font-medium text-sm text-gray-900 mb-2">Home → Search → Product → Cart → Checkout</p>
                    <div className="flex items-center">
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div className="bg-primary-600 h-2 rounded-full" style={{ width: '42%' }}></div>
                      </div>
                      <span className="ml-2 text-sm text-gray-600">42%</span>
                    </div>
                  </div>
                  
                  <div className="p-4 bg-gray-50 rounded-lg">
                    <p className="font-medium text-sm text-gray-900 mb-2">Home → Categories → Product → Cart</p>
                    <div className="flex items-center">
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div className="bg-primary-600 h-2 rounded-full" style={{ width: '27%' }}></div>
                      </div>
                      <span className="ml-2 text-sm text-gray-600">27%</span>
                    </div>
                  </div>
                  
                  <div className="p-4 bg-gray-50 rounded-lg">
                    <p className="font-medium text-sm text-gray-900 mb-2">Home → Profile → Settings → Logout</p>
                    <div className="flex items-center">
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div className="bg-primary-600 h-2 rounded-full" style={{ width: '18%' }}></div>
                      </div>
                      <span className="ml-2 text-sm text-gray-600">18%</span>
                    </div>
                  </div>
                  
                  <div className="p-4 bg-gray-50 rounded-lg">
                    <p className="font-medium text-sm text-gray-900 mb-2">Home → Notifications → Message → Profile</p>
                    <div className="flex items-center">
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div className="bg-primary-600 h-2 rounded-full" style={{ width: '13%' }}></div>
                      </div>
                      <span className="ml-2 text-sm text-gray-600">13%</span>
                    </div>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Exit Points</CardTitle>
              <CardDescription>
                Where users most commonly exit your application
              </CardDescription>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <Skeleton className="h-[200px] w-full" />
              ) : (
                <div className="space-y-4">
                  <div className="p-4 bg-gray-50 rounded-lg">
                    <p className="font-medium text-sm text-gray-900 mb-2">Checkout Payment Screen</p>
                    <div className="flex items-center">
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div className="bg-red-500 h-2 rounded-full" style={{ width: '35%' }}></div>
                      </div>
                      <span className="ml-2 text-sm text-gray-600">35%</span>
                    </div>
                  </div>
                  
                  <div className="p-4 bg-gray-50 rounded-lg">
                    <p className="font-medium text-sm text-gray-900 mb-2">Product Detail Page</p>
                    <div className="flex items-center">
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div className="bg-red-500 h-2 rounded-full" style={{ width: '22%' }}></div>
                      </div>
                      <span className="ml-2 text-sm text-gray-600">22%</span>
                    </div>
                  </div>
                  
                  <div className="p-4 bg-gray-50 rounded-lg">
                    <p className="font-medium text-sm text-gray-900 mb-2">Search Results</p>
                    <div className="flex items-center">
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div className="bg-red-500 h-2 rounded-full" style={{ width: '18%' }}></div>
                      </div>
                      <span className="ml-2 text-sm text-gray-600">18%</span>
                    </div>
                  </div>
                  
                  <div className="p-4 bg-gray-50 rounded-lg">
                    <p className="font-medium text-sm text-gray-900 mb-2">Shopping Cart</p>
                    <div className="flex items-center">
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div className="bg-red-500 h-2 rounded-full" style={{ width: '15%' }}></div>
                      </div>
                      <span className="ml-2 text-sm text-gray-600">15%</span>
                    </div>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </AppLayout>
  );
}
