import React from "react";
import { useLocation } from "wouter";
import { useForm, useFieldArray } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import AppLayout from "@/layout/app-layout";
import Header from "@/components/layout/header";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { MoveUp, Plus, Trash2 } from "lucide-react";

const formSchema = z.object({
  name: z.string().min(3, {
    message: "Funnel name must be at least 3 characters.",
  }),
  description: z.string().optional(),
  steps: z.array(z.object({
    name: z.string().min(1, "Step name is required"),
    event: z.string().min(1, "Event is required"),
  })).min(2, "At least 2 steps are required"),
});

type FormValues = z.infer<typeof formSchema>;

export default function CreateFunnel() {
  const [, navigate] = useLocation();
  const { toast } = useToast();

  // Default values for the form
  const defaultValues: Partial<FormValues> = {
    name: "",
    description: "",
    steps: [
      { name: "Visit Homepage", event: "page_view" },
      { name: "View Product", event: "product_view" }
    ]
  };

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues,
  });
  
  // React Hook Form provides useFieldArray as a separate hook, not as a method on form
  const { fields, append, remove, move } = useFieldArray({
    control: form.control,
    name: "steps"
  });
  
  const onSubmit = async (data: FormValues) => {
    try {
      console.log("Form data on submit:", data);
      
      const response = await apiRequest("POST", "/api/funnels", data);
      
      if (response.ok) {
        // Invalidate the funnels query cache
        queryClient.invalidateQueries({ queryKey: ['/api/funnels'] });
        
        toast({
          title: "Funnel created successfully",
          description: "Your funnel has been created and is ready to use.",
        });
        
        // Redirect to the funnels list page
        navigate("/funnels");
      }
    } catch (error) {
      console.error("Error creating funnel:", error);
      toast({
        title: "Error creating funnel",
        description: "Something went wrong. Please try again.",
        variant: "destructive",
      });
    }
  };
  
  return (
    <AppLayout>
      <Header 
        title="Create Funnel" 
        description="Set up a new conversion funnel to track user flow"
        showDateRangePicker={false}
      />
      
      <div className="py-6 px-4 sm:px-6 lg:px-8">
        <Card>
          <CardHeader>
            <CardTitle>Funnel Details</CardTitle>
            <CardDescription>Define your funnel steps and events</CardDescription>
          </CardHeader>
          <CardContent>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Funnel Name</FormLabel>
                      <FormControl>
                        <Input placeholder="Signup Flow" {...field} />
                      </FormControl>
                      <FormDescription>
                        Give your funnel a descriptive name.
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="description"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Description (Optional)</FormLabel>
                      <FormControl>
                        <Textarea 
                          placeholder="Track user journey from homepage to registration completion" 
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <div>
                  <h3 className="text-md font-medium mb-2">Funnel Steps</h3>
                  <p className="text-sm text-gray-500 mb-4">
                    Define the steps in your user journey. The order matters - users progress through these steps sequentially.
                  </p>
                  
                  <div className="space-y-4">
                    {fields.map((field, index) => (
                      <div key={field.id} className="flex items-start gap-3 p-4 border rounded-md">
                        <div className="w-8 flex-shrink-0 flex flex-col items-center">
                          <div className="bg-primary-100 text-primary-700 font-bold rounded-full w-8 h-8 flex items-center justify-center">
                            {index + 1}
                          </div>
                          {index > 0 && (
                            <Button
                              type="button"
                              variant="ghost"
                              size="icon"
                              onClick={() => move(index, index - 1)}
                              className="h-8 w-8 mt-2"
                            >
                              <MoveUp className="h-4 w-4" />
                            </Button>
                          )}
                        </div>
                        
                        <div className="flex-1 grid grid-cols-1 md:grid-cols-2 gap-4">
                          <FormField
                            control={form.control}
                            name={`steps.${index}.name`}
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Step Name</FormLabel>
                                <FormControl>
                                  <Input {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={form.control}
                            name={`steps.${index}.event`}
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Event</FormLabel>
                                <Select
                                  onValueChange={field.onChange}
                                  defaultValue={field.value}
                                >
                                  <FormControl>
                                    <SelectTrigger>
                                      <SelectValue placeholder="Select an event" />
                                    </SelectTrigger>
                                  </FormControl>
                                  <SelectContent>
                                    <SelectItem value="page_view">Page View</SelectItem>
                                    <SelectItem value="registration">Registration</SelectItem>
                                    <SelectItem value="product_view">Product View</SelectItem>
                                    <SelectItem value="add_to_cart">Add to Cart</SelectItem>
                                    <SelectItem value="checkout">Checkout</SelectItem>
                                    <SelectItem value="purchase">Purchase</SelectItem>
                                    <SelectItem value="login">Login</SelectItem>
                                    <SelectItem value="search">Search</SelectItem>
                                    <SelectItem value="share">Share</SelectItem>
                                    <SelectItem value="download">Download</SelectItem>
                                  </SelectContent>
                                </Select>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                        
                        {fields.length > 2 && (
                          <Button
                            type="button"
                            variant="ghost"
                            size="icon"
                            onClick={() => remove(index)}
                            className="h-8 w-8 text-gray-400 hover:text-red-600"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        )}
                      </div>
                    ))}
                    
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={() => append({ name: "", event: "" })}
                      className="mt-2"
                    >
                      <Plus className="mr-2 h-4 w-4" /> Add Step
                    </Button>
                  </div>
                </div>
                
                <CardFooter className="flex justify-between px-0">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => navigate("/funnels")}
                  >
                    Cancel
                  </Button>
                  <Button type="submit">
                    Create Funnel
                  </Button>
                </CardFooter>
              </form>
            </Form>
          </CardContent>
        </Card>
      </div>
    </AppLayout>
  );
}