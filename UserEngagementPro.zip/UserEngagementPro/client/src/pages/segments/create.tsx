import React, { useState } from "react";
import { useLocation } from "wouter";
import AppLayout from "@/layout/app-layout";
import Header from "@/components/layout/header";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle,
  CardDescription,
  CardFooter
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useToast } from "@/hooks/use-toast";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Users, 
  Plus, 
  Trash, 
  ChevronRight, 
  CalendarDays, 
  Activity, 
  Search,
  Globe,
  Smartphone,
  Gauge,
  Clock,
  CheckCircle,
  Info
} from "lucide-react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

const formSchema = z.object({
  name: z.string().min(3, {
    message: "Segment name must be at least 3 characters.",
  }),
  description: z.string().optional(),
  type: z.string({
    required_error: "Please select a segment type.",
  }),
  criteria: z.record(z.any()),
});

type FormValues = z.infer<typeof formSchema>;

export default function CreateSegment() {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const [segmentType, setSegmentType] = useState("behavioral");
  const [estimatedUserCount, setEstimatedUserCount] = useState<number | null>(null);
  const [isCalculating, setIsCalculating] = useState(false);
  
  // Default values for the form
  const defaultValues: Partial<FormValues> = {
    name: "",
    description: "",
    type: "behavioral",
    criteria: {},
  };
  
  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues,
  });
  
  const onSubmit = async (data: FormValues) => {
    try {
      console.log("Form data on submit:", data);
      
      // Validate required fields
      if (!data.name) {
        form.setError("name", { message: "Segment name is required" });
        return;
      }
      
      // Set up criteria based on the segment type
      let criteria = {};
      let isValid = true;
      
      switch(segmentType) {
        case "behavioral":
          if (!data.criteria.eventName) {
            form.setError("criteria.eventName", { message: "Event name is required" });
            isValid = false;
          }
          
          criteria = {
            eventName: data.criteria.eventName || "purchase",
            operator: data.criteria.operator || "performed",
            threshold: data.criteria.threshold || 1,
            timeframe: data.criteria.timeframe || 30,
          };
          break;
          
        case "demographic":
          // Validate demographic properties if needed
          criteria = {
            properties: data.criteria.properties || [
              { property: "country", operator: "equals", value: "United States" }
            ]
          };
          break;
          
        case "lifecycle":
          if (!data.criteria.stage) {
            form.setError("criteria.stage", { message: "Lifecycle stage is required" });
            isValid = false;
          }
          
          criteria = {
            stage: data.criteria.stage || "new",
            duration: data.criteria.duration || 7,
          };
          break;
          
        case "predictive":
          if (!data.criteria.model) {
            form.setError("criteria.model", { message: "Prediction model is required" });
            isValid = false;
          }
          
          criteria = {
            model: data.criteria.model || "churn_prediction",
            threshold: data.criteria.threshold || 70,
          };
          break;
      }
      
      if (!isValid) {
        return;
      }
      
      // Convert the form data to match the API schema
      const payload = {
        name: data.name,
        description: data.description || "",
        type: segmentType,
        filters: JSON.stringify(criteria), // Convert to JSON string for the API
        createdBy: 1, // Using dummy user ID
        organizationId: 1 // Using dummy org ID
      };
      
      const response = await apiRequest("POST", "/api/segments", payload);
      
      if (response.ok) {
        // Invalidate the segments query cache
        queryClient.invalidateQueries({ queryKey: ['/api/segments'] });
        
        toast({
          title: "Segment created successfully",
          description: "Your segment is being calculated and will be ready shortly.",
        });
        
        // Redirect to the segments list page
        navigate("/segments");
      }
    } catch (error) {
      console.error("Error creating segment:", error);
      toast({
        title: "Error creating segment",
        description: "Something went wrong. Please try again.",
        variant: "destructive",
      });
    }
  };
  
  const calculateEstimate = () => {
    setIsCalculating(true);
    // Simulate API call to calculate estimate
    setTimeout(() => {
      setEstimatedUserCount(Math.floor(Math.random() * 10000) + 5000);
      setIsCalculating(false);
    }, 1500);
  };
  
  const renderCriteriaForm = () => {
    switch(segmentType) {
      case "behavioral":
        return (
          <div className="space-y-4">
            <FormField
              control={form.control}
              name="criteria.eventName"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Event Name</FormLabel>
                  <Select 
                    onValueChange={field.onChange} 
                    defaultValue={field.value || "purchase"}
                  >
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select an event" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="purchase">Purchase</SelectItem>
                      <SelectItem value="app_open">App Open</SelectItem>
                      <SelectItem value="page_view">Page View</SelectItem>
                      <SelectItem value="add_to_cart">Add to Cart</SelectItem>
                      <SelectItem value="checkout_start">Checkout Start</SelectItem>
                      <SelectItem value="login">Login</SelectItem>
                      <SelectItem value="register">Registration</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormDescription>
                    The user event to track.
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="criteria.operator"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Operator</FormLabel>
                  <Select 
                    onValueChange={field.onChange} 
                    defaultValue={field.value || "performed"}
                  >
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select operator" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="performed">Performed</SelectItem>
                      <SelectItem value="not_performed">Did Not Perform</SelectItem>
                      <SelectItem value="performed_at_least">Performed At Least</SelectItem>
                      <SelectItem value="performed_at_most">Performed At Most</SelectItem>
                      <SelectItem value="performed_exactly">Performed Exactly</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormDescription>
                    How to evaluate the event.
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="criteria.threshold"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Threshold</FormLabel>
                  <FormControl>
                    <Input 
                      type="number" 
                      min="1" 
                      placeholder="1" 
                      {...field} 
                      onChange={e => field.onChange(parseInt(e.target.value))}
                    />
                  </FormControl>
                  <FormDescription>
                    The number of times the event should occur.
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="criteria.timeframe"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Timeframe (days)</FormLabel>
                  <Select 
                    onValueChange={value => field.onChange(parseInt(value))} 
                    defaultValue={field.value?.toString() || "30"}
                  >
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select timeframe" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="1">Last 24 hours</SelectItem>
                      <SelectItem value="7">Last 7 days</SelectItem>
                      <SelectItem value="30">Last 30 days</SelectItem>
                      <SelectItem value="90">Last 90 days</SelectItem>
                      <SelectItem value="180">Last 180 days</SelectItem>
                      <SelectItem value="365">Last 365 days</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormDescription>
                    The time window to consider.
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>
        );
        
      case "demographic":
        return (
          <div className="space-y-4">
            <div className="bg-amber-50 border border-amber-200 rounded-md p-4 mb-4">
              <div className="flex gap-2">
                <Info className="h-5 w-5 text-amber-500 flex-shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-medium text-sm text-amber-800">Property Matching</h4>
                  <p className="text-xs text-amber-700 mt-1">
                    Match users based on their profile properties. Add multiple properties to create an AND condition.
                  </p>
                </div>
              </div>
            </div>
            
            <div className="border rounded-md p-4 space-y-4">
              <div className="flex justify-between items-center">
                <h4 className="text-sm font-medium">User Properties</h4>
                <Button type="button" size="sm" variant="outline">
                  <Plus className="h-4 w-4 mr-1" />
                  Add Property
                </Button>
              </div>
              
              <div className="space-y-2">
                <div className="grid grid-cols-1 md:grid-cols-12 gap-2 items-end">
                  <div className="md:col-span-4">
                    <label className="text-xs text-gray-500 mb-1 block">Property</label>
                    <Select defaultValue="country">
                      <SelectTrigger>
                        <SelectValue placeholder="Select property" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="country">Country</SelectItem>
                        <SelectItem value="city">City</SelectItem>
                        <SelectItem value="language">Language</SelectItem>
                        <SelectItem value="platform">Platform</SelectItem>
                        <SelectItem value="device_type">Device Type</SelectItem>
                        <SelectItem value="app_version">App Version</SelectItem>
                        <SelectItem value="os_version">OS Version</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="md:col-span-3">
                    <label className="text-xs text-gray-500 mb-1 block">Operator</label>
                    <Select defaultValue="equals">
                      <SelectTrigger>
                        <SelectValue placeholder="Select operator" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="equals">Equals</SelectItem>
                        <SelectItem value="not_equals">Does Not Equal</SelectItem>
                        <SelectItem value="contains">Contains</SelectItem>
                        <SelectItem value="starts_with">Starts With</SelectItem>
                        <SelectItem value="greater_than">Greater Than</SelectItem>
                        <SelectItem value="less_than">Less Than</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="md:col-span-4">
                    <label className="text-xs text-gray-500 mb-1 block">Value</label>
                    <Input defaultValue="United States" />
                  </div>
                  
                  <div className="md:col-span-1 flex justify-end">
                    <Button type="button" variant="ghost" size="icon" className="text-gray-400 hover:text-red-600">
                      <Trash className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        );
        
      case "lifecycle":
        return (
          <div className="space-y-4">
            <FormField
              control={form.control}
              name="criteria.stage"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Lifecycle Stage</FormLabel>
                  <Select 
                    onValueChange={field.onChange} 
                    defaultValue={field.value || "new"}
                  >
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select lifecycle stage" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="new">New Users</SelectItem>
                      <SelectItem value="active">Active Users</SelectItem>
                      <SelectItem value="inactive">Inactive Users</SelectItem>
                      <SelectItem value="dormant">Dormant Users</SelectItem>
                      <SelectItem value="churned">Churned Users</SelectItem>
                      <SelectItem value="reactivated">Reactivated Users</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormDescription>
                    The lifecycle stage of users.
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="criteria.duration"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Duration (days)</FormLabel>
                  <Select 
                    onValueChange={value => field.onChange(parseInt(value))} 
                    defaultValue={field.value?.toString() || "7"}
                  >
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select duration" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="1">1 day</SelectItem>
                      <SelectItem value="7">7 days</SelectItem>
                      <SelectItem value="14">14 days</SelectItem>
                      <SelectItem value="30">30 days</SelectItem>
                      <SelectItem value="60">60 days</SelectItem>
                      <SelectItem value="90">90 days</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormDescription>
                    The duration to consider for the lifecycle stage.
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>
        );
        
      case "predictive":
        return (
          <div className="space-y-4">
            <div className="bg-blue-50 border border-blue-200 rounded-md p-4 mb-4">
              <div className="flex gap-2">
                <Info className="h-5 w-5 text-blue-500 flex-shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-medium text-sm text-blue-800">Predictive Segments</h4>
                  <p className="text-xs text-blue-700 mt-1">
                    Predictive segments use machine learning to identify users who are likely to perform specific actions in the future.
                  </p>
                </div>
              </div>
            </div>
            
            <FormField
              control={form.control}
              name="criteria.model"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Prediction Model</FormLabel>
                  <Select 
                    onValueChange={field.onChange} 
                    defaultValue={field.value || "churn_prediction"}
                  >
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select prediction model" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="churn_prediction">Churn Prediction</SelectItem>
                      <SelectItem value="conversion_prediction">Conversion Prediction</SelectItem>
                      <SelectItem value="purchase_prediction">Purchase Prediction</SelectItem>
                      <SelectItem value="engagement_prediction">Engagement Prediction</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormDescription>
                    The type of prediction to make.
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="criteria.threshold"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Probability Threshold (%)</FormLabel>
                  <FormControl>
                    <Input 
                      type="number" 
                      min="1" 
                      max="100"
                      placeholder="70" 
                      {...field} 
                      onChange={e => field.onChange(parseInt(e.target.value))}
                    />
                  </FormControl>
                  <FormDescription>
                    The minimum probability threshold for including users in this segment.
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>
        );
        
      default:
        return null;
    }
  };
  
  return (
    <AppLayout>
      <Header 
        title="Create Segment" 
        description="Define criteria to target specific user groups"
      />

      <div className="py-6 px-4 sm:px-6 lg:px-8">
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Segment Details</CardTitle>
                <CardDescription>
                  Give your segment a name and description.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Segment Name</FormLabel>
                      <FormControl>
                        <Input placeholder="High-value customers" {...field} />
                      </FormControl>
                      <FormDescription>
                        Give your segment a descriptive name.
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="description"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Description (Optional)</FormLabel>
                      <FormControl>
                        <Textarea 
                          placeholder="Users who have made at least 3 purchases in the last 30 days" 
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Segment Type</CardTitle>
                <CardDescription>
                  Choose the type of segment you want to create.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Tabs value={segmentType} onValueChange={setSegmentType} className="mb-6">
                  <TabsList className="grid grid-cols-4 mb-6">
                    <TabsTrigger value="behavioral" className="flex flex-col items-center gap-1 h-auto py-2">
                      <Gauge className="h-5 w-5" />
                      <span className="text-xs font-normal">Behavioral</span>
                    </TabsTrigger>
                    <TabsTrigger value="demographic" className="flex flex-col items-center gap-1 h-auto py-2">
                      <Globe className="h-5 w-5" />
                      <span className="text-xs font-normal">Demographic</span>
                    </TabsTrigger>
                    <TabsTrigger value="lifecycle" className="flex flex-col items-center gap-1 h-auto py-2">
                      <Clock className="h-5 w-5" />
                      <span className="text-xs font-normal">Lifecycle</span>
                    </TabsTrigger>
                    <TabsTrigger value="predictive" className="flex flex-col items-center gap-1 h-auto py-2">
                      <CheckCircle className="h-5 w-5" />
                      <span className="text-xs font-normal">Predictive</span>
                    </TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value="behavioral">
                    <div className="mb-4">
                      <h3 className="text-sm font-medium">Behavioral Criteria</h3>
                      <p className="text-sm text-gray-500 mt-1">
                        Group users based on the actions they have performed.
                      </p>
                    </div>
                    {renderCriteriaForm()}
                  </TabsContent>
                  
                  <TabsContent value="demographic">
                    <div className="mb-4">
                      <h3 className="text-sm font-medium">Demographic Criteria</h3>
                      <p className="text-sm text-gray-500 mt-1">
                        Group users based on their characteristics and profile information.
                      </p>
                    </div>
                    {renderCriteriaForm()}
                  </TabsContent>
                  
                  <TabsContent value="lifecycle">
                    <div className="mb-4">
                      <h3 className="text-sm font-medium">Lifecycle Criteria</h3>
                      <p className="text-sm text-gray-500 mt-1">
                        Group users based on their stage in the customer lifecycle.
                      </p>
                    </div>
                    {renderCriteriaForm()}
                  </TabsContent>
                  
                  <TabsContent value="predictive">
                    <div className="mb-4">
                      <h3 className="text-sm font-medium">Predictive Criteria</h3>
                      <p className="text-sm text-gray-500 mt-1">
                        Use AI to predict user behavior and group users accordingly.
                      </p>
                    </div>
                    {renderCriteriaForm()}
                  </TabsContent>
                </Tabs>
                
                <div className="mt-6 space-y-4">
                  <div className="flex justify-between items-center">
                    <div>
                      <h3 className="text-sm font-medium">Estimated Audience Size</h3>
                      <p className="text-sm text-gray-500 mt-1">
                        See how many users match your criteria.
                      </p>
                    </div>
                    <Button type="button" variant="outline" onClick={calculateEstimate} disabled={isCalculating}>
                      <Search className="h-4 w-4 mr-2" />
                      {isCalculating ? "Calculating..." : "Calculate"}
                    </Button>
                  </div>
                  
                  {estimatedUserCount !== null && (
                    <div className="bg-green-50 border border-green-200 rounded-md p-4">
                      <div className="flex items-center">
                        <Users className="h-5 w-5 text-green-600 mr-2" />
                        <div>
                          <p className="text-sm font-medium text-green-800">
                            Estimated Audience: {estimatedUserCount.toLocaleString()} users
                          </p>
                          <p className="text-xs text-green-700 mt-1">
                            This is approximately {Math.round((estimatedUserCount / 100000) * 100)}% of your total user base.
                          </p>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </CardContent>
              <CardFooter className="flex justify-between border-t p-6">
                <Button type="button" variant="outline" onClick={() => navigate("/segments")}>
                  Cancel
                </Button>
                <Button type="submit">
                  Create Segment
                </Button>
              </CardFooter>
            </Card>
          </form>
        </Form>
      </div>
    </AppLayout>
  );
}