import React, { useState } from "react";
import AppLayout from "@/layout/app-layout";
import Header from "@/components/layout/header";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle,
  CardDescription,
  CardFooter
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";
import { Skeleton } from "@/components/ui/skeleton";
import { DataTable } from "@/components/ui/data-table";
import { Link } from "wouter";
import { 
  BookOpen, 
  FileText, 
  Users, 
  UserPlus, 
  Clock, 
  Edit, 
  Copy, 
  Trash,
  CheckCircle,
  AlertCircle, 
  Gauge
} from "lucide-react";
import { formatDateShort } from "@/lib/dates";
import { formatNumber } from "@/lib/utils";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

interface Segment {
  id: number;
  name: string;
  description: string;
  type: string;
  criteria: any;
  userCount?: number;
  createdAt: string;
  lastUpdated?: string;
  status: string;
}

export default function Segments() {
  const [typeFilter, setTypeFilter] = useState<string>("all");
  
  const { data: segments, isLoading, refetch } = useQuery<Segment[]>({
    queryKey: ['/api/segments', typeFilter],
  });

  const filteredSegments = segments?.filter(segment => {
    if (typeFilter !== "all" && segment.type !== typeFilter) return false;
    return true;
  });

  const columns = [
    {
      accessorKey: "name",
      header: "Segment Name",
      cell: ({ row }: any) => (
        <div className="flex items-start gap-3">
          <div className="flex h-9 w-9 items-center justify-center rounded-md bg-green-100">
            <Users className="h-5 w-5 text-green-600" />
          </div>
          <div>
            <div className="font-medium">{row.getValue("name")}</div>
            <div className="text-sm text-gray-500 truncate max-w-[300px]">{row.original.description}</div>
          </div>
        </div>
      ),
    },
    {
      accessorKey: "type",
      header: "Type",
      cell: ({ row }: any) => {
        const type = row.getValue("type");
        let icon = <FileText className="h-4 w-4" />;
        let label = "Unknown";
        let color = "bg-gray-100 text-gray-600";
        
        switch(type) {
          case "behavioral":
            icon = <Gauge className="h-4 w-4 mr-1" />;
            label = "Behavioral";
            color = "bg-purple-100 text-purple-600";
            break;
          case "demographic":
            icon = <Users className="h-4 w-4 mr-1" />;
            label = "Demographic";
            color = "bg-blue-100 text-blue-600";
            break;
          case "lifecycle":
            icon = <Clock className="h-4 w-4 mr-1" />;
            label = "Lifecycle";
            color = "bg-amber-100 text-amber-600";
            break;
          case "predictive":
            icon = <CheckCircle className="h-4 w-4 mr-1" />;
            label = "Predictive";
            color = "bg-green-100 text-green-600";
            break;
        }
        
        return (
          <div className={`flex items-center gap-1 w-fit px-2.5 py-1 rounded-full text-xs ${color}`}>
            {icon}
            {label}
          </div>
        );
      },
    },
    {
      accessorKey: "userCount",
      header: "Users",
      cell: ({ row }: any) => {
        const userCount = row.getValue("userCount");
        return userCount ? (
          <div className="font-medium">{formatNumber(userCount)}</div>
        ) : (
          <div className="text-gray-500">-</div>
        );
      },
    },
    {
      accessorKey: "status",
      header: "Status",
      cell: ({ row }: any) => {
        const status = row.getValue("status");
        let color = "";
        let icon = null;
        
        switch(status) {
          case "active":
            color = "bg-green-100 text-green-600";
            icon = <CheckCircle className="h-4 w-4 mr-1" />;
            break;
          case "calculating":
            color = "bg-blue-100 text-blue-600";
            icon = <Clock className="h-4 w-4 mr-1" />;
            break;
          case "error":
            color = "bg-red-100 text-red-600";
            icon = <AlertCircle className="h-4 w-4 mr-1" />;
            break;
          default:
            color = "bg-gray-100 text-gray-600";
        }
        
        return (
          <div className={`flex items-center gap-1 w-fit px-2.5 py-1 rounded-full text-xs ${color}`}>
            {icon}
            <span className="capitalize">{status}</span>
          </div>
        );
      },
    },
    {
      accessorKey: "createdAt",
      header: "Created",
      cell: ({ row }: any) => (
        <div className="text-sm text-gray-500">
          {formatDateShort(row.getValue("createdAt"))}
        </div>
      ),
    },
    {
      id: "actions",
      cell: ({ row }: any) => (
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" className="h-8 w-8 p-0">
              <span className="sr-only">Open menu</span>
              <div className="flex h-8 w-8 items-center justify-center">
                <div className="h-1 w-1 rounded-full bg-gray-500"></div>
                <div className="h-1 w-1 rounded-full bg-gray-500 ml-0.5"></div>
                <div className="h-1 w-1 rounded-full bg-gray-500 ml-0.5"></div>
              </div>
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuLabel>Actions</DropdownMenuLabel>
            <DropdownMenuItem 
              onClick={() => window.location.href = `/segments/${row.original.id}`}
              className="cursor-pointer"
            >
              <Users className="mr-2 h-4 w-4" />
              View Users
            </DropdownMenuItem>
            <DropdownMenuItem 
              onClick={() => window.location.href = `/segments/${row.original.id}/edit`}
              className="cursor-pointer"
            >
              <Edit className="mr-2 h-4 w-4" />
              Edit
            </DropdownMenuItem>
            <DropdownMenuItem className="cursor-pointer">
              <Copy className="mr-2 h-4 w-4" />
              Duplicate
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <DropdownMenuItem 
                  onSelect={(e) => e.preventDefault()}
                  className="text-red-600 cursor-pointer"
                >
                  <Trash className="mr-2 h-4 w-4" />
                  Delete
                </DropdownMenuItem>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
                  <AlertDialogDescription>
                    This action cannot be undone. This will permanently delete the segment
                    "{row.original.name}" and remove it from any campaigns or journeys that use it.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>Cancel</AlertDialogCancel>
                  <AlertDialogAction className="bg-red-600">Delete</AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          </DropdownMenuContent>
        </DropdownMenu>
      ),
    },
  ];
  
  // Quick stats for the overview
  const stats = {
    total: segments?.length || 0,
    behavioral: segments?.filter(s => s.type === 'behavioral').length || 0,
    demographic: segments?.filter(s => s.type === 'demographic').length || 0,
    lifecycle: segments?.filter(s => s.type === 'lifecycle').length || 0,
    predictive: segments?.filter(s => s.type === 'predictive').length || 0,
  };

  return (
    <AppLayout>
      <Header 
        title="User Segments" 
        description="Create and manage targeted user segments"
        actionButton={{
          label: "Create Segment",
          href: "/segments/create",
        }}
      />

      <div className="py-6 px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-5 gap-4 mb-6">
          <Card className={typeFilter === 'all' ? 'ring-2 ring-primary-500 ring-offset-2' : ''}>
            <CardContent className="pt-6">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-500">All Segments</p>
                  <h3 className="text-2xl font-semibold mt-1">{stats.total}</h3>
                </div>
                <div className="p-2 bg-blue-100 rounded-full">
                  <Users className="h-5 w-5 text-blue-600" />
                </div>
              </div>
              <Button 
                variant="ghost" 
                size="sm" 
                className="mt-2 w-full justify-start text-primary-600"
                onClick={() => setTypeFilter('all')}
              >
                View all
              </Button>
            </CardContent>
          </Card>
          
          <Card className={typeFilter === 'behavioral' ? 'ring-2 ring-primary-500 ring-offset-2' : ''}>
            <CardContent className="pt-6">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-500">Behavioral</p>
                  <h3 className="text-2xl font-semibold mt-1">{stats.behavioral}</h3>
                </div>
                <div className="p-2 bg-purple-100 rounded-full">
                  <Gauge className="h-5 w-5 text-purple-600" />
                </div>
              </div>
              <Button 
                variant="ghost" 
                size="sm" 
                className="mt-2 w-full justify-start text-primary-600"
                onClick={() => setTypeFilter('behavioral')}
              >
                View segments
              </Button>
            </CardContent>
          </Card>
          
          <Card className={typeFilter === 'demographic' ? 'ring-2 ring-primary-500 ring-offset-2' : ''}>
            <CardContent className="pt-6">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-500">Demographic</p>
                  <h3 className="text-2xl font-semibold mt-1">{stats.demographic}</h3>
                </div>
                <div className="p-2 bg-blue-100 rounded-full">
                  <Users className="h-5 w-5 text-blue-600" />
                </div>
              </div>
              <Button 
                variant="ghost" 
                size="sm" 
                className="mt-2 w-full justify-start text-primary-600"
                onClick={() => setTypeFilter('demographic')}
              >
                View segments
              </Button>
            </CardContent>
          </Card>
          
          <Card className={typeFilter === 'lifecycle' ? 'ring-2 ring-primary-500 ring-offset-2' : ''}>
            <CardContent className="pt-6">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-500">Lifecycle</p>
                  <h3 className="text-2xl font-semibold mt-1">{stats.lifecycle}</h3>
                </div>
                <div className="p-2 bg-amber-100 rounded-full">
                  <Clock className="h-5 w-5 text-amber-600" />
                </div>
              </div>
              <Button 
                variant="ghost" 
                size="sm" 
                className="mt-2 w-full justify-start text-primary-600"
                onClick={() => setTypeFilter('lifecycle')}
              >
                View segments
              </Button>
            </CardContent>
          </Card>
          
          <Card className={typeFilter === 'predictive' ? 'ring-2 ring-primary-500 ring-offset-2' : ''}>
            <CardContent className="pt-6">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-500">Predictive</p>
                  <h3 className="text-2xl font-semibold mt-1">{stats.predictive}</h3>
                </div>
                <div className="p-2 bg-green-100 rounded-full">
                  <CheckCircle className="h-5 w-5 text-green-600" />
                </div>
              </div>
              <Button 
                variant="ghost" 
                size="sm" 
                className="mt-2 w-full justify-start text-primary-600"
                onClick={() => setTypeFilter('predictive')}
              >
                View segments
              </Button>
            </CardContent>
          </Card>
        </div>
        
        <Card>
          <CardHeader>
            <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center space-y-2 sm:space-y-0">
              <div>
                <CardTitle>Segment Management</CardTitle>
                <CardDescription>
                  Create and manage user segments for targeted campaigns
                </CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="space-y-4">
                <Skeleton className="h-10 w-full" />
                <Skeleton className="h-32 w-full" />
                <Skeleton className="h-10 w-full" />
              </div>
            ) : filteredSegments && filteredSegments.length > 0 ? (
              <DataTable 
                columns={columns}
                data={filteredSegments}
                searchColumn="name"
                searchPlaceholder="Search segments..."
              />
            ) : (
              <div className="flex flex-col items-center justify-center py-12 text-center">
                <div className="bg-green-100 p-3 rounded-full mb-4">
                  <Users className="h-8 w-8 text-green-600" />
                </div>
                <h3 className="text-lg font-medium text-gray-900 mb-1">No Segments Found</h3>
                <p className="text-sm text-gray-500 max-w-sm mb-6">
                  Create your first segment to start grouping users based on behavior, demographics, or lifecycle stage.
                </p>
                <Button asChild>
                  <Link href="/segments/create">Create Segment</Link>
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
        
        <div className="mt-6 grid grid-cols-1 gap-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Segment Types</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-start gap-3 p-3 bg-gray-50 rounded-lg">
                  <div className="p-2 bg-purple-100 rounded-full">
                    <Gauge className="h-5 w-5 text-purple-600" />
                  </div>
                  <div>
                    <h4 className="font-medium text-sm">Behavioral Segments</h4>
                    <p className="text-xs text-gray-500 mt-1">Group users based on their actions and behaviors within your app, such as feature usage or purchase history.</p>
                  </div>
                </div>
                
                <div className="flex items-start gap-3 p-3 bg-gray-50 rounded-lg">
                  <div className="p-2 bg-blue-100 rounded-full">
                    <Users className="h-5 w-5 text-blue-600" />
                  </div>
                  <div>
                    <h4 className="font-medium text-sm">Demographic Segments</h4>
                    <p className="text-xs text-gray-500 mt-1">Group users based on personal attributes like age, location, language, or device type.</p>
                  </div>
                </div>
                
                <div className="flex items-start gap-3 p-3 bg-gray-50 rounded-lg">
                  <div className="p-2 bg-amber-100 rounded-full">
                    <Clock className="h-5 w-5 text-amber-600" />
                  </div>
                  <div>
                    <h4 className="font-medium text-sm">Lifecycle Segments</h4>
                    <p className="text-xs text-gray-500 mt-1">Group users based on their stage in the customer journey, such as new users, active users, or churned users.</p>
                  </div>
                </div>
                
                <div className="flex items-start gap-3 p-3 bg-gray-50 rounded-lg">
                  <div className="p-2 bg-green-100 rounded-full">
                    <CheckCircle className="h-5 w-5 text-green-600" />
                  </div>
                  <div>
                    <h4 className="font-medium text-sm">Predictive Segments</h4>
                    <p className="text-xs text-gray-500 mt-1">AI-powered segments that group users based on predicted future behaviors, such as likelihood to convert or churn.</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </AppLayout>
  );
}