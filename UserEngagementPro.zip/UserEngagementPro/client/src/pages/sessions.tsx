import React, { useState } from "react";
import AppLayout from "@/layout/app-layout";
import Header from "@/components/layout/header";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle,
  CardDescription 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  Tabs, 
  TabsContent, 
  TabsList, 
  TabsTrigger 
} from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useQuery } from "@tanstack/react-query";
import { Skeleton } from "@/components/ui/skeleton";
import { DataTable } from "@/components/ui/data-table";
import { 
  LineChart, 
  Line, 
  AreaChart,
  Area,
  BarChart,
  Bar,
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell
} from 'recharts';
import { generateUserEngagementData, getLegendColors } from "@/lib/charts";
import { Download, Filter, Clock, Target, Calendar } from "lucide-react";
import { formatDateShort } from "@/lib/dates";

interface Session {
  id: string;
  userId: string;
  deviceType: string;
  platform: string;
  startTime: string;
  endTime: string;
  duration: number;
  eventsCount: number;
  country: string;
}

export default function Sessions() {
  const [viewType, setViewType] = useState<string>("overview");
  const [timeRange, setTimeRange] = useState<string>("last30days");
  
  const { data: sessionStats, isLoading: isStatsLoading } = useQuery({
    queryKey: ['/api/analytics/sessions/stats', timeRange],
    queryFn: () => Promise.resolve(generateUserEngagementData(30))
  });

  const { data: sessions, isLoading: isSessionsLoading } = useQuery<Session[]>({
    queryKey: ['/api/analytics/sessions', timeRange],
  });

  const platformDistribution = [
    { name: 'iOS', value: 45 },
    { name: 'Android', value: 40 },
    { name: 'Web', value: 15 }
  ];

  const sessionDurations = [
    { name: '< 1 min', value: 20 },
    { name: '1-5 mins', value: 35 },
    { name: '5-15 mins', value: 25 },
    { name: '15-30 mins', value: 12 },
    { name: '> 30 mins', value: 8 }
  ];

  const sessionColumns = [
    {
      accessorKey: "id",
      header: "Session ID",
      cell: ({ row }: any) => (
        <div className="font-mono text-xs">{row.getValue("id")}</div>
      ),
    },
    {
      accessorKey: "userId",
      header: "User ID",
      cell: ({ row }: any) => (
        <div className="font-medium">{row.getValue("userId")}</div>
      ),
    },
    {
      accessorKey: "deviceType",
      header: "Device",
    },
    {
      accessorKey: "platform",
      header: "Platform",
    },
    {
      accessorKey: "startTime",
      header: "Start Time",
      cell: ({ row }: any) => (
        <div>{formatDateShort(row.getValue("startTime"))}</div>
      ),
    },
    {
      accessorKey: "duration",
      header: "Duration",
      cell: ({ row }: any) => {
        const duration = row.getValue("duration");
        const minutes = Math.floor(duration / 60);
        const seconds = duration % 60;
        return <div>{minutes}m {seconds}s</div>;
      },
    },
    {
      accessorKey: "eventsCount",
      header: "Events",
    },
    {
      accessorKey: "country",
      header: "Country",
    },
  ];

  // Sample session data for visualization
  const generateSampleSessionData = (): Session[] => {
    const devices = ['iPhone', 'Android Phone', 'Desktop', 'Tablet', 'iPad'];
    const platforms = ['iOS', 'Android', 'Web'];
    const countries = ['United States', 'United Kingdom', 'Germany', 'France', 'India', 'Japan', 'Brazil'];
    const now = new Date();
    
    return Array.from({ length: 10 }, (_, i) => {
      const startTime = new Date(now.getTime() - Math.random() * 86400000 * 7);
      const duration = Math.floor(Math.random() * 1800); // Up to 30 minutes
      const endTime = new Date(startTime.getTime() + duration * 1000);
      
      return {
        id: `sess_${Math.random().toString(36).substring(2, 10)}`,
        userId: `user_${Math.random().toString(36).substring(2, 8)}`,
        deviceType: devices[Math.floor(Math.random() * devices.length)],
        platform: platforms[Math.floor(Math.random() * platforms.length)],
        startTime: startTime.toISOString(),
        endTime: endTime.toISOString(),
        duration: duration,
        eventsCount: Math.floor(Math.random() * 50) + 1,
        country: countries[Math.floor(Math.random() * countries.length)]
      };
    });
  };

  const sampleSessions = sessions || generateSampleSessionData();

  return (
    <AppLayout>
      <Header 
        title="Session Analytics" 
        description="Analyze user session patterns and engagement metrics"
      />

      <div className="py-6 px-4 sm:px-6 lg:px-8">
        <Tabs value={viewType} onValueChange={setViewType} className="mb-6">
          <div className="flex justify-between items-center mb-4">
            <TabsList>
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="duration">Duration</TabsTrigger>
              <TabsTrigger value="devices">Devices</TabsTrigger>
              <TabsTrigger value="individual">Individual Sessions</TabsTrigger>
            </TabsList>
            
            <div className="flex items-center space-x-2">
              <Select
                value={timeRange}
                onValueChange={setTimeRange}
              >
                <SelectTrigger className="w-[160px]">
                  <SelectValue placeholder="Select time range" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="today">Today</SelectItem>
                  <SelectItem value="yesterday">Yesterday</SelectItem>
                  <SelectItem value="last7days">Last 7 days</SelectItem>
                  <SelectItem value="last30days">Last 30 days</SelectItem>
                  <SelectItem value="custom">Custom Range</SelectItem>
                </SelectContent>
              </Select>
              
              <Button variant="outline" size="icon">
                <Download className="h-4 w-4" />
                <span className="sr-only">Download</span>
              </Button>
            </div>
          </div>

          <TabsContent value="overview">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
              <Card>
                <CardContent className="pt-6">
                  <div className="flex items-start justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-500">Average Session Length</p>
                      <h3 className="text-2xl font-semibold mt-1">8m 24s</h3>
                    </div>
                    <div className="p-2 bg-blue-100 rounded-full">
                      <Clock className="h-5 w-5 text-blue-600" />
                    </div>
                  </div>
                  <p className="text-xs text-green-600 mt-2">+12% vs. previous period</p>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="pt-6">
                  <div className="flex items-start justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-500">Sessions Per User</p>
                      <h3 className="text-2xl font-semibold mt-1">4.6</h3>
                    </div>
                    <div className="p-2 bg-violet-100 rounded-full">
                      <Target className="h-5 w-5 text-violet-600" />
                    </div>
                  </div>
                  <p className="text-xs text-green-600 mt-2">+5% vs. previous period</p>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="pt-6">
                  <div className="flex items-start justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-500">Bounce Rate</p>
                      <h3 className="text-2xl font-semibold mt-1">22.4%</h3>
                    </div>
                    <div className="p-2 bg-amber-100 rounded-full">
                      <Target className="h-5 w-5 text-amber-600" />
                    </div>
                  </div>
                  <p className="text-xs text-red-600 mt-2">+2.1% vs. previous period</p>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="pt-6">
                  <div className="flex items-start justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-500">Total Sessions</p>
                      <h3 className="text-2xl font-semibold mt-1">1.2M</h3>
                    </div>
                    <div className="p-2 bg-green-100 rounded-full">
                      <Calendar className="h-5 w-5 text-green-600" />
                    </div>
                  </div>
                  <p className="text-xs text-green-600 mt-2">+15% vs. previous period</p>
                </CardContent>
              </Card>
            </div>
            
            <Card className="mb-6">
              <CardHeader>
                <CardTitle>Sessions Over Time</CardTitle>
                <CardDescription>
                  Daily session count and average duration
                </CardDescription>
              </CardHeader>
              <CardContent>
                {isStatsLoading ? (
                  <Skeleton className="h-[400px] w-full" />
                ) : (
                  <div className="h-[400px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart
                        data={sessionStats}
                        margin={{
                          top: 20,
                          right: 30,
                          left: 20,
                          bottom: 20,
                        }}
                      >
                        <CartesianGrid strokeDasharray="3 3" vertical={false} opacity={0.2} />
                        <XAxis 
                          dataKey="label" 
                          tick={{ fontSize: 12 }}
                          tickLine={false}
                          axisLine={{ stroke: '#e2e8f0' }}
                        />
                        <YAxis 
                          yAxisId="left"
                          tickFormatter={(value) => value >= 1000 ? `${(value / 1000).toFixed(0)}k` : value}
                          tick={{ fontSize: 12 }}
                          tickLine={false}
                          axisLine={{ stroke: '#e2e8f0' }}
                        />
                        <YAxis 
                          yAxisId="right"
                          orientation="right"
                          tickFormatter={(value) => `${value}m`}
                          tick={{ fontSize: 12 }}
                          tickLine={false}
                          axisLine={{ stroke: '#e2e8f0' }}
                        />
                        <Tooltip 
                          formatter={(value: number, name: string) => {
                            if (name === 'Sessions') {
                              return [value.toLocaleString(), name];
                            }
                            return [`${value} min`, name];
                          }}
                          labelFormatter={(label) => `Date: ${label}`}
                        />
                        <Legend />
                        <Line 
                          type="monotone" 
                          dataKey="sessions" 
                          name="Sessions"
                          stroke={getLegendColors()[0]} 
                          strokeWidth={2}
                          yAxisId="left"
                          dot={false}
                          activeDot={{ r: 6 }}
                        />
                        <Line 
                          type="monotone" 
                          dataKey="avgDuration" 
                          name="Avg. Duration"
                          stroke={getLegendColors()[1]} 
                          strokeWidth={2}
                          yAxisId="right"
                          dot={false}
                          activeDot={{ r: 6 }}
                        />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                )}
              </CardContent>
            </Card>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Platform Distribution</CardTitle>
                  <CardDescription>
                    Sessions by platform
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-[300px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={platformDistribution}
                          cx="50%"
                          cy="50%"
                          labelLine={false}
                          label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                          outerRadius={120}
                          fill="#8884d8"
                          dataKey="value"
                        >
                          {platformDistribution.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={`hsl(${(index * 120 + 180) % 360}, 70%, 60%)`} />
                          ))}
                        </Pie>
                        <Tooltip formatter={(value) => `${value}%`} />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle>Session Durations</CardTitle>
                  <CardDescription>
                    Distribution of session lengths
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-[300px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart
                        data={sessionDurations}
                        margin={{
                          top: 20,
                          right: 30,
                          left: 20,
                          bottom: 30,
                        }}
                      >
                        <CartesianGrid strokeDasharray="3 3" vertical={false} opacity={0.2} />
                        <XAxis 
                          dataKey="name" 
                          tick={{ fontSize: 12 }}
                          tickLine={false}
                          axisLine={{ stroke: '#e2e8f0' }}
                        />
                        <YAxis 
                          tickFormatter={(value) => `${value}%`}
                          tick={{ fontSize: 12 }}
                          tickLine={false}
                          axisLine={{ stroke: '#e2e8f0' }}
                        />
                        <Tooltip formatter={(value) => `${value}%`} />
                        <Bar 
                          dataKey="value" 
                          name="Sessions" 
                          fill="#5046e5" 
                          radius={[4, 4, 0, 0]} 
                        />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
          
          <TabsContent value="duration">
            <Card>
              <CardHeader>
                <CardTitle>Session Duration Analysis</CardTitle>
                <CardDescription>
                  Detailed analysis of how long users stay in your app
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-[400px] mb-6">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart
                      data={sessionStats}
                      margin={{
                        top: 20,
                        right: 30,
                        left: 20,
                        bottom: 20,
                      }}
                    >
                      <CartesianGrid strokeDasharray="3 3" vertical={false} opacity={0.2} />
                      <XAxis 
                        dataKey="label" 
                        tick={{ fontSize: 12 }}
                        tickLine={false}
                        axisLine={{ stroke: '#e2e8f0' }}
                      />
                      <YAxis 
                        tickFormatter={(value) => `${value} min`}
                        tick={{ fontSize: 12 }}
                        tickLine={false}
                        axisLine={{ stroke: '#e2e8f0' }}
                      />
                      <Tooltip 
                        formatter={(value: number) => [`${value} minutes`, 'Avg. Duration']}
                        labelFormatter={(label) => `Date: ${label}`}
                      />
                      <Legend />
                      <Area 
                        type="monotone" 
                        dataKey="avgDuration" 
                        name="Avg. Duration" 
                        stroke="#5046e5" 
                        fill="#5046e533" 
                      />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  <Card>
                    <CardContent className="pt-6">
                      <div className="text-sm font-medium text-gray-500">Average</div>
                      <div className="text-2xl font-semibold mt-1">8m 24s</div>
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardContent className="pt-6">
                      <div className="text-sm font-medium text-gray-500">Median</div>
                      <div className="text-2xl font-semibold mt-1">6m 12s</div>
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardContent className="pt-6">
                      <div className="text-sm font-medium text-gray-500">90th Percentile</div>
                      <div className="text-2xl font-semibold mt-1">18m 35s</div>
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardContent className="pt-6">
                      <div className="text-sm font-medium text-gray-500">Engagement Score</div>
                      <div className="text-2xl font-semibold mt-1">7.6</div>
                    </CardContent>
                  </Card>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="devices">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Platform Distribution</CardTitle>
                  <CardDescription>
                    Sessions by operating system
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-[300px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={platformDistribution}
                          cx="50%"
                          cy="50%"
                          labelLine={false}
                          label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                          outerRadius={120}
                          fill="#8884d8"
                          dataKey="value"
                        >
                          {platformDistribution.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={`hsl(${(index * 120 + 180) % 360}, 70%, 60%)`} />
                          ))}
                        </Pie>
                        <Tooltip formatter={(value) => `${value}%`} />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle>Device Comparison</CardTitle>
                  <CardDescription>
                    Session metrics by device type
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="overflow-x-auto">
                    <table className="min-w-full divide-y divide-gray-200">
                      <thead className="bg-gray-50">
                        <tr>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Device</th>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Sessions</th>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Avg. Duration</th>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Bounce Rate</th>
                        </tr>
                      </thead>
                      <tbody className="bg-white divide-y divide-gray-200">
                        <tr>
                          <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">iPhone</td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">524,386</td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">9m 12s</td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">18.2%</td>
                        </tr>
                        <tr>
                          <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">Android Phone</td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">495,104</td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">7m 45s</td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">22.5%</td>
                        </tr>
                        <tr>
                          <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">iPad</td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">98,245</td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">12m 33s</td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">14.8%</td>
                        </tr>
                        <tr>
                          <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">Desktop</td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">182,670</td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">11m 19s</td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">16.3%</td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
          
          <TabsContent value="individual">
            <Card>
              <CardHeader>
                <CardTitle>Individual Sessions</CardTitle>
                <CardDescription>
                  Detailed view of user sessions
                </CardDescription>
              </CardHeader>
              <CardContent>
                {isSessionsLoading ? (
                  <div className="space-y-4">
                    <Skeleton className="h-10 w-full" />
                    <Skeleton className="h-32 w-full" />
                    <Skeleton className="h-10 w-full" />
                  </div>
                ) : (
                  <DataTable 
                    columns={sessionColumns}
                    data={sampleSessions}
                    searchColumn="userId"
                    searchPlaceholder="Search by user ID..."
                  />
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </AppLayout>
  );
}