import React, { useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import AppLayout from "@/layout/app-layout";
import Header from "@/components/layout/header";
import {
  Users,
  Building,
  Key,
  Lock,
  Bell,
  Mail,
  MessageSquare,
  Send,
  Shield,
  Globe,
  FileJson,
  Database,
  Zap,
  HelpCircle,
  ArchiveRestore,
  ServerCrash,
  Clock,
  UserCog,
  Building2,
  CreditCard,
  Tag,
} from "lucide-react";

export default function Settings() {
  const [activeTab, setActiveTab] = useState('general');
  
  return (
    <AppLayout>
      <Header 
        title="Settings" 
        description="Configure your account and application preferences"
      />
      
      <div className="p-6">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          <div className="lg:col-span-1">
            <div className="bg-white shadow rounded-lg overflow-hidden">
              <div className="p-4 space-y-1">
                <div className="font-medium text-lg">Settings</div>
                <div className="text-sm text-gray-500">Manage your account and preferences</div>
              </div>
              <Separator />
              <div className="p-0">
                <nav className="space-y-1">
                  {[
                    { id: 'general', label: 'General', icon: <Tag className="h-4 w-4" /> },
                    { id: 'organization', label: 'Organization', icon: <Building2 className="h-4 w-4" /> },
                    { id: 'users', label: 'Users & Permissions', icon: <Users className="h-4 w-4" /> },
                    { id: 'security', label: 'Security', icon: <Shield className="h-4 w-4" /> },
                    { id: 'api', label: 'API Keys', icon: <Key className="h-4 w-4" /> },
                    { id: 'notifications', label: 'Notifications', icon: <Bell className="h-4 w-4" /> },
                    { id: 'integrations', label: 'Integrations', icon: <Zap className="h-4 w-4" /> },
                    { id: 'billing', label: 'Billing', icon: <CreditCard className="h-4 w-4" /> },
                    { id: 'data', label: 'Data Management', icon: <Database className="h-4 w-4" /> },
                  ].map((item) => (
                    <Button
                      key={item.id}
                      variant={activeTab === item.id ? 'secondary' : 'ghost'}
                      className="w-full justify-start h-10 font-normal"
                      onClick={() => setActiveTab(item.id)}
                    >
                      {item.icon}
                      <span className="ml-3">{item.label}</span>
                    </Button>
                  ))}
                </nav>
              </div>
            </div>
          </div>
          
          <div className="lg:col-span-3 space-y-6">
            {activeTab === 'general' && (
              <div>
                <Card>
                  <CardHeader>
                    <CardTitle>General Settings</CardTitle>
                    <CardDescription>
                      Configure basic application settings and preferences
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="space-y-1">
                      <Label htmlFor="app-name">Application Name</Label>
                      <Input id="app-name" defaultValue="CustomerHub" />
                      <p className="text-sm text-gray-500 mt-1">The name of your application instance</p>
                    </div>
                    
                    <Separator />
                    
                    <div className="space-y-4">
                      <h3 className="text-sm font-medium">Time Zone & Date Format</h3>
                      
                      <div className="grid gap-2">
                        <Label htmlFor="timezone">Default Time Zone</Label>
                        <select
                          id="timezone"
                          className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                          defaultValue="America/New_York"
                        >
                          <option value="America/New_York">Eastern Time (ET)</option>
                          <option value="America/Chicago">Central Time (CT)</option>
                          <option value="America/Denver">Mountain Time (MT)</option>
                          <option value="America/Los_Angeles">Pacific Time (PT)</option>
                          <option value="UTC">UTC</option>
                        </select>
                      </div>
                      
                      <div className="grid gap-2">
                        <Label htmlFor="date-format">Date Format</Label>
                        <select
                          id="date-format"
                          className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                          defaultValue="MM/DD/YYYY"
                        >
                          <option value="MM/DD/YYYY">MM/DD/YYYY</option>
                          <option value="DD/MM/YYYY">DD/MM/YYYY</option>
                          <option value="YYYY-MM-DD">YYYY-MM-DD</option>
                        </select>
                      </div>
                    </div>
                    
                    <Separator />
                    
                    <div className="space-y-4">
                      <h3 className="text-sm font-medium">Default Settings</h3>
                      
                      <div className="flex items-center justify-between">
                        <div className="space-y-0.5">
                          <Label>Auto Archive Campaigns</Label>
                          <p className="text-sm text-gray-500">Automatically archive campaigns 30 days after completion</p>
                        </div>
                        <Switch defaultChecked />
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <div className="space-y-0.5">
                          <Label>Analytics Sampling</Label>
                          <p className="text-sm text-gray-500">Enable data sampling for high-volume analytics</p>
                        </div>
                        <Switch />
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <div className="space-y-0.5">
                          <Label>Real-time Dashboards</Label>
                          <p className="text-sm text-gray-500">Show real-time data on dashboards (may impact performance)</p>
                        </div>
                        <Switch defaultChecked />
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter className="flex justify-between">
                    <Button variant="outline">Cancel</Button>
                    <Button>Save Changes</Button>
                  </CardFooter>
                </Card>
                
                <Card className="mt-6">
                  <CardHeader>
                    <CardTitle>Interface Preferences</CardTitle>
                    <CardDescription>
                      Customize the appearance and behavior of the user interface
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="space-y-4">
                      <h3 className="text-sm font-medium">Display Settings</h3>
                      
                      <div className="grid gap-2">
                        <Label htmlFor="theme">Theme</Label>
                        <select
                          id="theme"
                          className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                          defaultValue="light"
                        >
                          <option value="light">Light</option>
                          <option value="dark">Dark</option>
                          <option value="system">System Default</option>
                        </select>
                      </div>
                      
                      <div className="grid gap-2">
                        <Label htmlFor="density">Display Density</Label>
                        <select
                          id="density"
                          className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                          defaultValue="compact"
                        >
                          <option value="comfortable">Comfortable</option>
                          <option value="default">Default</option>
                          <option value="compact">Compact</option>
                        </select>
                      </div>
                    </div>
                    
                    <Separator />
                    
                    <div className="space-y-4">
                      <h3 className="text-sm font-medium">Table Preferences</h3>
                      
                      <div className="grid gap-2">
                        <Label htmlFor="page-size">Default Page Size</Label>
                        <select
                          id="page-size"
                          className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                          defaultValue="20"
                        >
                          <option value="10">10 items</option>
                          <option value="20">20 items</option>
                          <option value="50">50 items</option>
                          <option value="100">100 items</option>
                        </select>
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter className="flex justify-between">
                    <Button variant="outline">Reset to Default</Button>
                    <Button>Save Changes</Button>
                  </CardFooter>
                </Card>
              </div>
            )}
            
            {activeTab === 'organization' && (
              <Card>
                <CardHeader>
                  <CardTitle>Organization Settings</CardTitle>
                  <CardDescription>
                    Manage your organization profile and preferences
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="space-y-1">
                    <Label htmlFor="org-name">Organization Name</Label>
                    <Input id="org-name" defaultValue="Acme Corporation" />
                  </div>
                  
                  <div className="space-y-1">
                    <Label htmlFor="org-industry">Industry</Label>
                    <select
                      id="org-industry"
                      className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                      defaultValue="tech"
                    >
                      <option value="tech">Technology</option>
                      <option value="retail">Retail & E-commerce</option>
                      <option value="finance">Finance & Banking</option>
                      <option value="healthcare">Healthcare</option>
                      <option value="education">Education</option>
                      <option value="other">Other</option>
                    </select>
                  </div>
                  
                  <div className="space-y-1">
                    <Label htmlFor="org-size">Company Size</Label>
                    <select
                      id="org-size"
                      className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                      defaultValue="51-200"
                    >
                      <option value="1-10">1-10 employees</option>
                      <option value="11-50">11-50 employees</option>
                      <option value="51-200">51-200 employees</option>
                      <option value="201-500">201-500 employees</option>
                      <option value="501+">501+ employees</option>
                    </select>
                  </div>
                  
                  <Separator />
                  
                  <div className="space-y-1">
                    <Label htmlFor="primary-contact">Primary Contact Email</Label>
                    <Input id="primary-contact" type="email" defaultValue="admin@acmecorp.com" />
                  </div>
                  
                  <div className="space-y-1">
                    <Label htmlFor="org-address">Business Address</Label>
                    <Input id="org-address" defaultValue="123 Main Street, Suite 100" />
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <Label htmlFor="org-city">City</Label>
                      <Input id="org-city" defaultValue="San Francisco" />
                    </div>
                    <div className="space-y-1">
                      <Label htmlFor="org-zip">ZIP / Postal Code</Label>
                      <Input id="org-zip" defaultValue="94105" />
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <Label htmlFor="org-state">State / Province</Label>
                      <Input id="org-state" defaultValue="California" />
                    </div>
                    <div className="space-y-1">
                      <Label htmlFor="org-country">Country</Label>
                      <select
                        id="org-country"
                        className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                        defaultValue="US"
                      >
                        <option value="US">United States</option>
                        <option value="CA">Canada</option>
                        <option value="UK">United Kingdom</option>
                        <option value="AU">Australia</option>
                        <option value="DE">Germany</option>
                        <option value="FR">France</option>
                      </select>
                    </div>
                  </div>
                </CardContent>
                <CardFooter className="flex justify-between">
                  <Button variant="outline">Cancel</Button>
                  <Button>Save Changes</Button>
                </CardFooter>
              </Card>
            )}
            
            {activeTab === 'users' && (
              <Card>
                <CardHeader>
                  <CardTitle>Users & Permissions</CardTitle>
                  <CardDescription>
                    Manage user accounts and access controls
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-end">
                      <Button>
                        <UserCog className="h-4 w-4 mr-2" />
                        Add User
                      </Button>
                    </div>
                    
                    <div className="relative overflow-x-auto shadow-sm rounded-lg">
                      <table className="w-full text-sm text-left">
                        <thead className="text-xs text-gray-700 uppercase bg-gray-50">
                          <tr>
                            <th scope="col" className="px-6 py-3">User</th>
                            <th scope="col" className="px-6 py-3">Email</th>
                            <th scope="col" className="px-6 py-3">Role</th>
                            <th scope="col" className="px-6 py-3">Status</th>
                            <th scope="col" className="px-6 py-3">Actions</th>
                          </tr>
                        </thead>
                        <tbody>
                          {[
                            { name: "John Smith", email: "john@acmecorp.com", role: "Admin", status: "Active" },
                            { name: "Sarah Johnson", email: "sarah@acmecorp.com", role: "Marketing Manager", status: "Active" },
                            { name: "Michael Brown", email: "michael@acmecorp.com", role: "Analyst", status: "Active" },
                            { name: "Emma Davis", email: "emma@acmecorp.com", role: "Viewer", status: "Invited" },
                          ].map((user, i) => (
                            <tr key={i} className="bg-white border-b hover:bg-gray-50">
                              <td className="px-6 py-4 font-medium text-gray-900 whitespace-nowrap">
                                {user.name}
                              </td>
                              <td className="px-6 py-4">{user.email}</td>
                              <td className="px-6 py-4">{user.role}</td>
                              <td className="px-6 py-4">
                                <span className={`px-2 py-1 text-xs rounded-full ${
                                  user.status === 'Active' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'
                                }`}>
                                  {user.status}
                                </span>
                              </td>
                              <td className="px-6 py-4 space-x-2">
                                <Button variant="ghost" size="sm">Edit</Button>
                                <Button variant="ghost" size="sm" className="text-red-500">Disable</Button>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                  
                  <div className="mt-8 space-y-4">
                    <h3 className="text-lg font-medium">Roles & Permissions</h3>
                    <p className="text-sm text-gray-500">Define access levels and capabilities for each user role</p>
                    
                    <div className="relative overflow-x-auto shadow-sm rounded-lg">
                      <table className="w-full text-sm text-left">
                        <thead className="text-xs text-gray-700 uppercase bg-gray-50">
                          <tr>
                            <th scope="col" className="px-6 py-3">Role</th>
                            <th scope="col" className="px-6 py-3">Description</th>
                            <th scope="col" className="px-6 py-3">Users</th>
                            <th scope="col" className="px-6 py-3">Actions</th>
                          </tr>
                        </thead>
                        <tbody>
                          {[
                            { name: "Admin", description: "Full access to all features and settings", users: 1 },
                            { name: "Marketing Manager", description: "Can create campaigns and access analytics", users: 1 },
                            { name: "Analyst", description: "Can view analytics and reports only", users: 1 },
                            { name: "Viewer", description: "Read-only access to dashboards", users: 1 },
                          ].map((role, i) => (
                            <tr key={i} className="bg-white border-b hover:bg-gray-50">
                              <td className="px-6 py-4 font-medium text-gray-900 whitespace-nowrap">
                                {role.name}
                              </td>
                              <td className="px-6 py-4">{role.description}</td>
                              <td className="px-6 py-4">{role.users}</td>
                              <td className="px-6 py-4 space-x-2">
                                <Button variant="ghost" size="sm">Edit</Button>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
            
            {activeTab === 'security' && (
              <Card>
                <CardHeader>
                  <CardTitle>Security Settings</CardTitle>
                  <CardDescription>
                    Configure security and authentication options
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="space-y-4">
                    <h3 className="text-sm font-medium">Authentication</h3>
                    
                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label>Two-Factor Authentication (2FA)</Label>
                        <p className="text-sm text-gray-500">Require 2FA for all admin users</p>
                      </div>
                      <Switch defaultChecked />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label>Single Sign-On (SSO)</Label>
                        <p className="text-sm text-gray-500">Enable SSO with your identity provider</p>
                      </div>
                      <Switch />
                    </div>
                  </div>
                  
                  <Separator />
                  
                  <div className="space-y-4">
                    <h3 className="text-sm font-medium">Password Policy</h3>
                    
                    <div className="grid gap-2">
                      <Label htmlFor="min-password-length">Minimum Password Length</Label>
                      <select
                        id="min-password-length"
                        className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                        defaultValue="8"
                      >
                        <option value="6">6 characters</option>
                        <option value="8">8 characters</option>
                        <option value="10">10 characters</option>
                        <option value="12">12 characters</option>
                      </select>
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label>Require Special Characters</Label>
                        <p className="text-sm text-gray-500">Passwords must include special characters</p>
                      </div>
                      <Switch defaultChecked />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label>Password Expiration</Label>
                        <p className="text-sm text-gray-500">Force password reset every 90 days</p>
                      </div>
                      <Switch />
                    </div>
                  </div>
                  
                  <Separator />
                  
                  <div className="space-y-4">
                    <h3 className="text-sm font-medium">Session Management</h3>
                    
                    <div className="grid gap-2">
                      <Label htmlFor="session-timeout">Session Timeout</Label>
                      <select
                        id="session-timeout"
                        className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                        defaultValue="30"
                      >
                        <option value="15">15 minutes</option>
                        <option value="30">30 minutes</option>
                        <option value="60">1 hour</option>
                        <option value="120">2 hours</option>
                        <option value="240">4 hours</option>
                      </select>
                    </div>
                  </div>
                </CardContent>
                <CardFooter className="flex justify-between">
                  <Button variant="outline">Cancel</Button>
                  <Button>Save Changes</Button>
                </CardFooter>
              </Card>
            )}
          </div>
        </div>
      </div>
    </AppLayout>
  );
}