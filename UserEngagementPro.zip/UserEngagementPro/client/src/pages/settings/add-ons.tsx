import React from "react";
import AppLayout from "@/layout/app-layout";
import Header from "@/components/layout/header";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Puzzle,
  Zap,
  Activity,
  BarChart4,
  Globe,
  MessagesSquare,
  Share2,
  BookOpen,
  Settings,
  AlertTriangle,
  Check,
  XCircle,
  Lock,
  Star,
} from "lucide-react";

export default function AddOns() {
  return (
    <AppLayout>
      <Header
        title="Extensions & Add-ons"
        description="Enhance your platform with additional features and integrations"
        actionButton={{
          label: "Marketplace",
          href: "#",
          icon: <Puzzle className="h-4 w-4 mr-2" />,
        }}
      />

      <div className="p-6">
        <Tabs defaultValue="installed">
          <div className="flex justify-between items-center mb-6">
            <TabsList>
              <TabsTrigger value="installed">Installed</TabsTrigger>
              <TabsTrigger value="recommended">Recommended</TabsTrigger>
              <TabsTrigger value="marketplace">Marketplace</TabsTrigger>
              <TabsTrigger value="custom">Custom Integrations</TabsTrigger>
            </TabsList>
          </div>

          <TabsContent value="installed" className="mt-0">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[
                {
                  name: "Advanced Analytics",
                  description: "Predictive analytics and advanced reporting capabilities",
                  icon: <BarChart4 className="h-8 w-8" />,
                  status: "active",
                  tier: "premium",
                },
                {
                  name: "Social Media Integration",
                  description: "Connect and share campaigns on social media platforms",
                  icon: <Share2 className="h-8 w-8" />,
                  status: "active",
                  tier: "standard",
                },
                {
                  name: "A/B Testing Suite",
                  description: "Advanced A/B testing for all campaign types",
                  icon: <Activity className="h-8 w-8" />,
                  status: "active",
                  tier: "premium",
                },
                {
                  name: "Chat Support",
                  description: "Live chat support for your customers",
                  icon: <MessagesSquare className="h-8 w-8" />,
                  status: "inactive",
                  tier: "premium",
                },
                {
                  name: "Multilingual Content",
                  description: "Automated translation and localization",
                  icon: <Globe className="h-8 w-8" />,
                  status: "active",
                  tier: "enterprise",
                },
              ].map((addon, i) => (
                <Card key={i}>
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <div className="p-2 bg-primary-100 rounded-lg">
                        <div className="text-primary-600">{addon.icon}</div>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge
                          variant={addon.tier === "premium" ? "default" : addon.tier === "enterprise" ? "destructive" : "secondary"}
                          className="capitalize"
                        >
                          {addon.tier}
                        </Badge>
                        <div className="flex items-center">
                          <Switch id={`addon-${i}`} checked={addon.status === "active"} />
                        </div>
                      </div>
                    </div>
                    <CardTitle className="mt-4">{addon.name}</CardTitle>
                    <CardDescription>{addon.description}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center text-sm text-gray-500 mb-4">
                      <div
                        className={`h-2.5 w-2.5 rounded-full mr-2 ${
                          addon.status === "active" ? "bg-green-500" : "bg-gray-400"
                        }`}
                      ></div>
                      <span className="capitalize">{addon.status}</span>
                    </div>

                    <div className="grid grid-cols-2 gap-2 text-sm">
                      <div className="flex items-center">
                        <Check className="h-4 w-4 text-green-500 mr-1" />
                        <span>Analytics</span>
                      </div>
                      <div className="flex items-center">
                        <Check className="h-4 w-4 text-green-500 mr-1" />
                        <span>Reporting</span>
                      </div>
                      <div className="flex items-center">
                        <Check className="h-4 w-4 text-green-500 mr-1" />
                        <span>API Access</span>
                      </div>
                      <div className="flex items-center">
                        {addon.tier === "premium" || addon.tier === "enterprise" ? (
                          <Check className="h-4 w-4 text-green-500 mr-1" />
                        ) : (
                          <XCircle className="h-4 w-4 text-gray-400 mr-1" />
                        )}
                        <span>Premium Support</span>
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter className="flex justify-between">
                    <Button variant="outline" size="sm">
                      <Settings className="h-4 w-4 mr-2" />
                      Configure
                    </Button>
                    <Button size="sm">
                      <BookOpen className="h-4 w-4 mr-2" />
                      Documentation
                    </Button>
                  </CardFooter>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="recommended" className="mt-0">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[
                {
                  name: "AI Audience Segmentation",
                  description: "Machine learning for advanced user segmentation",
                  icon: <Zap className="h-8 w-8" />,
                  tier: "premium",
                  recommended: true,
                },
                {
                  name: "WhatsApp Business Integration",
                  description: "Seamless integration with WhatsApp Business API",
                  icon: <MessagesSquare className="h-8 w-8" />,
                  tier: "premium",
                  recommended: true,
                },
                {
                  name: "E-commerce Analytics",
                  description: "Specialized analytics for e-commerce businesses",
                  icon: <BarChart4 className="h-8 w-8" />,
                  tier: "standard",
                  recommended: true,
                }
              ].map((addon, i) => (
                <Card key={i}>
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <div className="p-2 bg-primary-100 rounded-lg">
                        <div className="text-primary-600">{addon.icon}</div>
                      </div>
                      <Badge
                        variant={addon.tier === "premium" ? "default" : "secondary"}
                        className="capitalize"
                      >
                        {addon.tier}
                      </Badge>
                    </div>
                    <CardTitle className="mt-4">{addon.name}</CardTitle>
                    <CardDescription>{addon.description}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center text-sm text-yellow-600 mb-4">
                      <Star className="h-4 w-4 mr-2 fill-yellow-500" />
                      <span>Recommended for your business</span>
                    </div>

                    <div className="grid grid-cols-2 gap-2 text-sm">
                      <div className="flex items-center">
                        <Check className="h-4 w-4 text-green-500 mr-1" />
                        <span>Analytics</span>
                      </div>
                      <div className="flex items-center">
                        <Check className="h-4 w-4 text-green-500 mr-1" />
                        <span>Reporting</span>
                      </div>
                      <div className="flex items-center">
                        <Check className="h-4 w-4 text-green-500 mr-1" />
                        <span>API Access</span>
                      </div>
                      <div className="flex items-center">
                        {addon.tier === "premium" ? (
                          <Check className="h-4 w-4 text-green-500 mr-1" />
                        ) : (
                          <XCircle className="h-4 w-4 text-gray-400 mr-1" />
                        )}
                        <span>Premium Support</span>
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter>
                    <Button className="w-full">Install Add-on</Button>
                  </CardFooter>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="marketplace" className="mt-0">
            <div className="bg-white p-6 rounded-lg shadow mb-6">
              <div className="text-center max-w-2xl mx-auto mb-6">
                <h3 className="text-2xl font-bold mb-2">Add-on Marketplace</h3>
                <p className="text-gray-600">
                  Enhance your platform with premium features, integrations, and tools from our marketplace
                </p>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                <Button variant="outline" className="h-auto py-2 justify-start">
                  <BarChart4 className="h-4 w-4 mr-2" />
                  Analytics
                </Button>
                <Button variant="outline" className="h-auto py-2 justify-start">
                  <MessagesSquare className="h-4 w-4 mr-2" />
                  Messaging
                </Button>
                <Button variant="outline" className="h-auto py-2 justify-start">
                  <Globe className="h-4 w-4 mr-2" />
                  Localization
                </Button>
                <Button variant="outline" className="h-auto py-2 justify-start">
                  <Share2 className="h-4 w-4 mr-2" />
                  Social Media
                </Button>
              </div>

              <div className="relative">
                <div className="h-64 flex items-center justify-center border-2 border-dashed rounded-lg">
                  <div className="text-center px-6">
                    <Lock className="h-12 w-12 mx-auto text-gray-400 mb-2" />
                    <h3 className="text-lg font-medium">Marketplace Access</h3>
                    <p className="text-sm text-gray-500 mb-4">
                      Upgrade your plan to access our full marketplace of premium add-ons and integrations
                    </p>
                    <Button>Upgrade Your Plan</Button>
                  </div>
                </div>
              </div>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Enterprise Add-ons</CardTitle>
                <CardDescription>
                  Exclusive features available for enterprise customers
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {[
                    {
                      name: "Advanced Security Suite",
                      description: "Enterprise-grade security features",
                      icon: <Lock className="h-6 w-6" />,
                    },
                    {
                      name: "Custom Branding",
                      description: "White-label and custom branding options",
                      icon: <Settings className="h-6 w-6" />,
                    },
                    {
                      name: "Dedicated Infrastructure",
                      description: "Isolated cloud infrastructure",
                      icon: <AlertTriangle className="h-6 w-6" />,
                    },
                  ].map((feature, i) => (
                    <div
                      key={i}
                      className="border rounded-lg p-4 flex items-start space-x-4"
                    >
                      <div className="p-2 bg-gray-100 rounded-lg">
                        {feature.icon}
                      </div>
                      <div>
                        <h4 className="font-medium">{feature.name}</h4>
                        <p className="text-sm text-gray-500">
                          {feature.description}
                        </p>
                        <Button variant="link" size="sm" className="px-0 h-auto mt-2">
                          Learn more
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
              <CardFooter>
                <Button variant="outline" className="w-full">
                  Contact Sales for Enterprise Features
                </Button>
              </CardFooter>
            </Card>
          </TabsContent>

          <TabsContent value="custom" className="mt-0">
            <Card>
              <CardHeader>
                <CardTitle>Custom Integrations</CardTitle>
                <CardDescription>
                  Develop and manage your own custom integrations
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="p-6 border-2 border-dashed rounded-lg text-center">
                  <Zap className="h-12 w-12 mx-auto text-gray-400 mb-2" />
                  <h3 className="text-lg font-medium">No Custom Integrations Yet</h3>
                  <p className="text-sm text-gray-500 mb-4 max-w-md mx-auto">
                    Use our developer API to build custom integrations specific to your business needs
                  </p>
                  <div className="flex flex-col sm:flex-row gap-2 justify-center">
                    <Button variant="outline">
                      <BookOpen className="h-4 w-4 mr-2" />
                      API Documentation
                    </Button>
                    <Button>
                      <Puzzle className="h-4 w-4 mr-2" />
                      Create Integration
                    </Button>
                  </div>
                </div>

                <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
                  <div className="flex items-start">
                    <AlertTriangle className="h-5 w-5 text-amber-600 mr-3 mt-0.5" />
                    <div>
                      <h4 className="text-sm font-medium text-amber-800">Developer Access Required</h4>
                      <p className="text-sm text-amber-700 mt-1">
                        Creating custom integrations requires developer API access. Contact your administrator if you need access.
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="mt-6">
              <CardHeader>
                <CardTitle>API Access</CardTitle>
                <CardDescription>
                  Manage your API keys and developer access
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <h4 className="font-medium">Developer API Access</h4>
                    <p className="text-sm text-gray-500">
                      Enable API access for custom integrations
                    </p>
                  </div>
                  <Switch id="api-access" />
                </div>

                <div className="border rounded-lg overflow-hidden">
                  <div className="bg-gray-50 px-4 py-2 text-sm font-medium">
                    API Key Access
                  </div>
                  <div className="p-4">
                    <p className="text-sm text-gray-500 mb-4">
                      Your API keys provide full access to your account. Keep them secure!
                    </p>
                    <div className="grid gap-4">
                      <div className="flex justify-between items-center">
                        <div>
                          <Label className="mb-1 block">Production API Key</Label>
                          <div className="flex items-center">
                            <div className="bg-gray-100 text-gray-500 rounded px-3 py-1 text-sm font-mono">
                              •••••••••••••••••••••••••••••
                            </div>
                          </div>
                        </div>
                        <Button variant="outline" size="sm">
                          Show
                        </Button>
                      </div>

                      <div className="flex justify-between items-center">
                        <div>
                          <Label className="mb-1 block">Development API Key</Label>
                          <div className="flex items-center">
                            <div className="bg-gray-100 text-gray-500 rounded px-3 py-1 text-sm font-mono">
                              •••••••••••••••••••••••••••••
                            </div>
                          </div>
                        </div>
                        <Button variant="outline" size="sm">
                          Show
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
              <CardFooter className="flex justify-between">
                <Button variant="outline">Regenerate Keys</Button>
                <Button>
                  <BookOpen className="h-4 w-4 mr-2" />
                  API Documentation
                </Button>
              </CardFooter>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </AppLayout>
  );
}