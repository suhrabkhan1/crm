import React from "react";
import AppLayout from "@/layout/app-layout";
import Header from "@/components/layout/header";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import {
  Users as UsersIcon,
  UserPlus,
  Search,
  Filter,
  Mail,
  UserCog,
  ShieldCheck,
  ShieldAlert,
  Clock,
  FilterX,
  Edit,
  Trash2,
} from "lucide-react";

export default function Users() {
  return (
    <AppLayout>
      <Header
        title="User Management"
        description="Add, edit, and manage user access and permissions"
        actionButton={{
          label: "Add User",
          href: "#",
          icon: <UserPlus className="h-4 w-4 mr-2" />,
        }}
      />

      <div className="p-6">
        <Tabs defaultValue="all-users">
          <div className="flex justify-between items-center mb-4">
            <TabsList>
              <TabsTrigger value="all-users">All Users</TabsTrigger>
              <TabsTrigger value="admins">Admins</TabsTrigger>
              <TabsTrigger value="members">Team Members</TabsTrigger>
              <TabsTrigger value="api-users">API Users</TabsTrigger>
              <TabsTrigger value="pending">Pending Invites</TabsTrigger>
            </TabsList>

            <div className="flex items-center gap-2">
              <div className="relative">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
                <Input
                  type="search"
                  placeholder="Search users..."
                  className="pl-9 h-9"
                />
              </div>
              <Button variant="outline" size="sm">
                <Filter className="h-4 w-4 mr-2" />
                Filter
              </Button>
            </div>
          </div>

          <TabsContent value="all-users" className="mt-0">
            <Card>
              <CardContent className="p-0">
                <div className="relative overflow-x-auto">
                  <table className="w-full text-sm text-left">
                    <thead className="text-xs text-gray-700 uppercase bg-gray-50">
                      <tr>
                        <th scope="col" className="px-6 py-3">
                          User
                        </th>
                        <th scope="col" className="px-6 py-3">
                          Email
                        </th>
                        <th scope="col" className="px-6 py-3">
                          Role
                        </th>
                        <th scope="col" className="px-6 py-3">
                          Status
                        </th>
                        <th scope="col" className="px-6 py-3">
                          Last Activity
                        </th>
                        <th scope="col" className="px-6 py-3">
                          Actions
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      {[
                        {
                          name: "John Smith",
                          email: "john@acmecorp.com",
                          role: "Admin",
                          status: "Active",
                          lastActivity: "10 minutes ago",
                        },
                        {
                          name: "Sarah Johnson",
                          email: "sarah@acmecorp.com",
                          role: "Marketing Manager",
                          status: "Active",
                          lastActivity: "2 hours ago",
                        },
                        {
                          name: "Michael Brown",
                          email: "michael@acmecorp.com",
                          role: "Analyst",
                          status: "Active",
                          lastActivity: "Yesterday",
                        },
                        {
                          name: "Emma Davis",
                          email: "emma@acmecorp.com",
                          role: "Viewer",
                          status: "Invited",
                          lastActivity: "Never",
                        },
                        {
                          name: "API User",
                          email: "api@acmecorp.com",
                          role: "API",
                          status: "Active",
                          lastActivity: "5 minutes ago",
                        },
                      ].map((user, i) => (
                        <tr
                          key={i}
                          className="bg-white border-b hover:bg-gray-50"
                        >
                          <td className="px-6 py-4 font-medium text-gray-900 whitespace-nowrap">
                            {user.name}
                          </td>
                          <td className="px-6 py-4">{user.email}</td>
                          <td className="px-6 py-4">
                            <span
                              className={`px-2 py-1 text-xs rounded-full ${
                                user.role === "Admin"
                                  ? "bg-purple-100 text-purple-800"
                                  : user.role === "API"
                                  ? "bg-blue-100 text-blue-800"
                                  : "bg-gray-100 text-gray-800"
                              }`}
                            >
                              {user.role}
                            </span>
                          </td>
                          <td className="px-6 py-4">
                            <span
                              className={`px-2 py-1 text-xs rounded-full ${
                                user.status === "Active"
                                  ? "bg-green-100 text-green-800"
                                  : "bg-yellow-100 text-yellow-800"
                              }`}
                            >
                              {user.status}
                            </span>
                          </td>
                          <td className="px-6 py-4">{user.lastActivity}</td>
                          <td className="px-6 py-4 space-x-2">
                            <Button variant="ghost" size="icon">
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="icon"
                              className="text-red-500"
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
              <CardFooter className="flex items-center justify-between border-t p-4">
                <div className="text-sm text-gray-500">
                  Showing 5 of 5 users
                </div>
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" disabled>
                    Previous
                  </Button>
                  <Button variant="outline" size="sm" disabled>
                    Next
                  </Button>
                </div>
              </CardFooter>
            </Card>
          </TabsContent>

          <TabsContent value="admins" className="mt-0">
            <Card>
              <CardHeader>
                <CardTitle>Administrators</CardTitle>
                <CardDescription>
                  Users with full access to all features and settings
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="relative overflow-x-auto">
                  <table className="w-full text-sm text-left">
                    <thead className="text-xs text-gray-700 uppercase bg-gray-50">
                      <tr>
                        <th scope="col" className="px-6 py-3">
                          User
                        </th>
                        <th scope="col" className="px-6 py-3">
                          Email
                        </th>
                        <th scope="col" className="px-6 py-3">
                          Status
                        </th>
                        <th scope="col" className="px-6 py-3">
                          Last Activity
                        </th>
                        <th scope="col" className="px-6 py-3">
                          Actions
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr className="bg-white border-b hover:bg-gray-50">
                        <td className="px-6 py-4 font-medium text-gray-900 whitespace-nowrap">
                          John Smith
                        </td>
                        <td className="px-6 py-4">john@acmecorp.com</td>
                        <td className="px-6 py-4">
                          <span className="px-2 py-1 text-xs rounded-full bg-green-100 text-green-800">
                            Active
                          </span>
                        </td>
                        <td className="px-6 py-4">10 minutes ago</td>
                        <td className="px-6 py-4 space-x-2">
                          <Button variant="ghost" size="icon">
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="text-red-500"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        <div className="mt-6 grid grid-cols-1 lg:grid-cols-3 gap-6">
          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle>Roles & Permissions</CardTitle>
              <CardDescription>
                Manage access levels and capabilities for each user role
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="relative overflow-x-auto">
                <table className="w-full text-sm text-left">
                  <thead className="text-xs text-gray-700 uppercase bg-gray-50">
                    <tr>
                      <th scope="col" className="px-6 py-3">
                        Role
                      </th>
                      <th scope="col" className="px-6 py-3">
                        Description
                      </th>
                      <th scope="col" className="px-6 py-3">
                        Users
                      </th>
                      <th scope="col" className="px-6 py-3">
                        Actions
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    {[
                      {
                        name: "Admin",
                        description: "Full access to all features and settings",
                        users: 1,
                      },
                      {
                        name: "Marketing Manager",
                        description:
                          "Can create campaigns and access analytics",
                        users: 1,
                      },
                      {
                        name: "Analyst",
                        description: "Can view analytics and reports only",
                        users: 1,
                      },
                      {
                        name: "Viewer",
                        description: "Read-only access to dashboards",
                        users: 1,
                      },
                      {
                        name: "API",
                        description: "Programmatic access via API endpoints",
                        users: 1,
                      },
                    ].map((role, i) => (
                      <tr
                        key={i}
                        className="bg-white border-b hover:bg-gray-50"
                      >
                        <td className="px-6 py-4 font-medium text-gray-900 whitespace-nowrap">
                          {role.name}
                        </td>
                        <td className="px-6 py-4">{role.description}</td>
                        <td className="px-6 py-4">{role.users}</td>
                        <td className="px-6 py-4 space-x-2">
                          <Button variant="ghost" size="sm">
                            Edit
                          </Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              
              <div className="flex justify-end mt-4">
                <Button>Create New Role</Button>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>User Access Settings</CardTitle>
              <CardDescription>
                Configure global user access preferences
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <h3 className="text-sm font-medium">Authentication</h3>

                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label>Two-Factor Authentication</Label>
                    <p className="text-sm text-gray-500">
                      Require 2FA for all admin users
                    </p>
                  </div>
                  <Switch defaultChecked />
                </div>

                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label>Single Sign-On (SSO)</Label>
                    <p className="text-sm text-gray-500">
                      Enable SSO with your identity provider
                    </p>
                  </div>
                  <Switch />
                </div>
              </div>

              <Separator />

              <div className="space-y-4">
                <h3 className="text-sm font-medium">Session Security</h3>

                <div className="grid gap-2">
                  <Label htmlFor="max-sessions">Maximum Sessions Per User</Label>
                  <select
                    id="max-sessions"
                    className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                    defaultValue="3"
                  >
                    <option value="1">1 session</option>
                    <option value="2">2 sessions</option>
                    <option value="3">3 sessions</option>
                    <option value="5">5 sessions</option>
                    <option value="10">10 sessions</option>
                  </select>
                </div>

                <div className="grid gap-2">
                  <Label htmlFor="session-timeout">Session Timeout</Label>
                  <select
                    id="session-timeout"
                    className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                    defaultValue="30"
                  >
                    <option value="15">15 minutes</option>
                    <option value="30">30 minutes</option>
                    <option value="60">1 hour</option>
                    <option value="120">2 hours</option>
                    <option value="240">4 hours</option>
                  </select>
                </div>
              </div>

              <Separator />

              <div className="space-y-4">
                <h3 className="text-sm font-medium">Invite Settings</h3>

                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label>Allow Team Members to Invite Users</Label>
                    <p className="text-sm text-gray-500">
                      Non-admin users can send invites
                    </p>
                  </div>
                  <Switch />
                </div>

                <div className="grid gap-2">
                  <Label htmlFor="invite-expiration">Invite Expiration</Label>
                  <select
                    id="invite-expiration"
                    className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                    defaultValue="7"
                  >
                    <option value="1">24 hours</option>
                    <option value="3">3 days</option>
                    <option value="7">7 days</option>
                    <option value="14">14 days</option>
                    <option value="30">30 days</option>
                  </select>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button className="w-full">Save Settings</Button>
            </CardFooter>
          </Card>
        </div>
      </div>
    </AppLayout>
  );
}