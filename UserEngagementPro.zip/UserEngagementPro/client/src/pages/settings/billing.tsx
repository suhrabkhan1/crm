import React from "react";
import AppLayout from "@/layout/app-layout";
import Header from "@/components/layout/header";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import {
  CreditCard,
  DollarSign,
  Download,
  FileText,
  AlertCircle,
  ChevronUp,
  ChevronDown,
  InfoIcon,
  Bell,
  MessageSquare,
  Users,
  BarChart,
  HardDrive,
  Check,
  Zap,
  CircleHelp,
  ArrowRight,
  Star,
} from "lucide-react";

export default function Billing() {
  return (
    <AppLayout>
      <Header
        title="Billing & Subscription"
        description="Manage your subscription, invoices, and payment methods"
      />

      <div className="p-6 space-y-6">
        <Card>
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <div>
                <CardTitle>Current Plan</CardTitle>
                <CardDescription>Your subscription details and usage</CardDescription>
              </div>
              <Badge className="text-sm py-1 px-3">Premium</Badge>
            </div>
          </CardHeader>
          <CardContent className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div>
              <h3 className="text-sm font-medium text-gray-500 mb-1">Billing Period</h3>
              <p className="font-medium">Monthly (Renews Apr 28, 2025)</p>
              <div className="mt-4 flex items-center gap-3">
                <Button variant="outline" size="sm">Cancel Plan</Button>
                <Button size="sm">Upgrade</Button>
              </div>
            </div>
            
            <div>
              <h3 className="text-sm font-medium text-gray-500 mb-1">Amount</h3>
              <p className="font-medium">$199.00 / month</p>
              <p className="text-sm text-green-600 mt-1">Save 20% with annual billing</p>
            </div>
            
            <div>
              <h3 className="text-sm font-medium text-gray-500 mb-1">Payment Method</h3>
              <div className="flex items-center gap-2">
                <div className="bg-gray-100 p-1 rounded">
                  <CreditCard className="h-4 w-4" />
                </div>
                <p className="font-medium">Visa ending in 4242</p>
              </div>
              <Button variant="link" className="h-auto p-0 text-sm mt-1">Change payment method</Button>
            </div>
          </CardContent>
        </Card>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-base">Contacts</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-end justify-between mb-2">
                <div className="text-2xl font-bold">45,892</div>
                <div className="text-sm text-gray-500">of 50,000</div>
              </div>
              <Progress value={92} className="h-2 mb-2" />
              <p className="text-sm text-gray-500">92% of your limit</p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-base">Email Sends</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-end justify-between mb-2">
                <div className="text-2xl font-bold">124,568</div>
                <div className="text-sm text-gray-500">of 200,000</div>
              </div>
              <Progress value={62} className="h-2 mb-2" />
              <p className="text-sm text-gray-500">62% of your monthly limit</p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-base">Push Notifications</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-end justify-between mb-2">
                <div className="text-2xl font-bold">85,421</div>
                <div className="text-sm text-gray-500">of 500,000</div>
              </div>
              <Progress value={17} className="h-2 mb-2" />
              <p className="text-sm text-gray-500">17% of your monthly limit</p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-base">SMS Credits</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-end justify-between mb-2">
                <div className="text-2xl font-bold">3,254</div>
                <div className="text-sm text-gray-500">of 5,000</div>
              </div>
              <Progress value={65} className="h-2 mb-2" />
              <p className="text-sm text-gray-500">65% of your monthly limit</p>
            </CardContent>
          </Card>
        </div>
        
        <Tabs defaultValue="invoices">
          <TabsList>
            <TabsTrigger value="invoices">Invoices</TabsTrigger>
            <TabsTrigger value="usage">Usage Details</TabsTrigger>
            <TabsTrigger value="plans">Plans & Pricing</TabsTrigger>
          </TabsList>
          
          <TabsContent value="invoices" className="space-y-4 mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Billing History</CardTitle>
                <CardDescription>View and download your past invoices</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="relative overflow-x-auto">
                  <table className="w-full text-sm text-left">
                    <thead className="text-xs text-gray-700 uppercase bg-gray-50">
                      <tr>
                        <th scope="col" className="px-6 py-3">Invoice</th>
                        <th scope="col" className="px-6 py-3">Date</th>
                        <th scope="col" className="px-6 py-3">Amount</th>
                        <th scope="col" className="px-6 py-3">Status</th>
                        <th scope="col" className="px-6 py-3">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {[
                        { id: 'INV-2025-04', date: 'Apr 01, 2025', amount: '$199.00', status: 'Paid' },
                        { id: 'INV-2025-03', date: 'Mar 01, 2025', amount: '$199.00', status: 'Paid' },
                        { id: 'INV-2025-02', date: 'Feb 01, 2025', amount: '$199.00', status: 'Paid' },
                        { id: 'INV-2025-01', date: 'Jan 01, 2025', amount: '$199.00', status: 'Paid' },
                        { id: 'INV-2024-12', date: 'Dec 01, 2024', amount: '$199.00', status: 'Paid' },
                      ].map((invoice, i) => (
                        <tr key={i} className="bg-white border-b hover:bg-gray-50">
                          <td className="px-6 py-4 font-medium text-gray-900 whitespace-nowrap">
                            {invoice.id}
                          </td>
                          <td className="px-6 py-4">{invoice.date}</td>
                          <td className="px-6 py-4">{invoice.amount}</td>
                          <td className="px-6 py-4">
                            <span className="px-2 py-1 text-xs rounded-full bg-green-100 text-green-800">
                              {invoice.status}
                            </span>
                          </td>
                          <td className="px-6 py-4">
                            <Button variant="ghost" size="sm">
                              <Download className="h-4 w-4 mr-2" />
                              PDF
                            </Button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Payment Methods</CardTitle>
                <CardDescription>Manage your payment methods</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between p-4 border rounded-lg mb-4">
                  <div className="flex items-center gap-3">
                    <div className="bg-gray-100 p-2 rounded">
                      <CreditCard className="h-5 w-5" />
                    </div>
                    <div>
                      <p className="font-medium">Visa ending in 4242</p>
                      <p className="text-sm text-gray-500">Expires 09/2026</p>
                    </div>
                  </div>
                  <Badge>Default</Badge>
                </div>
                
                <Button variant="outline">
                  Add Payment Method
                </Button>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Billing Contact</CardTitle>
                <CardDescription>Who should receive billing notifications</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center gap-3">
                      <div className="bg-gray-100 p-2 rounded">
                        <Bell className="h-5 w-5" />
                      </div>
                      <div>
                        <p className="font-medium">John Smith</p>
                        <p className="text-sm text-gray-500">john@acmecorp.com</p>
                      </div>
                    </div>
                    <Button variant="outline" size="sm">Edit</Button>
                  </div>
                  
                  <div className="flex items-center gap-2 text-sm text-gray-500">
                    <InfoIcon className="h-4 w-4" />
                    <p>This contact will receive all invoices and payment notifications.</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="usage" className="space-y-6 mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Usage Summary</CardTitle>
                <CardDescription>Current billing period: Apr 1, 2025 - Apr 30, 2025</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div>
                    <div className="flex justify-between mb-2">
                      <h3 className="text-sm font-medium flex items-center">
                        <Bell className="h-4 w-4 mr-2" />
                        Notifications
                      </h3>
                      <Button variant="link" className="h-auto p-0">View Details</Button>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div className="p-4 border rounded-lg">
                        <p className="text-sm text-gray-500 mb-1">Email Sends</p>
                        <div className="text-lg font-semibold mb-2">124,568 / 200,000</div>
                        <Progress value={62} className="h-2" />
                      </div>
                      <div className="p-4 border rounded-lg">
                        <p className="text-sm text-gray-500 mb-1">Push Notifications</p>
                        <div className="text-lg font-semibold mb-2">85,421 / 500,000</div>
                        <Progress value={17} className="h-2" />
                      </div>
                      <div className="p-4 border rounded-lg">
                        <p className="text-sm text-gray-500 mb-1">SMS Credits</p>
                        <div className="text-lg font-semibold mb-2">3,254 / 5,000</div>
                        <Progress value={65} className="h-2" />
                      </div>
                    </div>
                  </div>
                  
                  <Separator />
                  
                  <div>
                    <div className="flex justify-between mb-2">
                      <h3 className="text-sm font-medium flex items-center">
                        <Users className="h-4 w-4 mr-2" />
                        Contacts & Profiles
                      </h3>
                      <Button variant="link" className="h-auto p-0">View Details</Button>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="p-4 border rounded-lg">
                        <p className="text-sm text-gray-500 mb-1">Contact Profiles</p>
                        <div className="text-lg font-semibold mb-2">45,892 / 50,000</div>
                        <Progress value={92} className="h-2" />
                      </div>
                      <div className="p-4 border rounded-lg">
                        <p className="text-sm text-gray-500 mb-1">Active Users</p>
                        <div className="text-lg font-semibold mb-2">12 / 20</div>
                        <Progress value={60} className="h-2" />
                      </div>
                    </div>
                  </div>
                  
                  <Separator />
                  
                  <div>
                    <div className="flex justify-between mb-2">
                      <h3 className="text-sm font-medium flex items-center">
                        <BarChart className="h-4 w-4 mr-2" />
                        Analytics & Storage
                      </h3>
                      <Button variant="link" className="h-auto p-0">View Details</Button>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="p-4 border rounded-lg">
                        <p className="text-sm text-gray-500 mb-1">Event Data</p>
                        <div className="text-lg font-semibold mb-2">25.4 GB / 100 GB</div>
                        <Progress value={25} className="h-2" />
                      </div>
                      <div className="p-4 border rounded-lg">
                        <p className="text-sm text-gray-500 mb-1">Media Storage</p>
                        <div className="text-lg font-semibold mb-2">6.2 GB / 50 GB</div>
                        <Progress value={12} className="h-2" />
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
              <CardFooter className="justify-between">
                <div className="text-sm text-amber-600 flex items-center">
                  <AlertCircle className="h-4 w-4 mr-2" />
                  You're approaching your contact limit
                </div>
                <Button>
                  View Usage Trends
                </Button>
              </CardFooter>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Usage History</CardTitle>
                <CardDescription>View your historical usage patterns</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-64 flex items-center justify-center border-2 border-dashed rounded-lg">
                  <div className="text-center">
                    <BarChart className="h-8 w-8 mx-auto text-gray-400 mb-2" />
                    <h3 className="text-lg font-medium">Usage History Graph</h3>
                    <p className="text-sm text-gray-500">
                      Historical data visualization would appear here
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="plans" className="mt-6">
            <div className="text-center max-w-xl mx-auto mb-8">
              <h3 className="text-2xl font-bold mb-2">Choose the Right Plan</h3>
              <p className="text-gray-600">
                Select a plan that suits your business needs
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {[
                {
                  name: "Standard",
                  price: "$99",
                  description: "Great for small businesses just getting started",
                  features: [
                    "Up to 25,000 contacts",
                    "100,000 email sends per month",
                    "Basic analytics",
                    "5 team members",
                    "Email support",
                  ],
                  cta: "Downgrade",
                  popular: false,
                },
                {
                  name: "Premium",
                  price: "$199",
                  description: "Perfect for growing businesses with advanced needs",
                  features: [
                    "Up to 50,000 contacts",
                    "Unlimited email sends",
                    "Advanced analytics",
                    "A/B testing",
                    "20 team members",
                    "Priority support",
                  ],
                  cta: "Current Plan",
                  popular: true,
                },
                {
                  name: "Enterprise",
                  price: "Custom",
                  description: "For large organizations with complex requirements",
                  features: [
                    "Unlimited contacts",
                    "Unlimited everything",
                    "Custom integrations",
                    "Dedicated account manager",
                    "Unlimited team members",
                    "24/7 phone support",
                  ],
                  cta: "Contact Sales",
                  popular: false,
                },
              ].map((plan, i) => (
                <Card key={i} className={`relative ${plan.popular ? 'border-primary-500 shadow-lg' : ''}`}>
                  {plan.popular && (
                    <div className="absolute top-0 right-0 mr-6 -mt-3">
                      <Badge className="px-3 py-1">Most Popular</Badge>
                    </div>
                  )}
                  <CardHeader>
                    <CardTitle>{plan.name}</CardTitle>
                    <div className="flex items-baseline mt-2">
                      <span className="text-3xl font-bold">{plan.price}</span>
                      {plan.price !== "Custom" && <span className="text-sm text-gray-500 ml-2">/ month</span>}
                    </div>
                    <CardDescription className="mt-2">{plan.description}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-3">
                      {plan.features.map((feature, j) => (
                        <li key={j} className="flex items-start">
                          <Check className="h-4 w-4 text-green-500 mr-2 mt-1" />
                          <span>{feature}</span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                  <CardFooter>
                    <Button
                      className="w-full"
                      variant={plan.popular ? 'default' : 'outline'}
                      disabled={plan.name === "Premium"}
                    >
                      {plan.cta}
                    </Button>
                  </CardFooter>
                </Card>
              ))}
            </div>
            
            <div className="mt-12">
              <Card>
                <CardHeader>
                  <CardTitle>Frequently Asked Questions</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {[
                      {
                        q: "How do I change my subscription plan?",
                        a: "You can upgrade at any time. Downgrades take effect at the end of your current billing cycle.",
                      },
                      {
                        q: "What happens if I exceed my plan limits?",
                        a: "We'll notify you when you approach your limits. You can upgrade your plan or purchase additional credits.",
                      },
                      {
                        q: "Do you offer annual billing?",
                        a: "Yes! You can save 20% with annual billing on any of our plans.",
                      },
                      {
                        q: "Is there a contract or commitment?",
                        a: "No. All plans are month-to-month unless you choose annual billing.",
                      },
                    ].map((faq, i) => (
                      <div key={i} className="border-b pb-4 last:border-b-0 last:pb-0">
                        <div className="flex justify-between items-center cursor-pointer mb-2">
                          <h4 className="font-medium">{faq.q}</h4>
                          <ChevronDown className="h-4 w-4 text-gray-500" />
                        </div>
                        <p className="text-sm text-gray-600">{faq.a}</p>
                      </div>
                    ))}
                  </div>
                </CardContent>
                <CardFooter>
                  <div className="flex justify-between items-center w-full">
                    <div className="flex items-center">
                      <CircleHelp className="h-5 w-5 text-gray-400 mr-2" />
                      <span className="text-sm text-gray-500">Have more questions?</span>
                    </div>
                    <Button variant="link" className="p-0 h-auto">
                      Contact Support
                    </Button>
                  </div>
                </CardFooter>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </AppLayout>
  );
}