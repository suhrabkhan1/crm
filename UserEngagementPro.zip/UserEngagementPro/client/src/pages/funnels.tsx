import React, { useState } from "react";
import AppLayout from "@/layout/app-layout";
import Header from "@/components/layout/header";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle,
  CardDescription 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Plus, Edit, Trash } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { DataTable } from "@/components/ui/data-table";
import { Link } from "wouter";
import { Skeleton } from "@/components/ui/skeleton";
import { 
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { formatDateShort } from "@/lib/dates";
import { getBarColors } from "@/lib/charts";
import { cn } from "@/lib/utils";

interface Funnel {
  id: number;
  name: string;
  description: string;
  steps: { name: string; event: string }[];
  createdAt: string;
}

export default function Funnels() {
  const [selectedFunnel, setSelectedFunnel] = useState<Funnel | null>(null);
  
  const { data: funnels, isLoading } = useQuery<Funnel[]>({
    queryKey: ['/api/funnels'],
  });

  const { data: funnelStats, isLoading: isStatsLoading } = useQuery({
    queryKey: ['/api/funnels', selectedFunnel?.id, 'analytics'],
    enabled: !!selectedFunnel,
  });

  const columns = [
    {
      accessorKey: "name",
      header: "Name",
      cell: ({ row }: any) => (
        <div 
          className="font-medium cursor-pointer hover:text-primary-600"
          onClick={() => setSelectedFunnel(row.original)}
        >
          {row.getValue("name")}
        </div>
      ),
    },
    {
      accessorKey: "description",
      header: "Description",
      cell: ({ row }: any) => (
        <div className="truncate max-w-[300px]">{row.getValue("description")}</div>
      ),
    },
    {
      accessorKey: "steps",
      header: "Steps",
      cell: ({ row }: any) => <div>{row.getValue("steps").length}</div>,
    },
    {
      accessorKey: "createdAt",
      header: "Created",
      cell: ({ row }: any) => <div>{formatDateShort(row.getValue("createdAt"))}</div>,
    },
    {
      id: "actions",
      cell: ({ row }: any) => (
        <div className="flex items-center space-x-2">
          <Button variant="ghost" size="icon" asChild>
            <Link href={`/funnels/${row.original.id}/edit`}>
              <Edit className="h-4 w-4" />
              <span className="sr-only">Edit</span>
            </Link>
          </Button>
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button variant="ghost" size="icon">
                <Trash className="h-4 w-4" />
                <span className="sr-only">Delete</span>
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                <AlertDialogDescription>
                  This will permanently delete the funnel "{row.original.name}".
                  This action cannot be undone.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Cancel</AlertDialogCancel>
                <AlertDialogAction>Delete</AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </div>
      ),
    },
  ];

  return (
    <AppLayout>
      <Header 
        title="Funnels" 
        description="Track and optimize user conversion paths"
        actionButton={{
          label: "Create Funnel",
          href: "/funnels/create",
          icon: <Plus className="h-4 w-4 mr-2" />,
        }}
      />

      <div className="py-6 px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-1">
            <Card>
              <CardHeader>
                <CardTitle>All Funnels</CardTitle>
                <CardDescription>
                  View and manage your conversion funnels
                </CardDescription>
              </CardHeader>
              <CardContent>
                {isLoading ? (
                  <div className="space-y-4">
                    <Skeleton className="h-10 w-full" />
                    <Skeleton className="h-32 w-full" />
                    <Skeleton className="h-10 w-full" />
                  </div>
                ) : (
                  <DataTable 
                    columns={columns} 
                    data={funnels || []} 
                    searchColumn="name"
                    searchPlaceholder="Search funnels..."
                  />
                )}
              </CardContent>
            </Card>
          </div>

          <div className="lg:col-span-2">
            <Card className="h-full">
              <CardHeader>
                <CardTitle>
                  {selectedFunnel ? selectedFunnel.name : "Funnel Analytics"}
                </CardTitle>
                <CardDescription>
                  {selectedFunnel 
                    ? selectedFunnel.description 
                    : "Select a funnel to view detailed analytics"}
                </CardDescription>
              </CardHeader>
              <CardContent>
                {!selectedFunnel ? (
                  <div className="h-80 flex items-center justify-center border-2 border-dashed rounded-lg">
                    <div className="text-center">
                      <p className="text-gray-500">Select a funnel from the list to view analytics</p>
                    </div>
                  </div>
                ) : isStatsLoading ? (
                  <div className="space-y-4">
                    <Skeleton className="h-80 w-full" />
                  </div>
                ) : (
                  <div>
                    <div className="h-80">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart
                          layout="vertical"
                          data={funnelStats?.steps || []}
                          margin={{
                            top: 20,
                            right: 30,
                            left: 20,
                            bottom: 5,
                          }}
                        >
                          <CartesianGrid strokeDasharray="3 3" horizontal={true} vertical={false} opacity={0.2} />
                          <XAxis
                            type="number"
                            tickFormatter={(value) => `${value}%`}
                            domain={[0, 100]}
                          />
                          <YAxis
                            dataKey="name"
                            type="category"
                            width={150}
                          />
                          <Tooltip 
                            formatter={(value: any) => [`${value}%`, 'Conversion']}
                          />
                          <Bar
                            dataKey="value"
                            fill={getBarColors()[0]}
                            radius={[0, 4, 4, 0]}
                            barSize={20}
                          />
                        </BarChart>
                      </ResponsiveContainer>
                    </div>

                    <div className="mt-6 space-y-4">
                      {funnelStats?.steps?.map((step: any, idx: number) => (
                        <div key={idx} className="flex items-center">
                          <div className="w-1/3 text-sm font-medium">{step.name}</div>
                          <div className="w-2/3">
                            <div className="h-6 bg-gray-100 rounded-full overflow-hidden">
                              <div 
                                className={cn("h-full rounded-full", `bg-primary-${600 - idx * 100}`)} 
                                style={{ width: `${step.value}%` }}
                              ></div>
                            </div>
                            <div className="mt-1 flex justify-between text-xs text-gray-500">
                              <div>{step.value}%</div>
                              {idx > 0 && (
                                <div className="text-red-500">
                                  -{(funnelStats.steps[idx-1].value - step.value).toFixed(1)}%
                                </div>
                              )}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </AppLayout>
  );
}
