import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatNumber(num: number): string {
  if (num >= 1000000) {
    return (num / 1000000).toFixed(1) + 'M';
  }
  if (num >= 1000) {
    return (num / 1000).toFixed(1) + 'K';
  }
  return num.toString();
}

export function formatPercentage(num: number): string {
  return num.toFixed(1) + '%';
}

export function getStatusColor(status: string): string {
  const statusMap: Record<string, string> = {
    active: 'bg-green-100 text-green-800',
    completed: 'bg-gray-100 text-gray-800',
    scheduled: 'bg-yellow-100 text-yellow-800',
    draft: 'bg-blue-100 text-blue-800',
    paused: 'bg-orange-100 text-orange-800',
    failed: 'bg-red-100 text-red-800',
    live: 'bg-blue-100 text-blue-800',
    behavior: 'bg-purple-100 text-purple-800',
    profile: 'bg-green-100 text-green-800'
  };
  
  return statusMap[status.toLowerCase()] || 'bg-gray-100 text-gray-800';
}

export function truncateText(text: string, length: number = 30): string {
  if (text.length <= length) return text;
  return text.substring(0, length) + '...';
}

export function getChannelIcon(channel: string): string {
  const channelMap: Record<string, string> = {
    email: 'mail',
    push: 'bell',
    'in-app': 'smartphone',
    sms: 'message-square',
    whatsapp: 'message-circle',
    'web-push': 'globe',
    'web-popup': 'layout',
    'app-inbox': 'inbox'
  };
  
  return channelMap[channel.toLowerCase()] || 'bell';
}

// This variant of the function is used by React components to get the icon as a JSX element
export function getChannelIconJSX(channel: string): any {
  // Components will provide their own implementation
  return null;
}

export function delay(ms: number): Promise<void> {
  return new Promise(resolve => setTimeout(resolve, ms));
}

export function getRandomId(): string {
  return Math.random().toString(36).substring(2, 9);
}

export function isValidEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

export function generateAvatarUrl(name: string): string {
  // This would typically use a real avatar service
  // For now we'll use a placeholder
  return `https://ui-avatars.com/api/?name=${encodeURIComponent(name)}&background=5046e5&color=fff`;
}
