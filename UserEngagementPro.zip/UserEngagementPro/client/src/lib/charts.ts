import { type ChartData, type ChartOptions } from "recharts";

export const generateUserEngagementData = (days: number = 30): any[] => {
  const data = [];
  const now = new Date();
  
  for (let i = days - 1; i >= 0; i--) {
    const date = new Date(now);
    date.setDate(date.getDate() - i);
    
    const activeUsersBase = 150000 + Math.random() * 25000;
    const sessionsBase = activeUsersBase * (1.3 + Math.random() * 0.4);
    
    // Add some weekly patterns
    const dayOfWeek = date.getDay();
    const isWeekend = dayOfWeek === 0 || dayOfWeek === 6;
    const weekendFactor = isWeekend ? 0.85 : 1;
    
    // Add a general upward trend
    const trendFactor = 1 + (i / days) * 0.15;
    
    data.push({
      date: date.toISOString().slice(0, 10),
      label: date.toISOString().slice(5, 10).replace("-", "/"),
      activeUsers: Math.round(activeUsersBase * weekendFactor / trendFactor),
      sessions: Math.round(sessionsBase * weekendFactor / trendFactor)
    });
  }
  
  return data;
};

export const channelPerformanceData = [
  { channel: "Push", openRate: 18, clickRate: 4.8 },
  { channel: "Email", openRate: 62, clickRate: 8.2 },
  { channel: "SMS", openRate: 98, clickRate: 7.5 },
  { channel: "In-App", openRate: 52, clickRate: 3.2 },
  { channel: "WhatsApp", openRate: 94, clickRate: 12.8 }
];

export const registrationFunnelData = [
  { step: "App Visit", value: 100 },
  { step: "Registration Start", value: 68.4 },
  { step: "Form Completion", value: 42.3 },
  { step: "Verification", value: 36.7 },
  { step: "Registration Complete", value: 28.5 }
];

export const purchaseFunnelData = [
  { step: "Product View", value: 100 },
  { step: "Add to Cart", value: 25.7 },
  { step: "Checkout Start", value: 14.2 },
  { step: "Payment Info", value: 8.5 },
  { step: "Purchase Complete", value: 5.3 }
];

export const onboardingFunnelData = [
  { step: "First Login", value: 100 },
  { step: "Profile Setup", value: 84.2 },
  { step: "Feature Tour", value: 56.8 },
  { step: "First Action", value: 38.9 },
  { step: "Recurring User", value: 22.4 }
];

export const funnelOptions: { [key: string]: any[] } = {
  "Registration Flow": registrationFunnelData,
  "Purchase Flow": purchaseFunnelData,
  "Onboarding Flow": onboardingFunnelData
};

export const cohortRetentionData = [
  { 
    cohort: "Jun 22 - Jun 28", 
    users: 4825,
    retention: [100, 62, 41, 28] 
  },
  { 
    cohort: "Jun 15 - Jun 21", 
    users: 5114,
    retention: [100, 58, 39, 25] 
  },
  { 
    cohort: "Jun 8 - Jun 14", 
    users: 4652,
    retention: [100, 60, 36, 24] 
  },
  { 
    cohort: "Jun 1 - Jun 7", 
    users: 5268,
    retention: [100, 64, 43, 30] 
  }
];

export const getBarColors = () => {
  return ["#5046e5", "#6455ef", "#8b7ff3", "#b1aaf7", "#d8d5fb"];
};

export const getLegendColors = () => {
  return ["#5046e5", "#2dd4bf"];
};

export const getLineChartOptions = (): ChartOptions => {
  return {
    responsive: true,
    plugins: {
      legend: {
        position: "top",
      },
      tooltip: {
        mode: "index",
        intersect: false,
      }
    },
    scales: {
      y: {
        beginAtZero: false,
        ticks: {
          callback: function(value: any) {
            return value / 1000 + 'k';
          }
        }
      }
    },
    interaction: {
      mode: "nearest",
      axis: "x",
      intersect: false
    }
  };
};
