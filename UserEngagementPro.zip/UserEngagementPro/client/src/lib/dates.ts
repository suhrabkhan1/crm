import { format, subDays, subMonths, startOfDay, endOfDay, isToday, isYesterday, isThisWeek, isThisMonth } from "date-fns";

export type DateRangeOption = "today" | "yesterday" | "last7days" | "last30days" | "thisMonth" | "lastMonth" | "custom";

export interface DateRange {
  start: Date;
  end: Date;
  label: string;
}

export const getDateRange = (option: DateRangeOption, customRange?: { start: Date; end: Date }): DateRange => {
  const now = new Date();
  
  switch (option) {
    case "today":
      return {
        start: startOfDay(now),
        end: endOfDay(now),
        label: "Today"
      };
    case "yesterday":
      const yesterday = subDays(now, 1);
      return {
        start: startOfDay(yesterday),
        end: endOfDay(yesterday),
        label: "Yesterday"
      };
    case "last7days":
      return {
        start: startOfDay(subDays(now, 6)),
        end: endOfDay(now),
        label: "Last 7 days"
      };
    case "last30days":
      return {
        start: startOfDay(subDays(now, 29)),
        end: endOfDay(now),
        label: "Last 30 days"
      };
    case "thisMonth":
      return {
        start: startOfDay(new Date(now.getFullYear(), now.getMonth(), 1)),
        end: endOfDay(now),
        label: "This Month"
      };
    case "lastMonth":
      const lastMonth = subMonths(now, 1);
      return {
        start: startOfDay(new Date(lastMonth.getFullYear(), lastMonth.getMonth(), 1)),
        end: endOfDay(new Date(lastMonth.getFullYear(), lastMonth.getMonth() + 1, 0)),
        label: "Last Month"
      };
    case "custom":
      if (!customRange) {
        throw new Error("Custom range requires start and end dates");
      }
      return {
        start: startOfDay(customRange.start),
        end: endOfDay(customRange.end),
        label: `${format(customRange.start, "MMM d, yyyy")} - ${format(customRange.end, "MMM d, yyyy")}`
      };
    default:
      return {
        start: startOfDay(subDays(now, 29)),
        end: endOfDay(now),
        label: "Last 30 days"
      };
  }
};

export const formatDate = (date: Date | string): string => {
  const dateObj = typeof date === "string" ? new Date(date) : date;
  
  if (isToday(dateObj)) {
    return `Today, ${format(dateObj, "h:mm a")}`;
  } else if (isYesterday(dateObj)) {
    return `Yesterday, ${format(dateObj, "h:mm a")}`;
  } else if (isThisWeek(dateObj)) {
    return format(dateObj, "EEEE, h:mm a");
  } else if (isThisMonth(dateObj)) {
    return format(dateObj, "MMM d, h:mm a");
  } else {
    return format(dateObj, "MMM d, yyyy");
  }
};

export const formatDateShort = (date: Date | string): string => {
  const dateObj = typeof date === "string" ? new Date(date) : date;
  return format(dateObj, "MMM d");
};
