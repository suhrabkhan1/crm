import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer 
} from 'recharts';
import { useQuery } from '@tanstack/react-query';
import { Skeleton } from '@/components/ui/skeleton';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { funnelOptions } from '@/lib/charts';

export const FunnelAnalysis: React.FC = () => {
  const [selectedFunnel, setSelectedFunnel] = useState<string>("Registration Flow");
  
  // In a real app, we would fetch from API based on the selected funnel
  // Here we're using mock data
  const { data, isLoading } = useQuery({
    queryKey: ['/api/funnels/analytics', selectedFunnel],
    queryFn: () => Promise.resolve(funnelOptions[selectedFunnel] || [])
  });

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-lg font-medium">Conversion Funnel</CardTitle>
        <div className="flex">
          <Select
            value={selectedFunnel}
            onValueChange={setSelectedFunnel}
          >
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Select funnel" />
            </SelectTrigger>
            <SelectContent>
              {Object.keys(funnelOptions).map((key) => (
                <SelectItem key={key} value={key}>{key}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="w-full h-[280px] flex items-center justify-center">
            <Skeleton className="h-[280px] w-full" />
          </div>
        ) : (
          <>
            <div className="h-[280px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  layout="vertical"
                  data={data}
                  margin={{
                    top: 5,
                    right: 30,
                    left: 20,
                    bottom: 5,
                  }}
                >
                  <CartesianGrid strokeDasharray="3 3" horizontal={true} vertical={false} opacity={0.2} />
                  <XAxis
                    type="number"
                    tickFormatter={(value) => `${value}%`}
                    domain={[0, 100]}
                    tick={{ fontSize: 12 }}
                    tickLine={false}
                    axisLine={{ stroke: '#e2e8f0' }}
                  />
                  <YAxis
                    dataKey="step"
                    type="category"
                    tick={{ fontSize: 12 }}
                    tickLine={false}
                    axisLine={{ stroke: '#e2e8f0' }}
                    width={120}
                  />
                  <Tooltip
                    formatter={(value: any) => [`${value}%`, 'Conversion']}
                    contentStyle={{
                      backgroundColor: 'white',
                      border: '1px solid #e2e8f0',
                      borderRadius: '6px',
                      boxShadow: '0 1px 2px 0 rgba(0, 0, 0, 0.05)'
                    }}
                  />
                  <Bar
                    dataKey="value"
                    fill="#5046e5"
                    radius={[0, 4, 4, 0]}
                    barSize={20}
                    animationDuration={500}
                  />
                </BarChart>
              </ResponsiveContainer>
            </div>
            <div className="mt-6 space-y-4 text-sm">
              {data?.map((item, index) => (
                <div key={index} className="flex justify-between items-center">
                  <span className="text-gray-700">{item.step}</span>
                  <span className="font-medium">{item.value}%</span>
                </div>
              ))}
            </div>
          </>
        )}
      </CardContent>
    </Card>
  );
};

export default FunnelAnalysis;
