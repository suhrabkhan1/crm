import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useQuery } from '@tanstack/react-query';
import { Skeleton } from '@/components/ui/skeleton';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { cohortRetentionData } from '@/lib/charts';

type CohortPeriod = 'weekly' | 'monthly' | 'quarterly';

export const CohortRetention: React.FC = () => {
  const [period, setPeriod] = useState<CohortPeriod>('weekly');
  
  // In a real app, we would fetch from API based on the selected period
  // Here we're using mock data
  const { data, isLoading } = useQuery({
    queryKey: ['/api/analytics/cohort-retention', period],
    queryFn: () => Promise.resolve(cohortRetentionData)
  });

  const getColorClass = (value: number) => {
    const colors = [
      "bg-primary-600", // 100%
      "bg-primary-500", // 60-80%
      "bg-primary-400", // 40-60%
      "bg-primary-300"  // 20-40%
    ];
    
    if (value === 100) return colors[0];
    if (value >= 60) return colors[1];
    if (value >= 40) return colors[2];
    return colors[3];
  };

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-lg font-medium">Cohort Retention</CardTitle>
        <div className="flex">
          <Select
            value={period}
            onValueChange={(value) => setPeriod(value as CohortPeriod)}
          >
            <SelectTrigger className="w-[120px]">
              <SelectValue placeholder="Select period" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="weekly">Weekly</SelectItem>
              <SelectItem value="monthly">Monthly</SelectItem>
              <SelectItem value="quarterly">Quarterly</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </CardHeader>
      <CardContent className="px-0">
        {isLoading ? (
          <div className="p-4">
            <Skeleton className="h-[240px] w-full" />
          </div>
        ) : (
          <div className="overflow-x-auto">
            <div className="inline-block min-w-full align-middle">
              <div className="overflow-hidden shadow-sm ring-1 ring-black ring-opacity-5">
                <table className="min-w-full divide-y divide-gray-300">
                  <thead className="bg-gray-50">
                    <tr>
                      <th scope="col" className="py-2 pl-4 pr-3 text-left text-xs font-semibold text-gray-900 sm:pl-6">Cohort</th>
                      <th scope="col" className="px-3 py-2 text-left text-xs font-semibold text-gray-900">Users</th>
                      <th scope="col" className="px-3 py-2 text-left text-xs font-semibold text-gray-900">Week 1</th>
                      <th scope="col" className="px-3 py-2 text-left text-xs font-semibold text-gray-900">Week 2</th>
                      <th scope="col" className="px-3 py-2 text-left text-xs font-semibold text-gray-900">Week 3</th>
                      <th scope="col" className="px-3 py-2 text-left text-xs font-semibold text-gray-900">Week 4</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-200 bg-white">
                    {data?.map((cohort, index) => (
                      <tr key={index}>
                        <td className="whitespace-nowrap py-2 pl-4 pr-3 text-sm font-medium text-gray-900 sm:pl-6">{cohort.cohort}</td>
                        <td className="whitespace-nowrap px-3 py-2 text-sm text-gray-500">{cohort.users.toLocaleString()}</td>
                        {cohort.retention.map((value, idx) => (
                          <td key={idx} className="whitespace-nowrap px-3 py-2 text-sm text-gray-500">
                            <div className={`${getColorClass(value)} rounded text-xs px-2 py-1 text-white font-medium`}>
                              {value}%
                            </div>
                          </td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default CohortRetention;
