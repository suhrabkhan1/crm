import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useQuery } from '@tanstack/react-query';
import { Skeleton } from '@/components/ui/skeleton';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Bell, Mail, MessageSquare, Smartphone, MessageCircle, BarChart2 } from 'lucide-react';

type Channel = 'all' | 'push' | 'email' | 'sms' | 'in-app' | 'whatsapp';

// The actual response structure from the API
interface MessageStats {
  totalSent: number;
  delivered: number;
  opened: number;
  clicked: number;
  converted: number;
  openRate: number;
  clickRate: number;
  conversionRate: number;
}

// Sample data for different channels
const channelData = [
  { name: "Welcome Email", channel: "email", delivered: 24650, openRate: 45.8, clickRate: 12.3, conversionRate: 3.2 },
  { name: "New Feature", channel: "push", delivered: 18432, openRate: 38.2, clickRate: 8.7, conversionRate: 2.1 },
  { name: "Weekly Update", channel: "in-app", delivered: 22150, openRate: 52.4, clickRate: 15.6, conversionRate: 4.8 },
  { name: "Discount Offer", channel: "sms", delivered: 8975, openRate: 98.2, clickRate: 6.5, conversionRate: 1.8 },
  { name: "Order Confirmation", channel: "whatsapp", delivered: 4545, openRate: 99.5, clickRate: 3.2, conversionRate: 0.9 }
];

export const MessagePerformance: React.FC = () => {
  const [channel, setChannel] = useState<Channel>('all');
  
  // We're using local data instead of API data for now
  const [isLoading, setIsLoading] = useState(false);

  const getMessageChannelIcon = (channel: string) => {
    switch (channel.toLowerCase()) {
      case 'push':
        return <Bell className="text-gray-400 mr-1" />;
      case 'email':
        return <Mail className="text-gray-400 mr-1" />;
      case 'sms':
        return <MessageSquare className="text-gray-400 mr-1" />;
      case 'in-app':
        return <Smartphone className="text-gray-400 mr-1" />;
      case 'whatsapp':
        return <MessageCircle className="text-gray-400 mr-1" />;
      default:
        return <Bell className="text-gray-400 mr-1" />;
    }
  };

  return (
    <Card className="col-span-1 lg:col-span-2">
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-lg font-medium">Message Performance</CardTitle>
        <div className="flex space-x-2">
          <Select
            value={channel}
            onValueChange={(value) => setChannel(value as Channel)}
          >
            <SelectTrigger className="w-[160px]">
              <SelectValue placeholder="Select channel" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Channels</SelectItem>
              <SelectItem value="push">Push Notifications</SelectItem>
              <SelectItem value="email">Email</SelectItem>
              <SelectItem value="sms">SMS</SelectItem>
              <SelectItem value="in-app">In-App</SelectItem>
              <SelectItem value="whatsapp">WhatsApp</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </CardHeader>
      <CardContent className="px-0">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead>
              <tr>
                <th scope="col" className="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Message</th>
                <th scope="col" className="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Channel</th>
                <th scope="col" className="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Delivered</th>
                <th scope="col" className="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Open Rate</th>
                <th scope="col" className="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">CTR</th>
                <th scope="col" className="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Conv.</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {isLoading ? (
                Array(5).fill(0).map((_, i) => (
                  <tr key={i} className="hover:bg-gray-50">
                    <td className="px-3 py-3 whitespace-nowrap">
                      <Skeleton className="h-4 w-48" />
                    </td>
                    <td className="px-3 py-3 whitespace-nowrap">
                      <Skeleton className="h-4 w-24" />
                    </td>
                    <td className="px-3 py-3 whitespace-nowrap">
                      <Skeleton className="h-4 w-16" />
                    </td>
                    <td className="px-3 py-3 whitespace-nowrap">
                      <Skeleton className="h-4 w-16" />
                    </td>
                    <td className="px-3 py-3 whitespace-nowrap">
                      <Skeleton className="h-4 w-12" />
                    </td>
                    <td className="px-3 py-3 whitespace-nowrap">
                      <Skeleton className="h-4 w-12" />
                    </td>
                  </tr>
                ))
              ) : (
                // Use the sample data we defined since the API returns aggregated stats
                channelData
                  .filter(message => channel === 'all' || message.channel === channel)
                  .map((message, index) => (
                    <tr key={index} className="hover:bg-gray-50">
                      <td className="px-3 py-3 whitespace-nowrap text-sm font-medium text-gray-900">
                        {message.name}
                      </td>
                      <td className="px-3 py-3 whitespace-nowrap text-sm text-gray-500">
                        <div className="flex items-center">
                          {getMessageChannelIcon(message.channel)}
                          {message.channel.charAt(0).toUpperCase() + message.channel.slice(1)}
                        </div>
                      </td>
                      <td className="px-3 py-3 whitespace-nowrap text-sm text-gray-500">
                        {message.delivered.toLocaleString()}
                      </td>
                      <td className="px-3 py-3 whitespace-nowrap text-sm text-gray-500">
                        {message.openRate.toFixed(1)}%
                      </td>
                      <td className="px-3 py-3 whitespace-nowrap text-sm text-gray-500">
                        {message.clickRate.toFixed(1)}%
                      </td>
                      <td className="px-3 py-3 whitespace-nowrap text-sm text-gray-500">
                        {message.conversionRate.toFixed(1)}%
                      </td>
                    </tr>
                  ))
              )}

              {!isLoading && channelData.filter(message => channel === 'all' || message.channel === channel).length === 0 && (
                <tr>
                  <td colSpan={6} className="px-3 py-6 text-center text-sm text-gray-500">
                    No messages found for the selected channel.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </CardContent>
    </Card>
  );
};

export default MessagePerformance;
