import React from 'react';
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { useQuery } from '@tanstack/react-query';
import { Link } from 'wouter';
import { 
  Users, 
  Bell, 
  MousePointerClick, 
  BarChart, 
  ArrowUp, 
  ArrowDown 
} from 'lucide-react';
import { formatNumber } from '@/lib/utils';
import { Skeleton } from '@/components/ui/skeleton';

interface StatCardProps {
  icon: React.ReactNode;
  iconBgColor: string;
  iconTextColor: string;
  title: string;
  value: string | number;
  trend?: number;
  linkHref: string;
  linkText: string;
}

const StatCard: React.FC<StatCardProps> = ({
  icon,
  iconBgColor,
  iconTextColor,
  title,
  value,
  trend,
  linkHref,
  linkText
}) => {
  return (
    <Card>
      <CardContent className="pt-6">
        <div className="flex items-center">
          <div className={`flex-shrink-0 ${iconBgColor} rounded-md p-3`}>
            <div className={iconTextColor}>{icon}</div>
          </div>
          <div className="ml-5 w-0 flex-1">
            <dl>
              <dt className="text-sm font-medium text-gray-500 truncate">{title}</dt>
              <dd className="flex items-baseline">
                <div className="text-2xl font-semibold text-gray-900">{value}</div>
                {trend !== undefined && (
                  <div className={`ml-2 flex items-baseline text-sm font-semibold ${trend >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                    {trend >= 0 ? <ArrowUp className="h-4 w-4" /> : <ArrowDown className="h-4 w-4" />}
                    <span className="sr-only">{trend >= 0 ? 'Increased by' : 'Decreased by'}</span>
                    {Math.abs(trend).toFixed(1)}%
                  </div>
                )}
              </dd>
            </dl>
          </div>
        </div>
      </CardContent>
      <CardFooter className="bg-gray-50 px-6 py-2">
        <div className="text-sm">
          <Link href={linkHref} className="font-medium text-primary-600 hover:text-primary-500">
            {linkText}
          </Link>
        </div>
      </CardFooter>
    </Card>
  );
};

export const QuickStats: React.FC = () => {
  const { data, isLoading, error } = useQuery({
    queryKey: ['/api/analytics/user-stats'],
  });

  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        {[...Array(4)].map((_, i) => (
          <Card key={i}>
            <CardContent className="pt-6">
              <div className="flex items-center">
                <Skeleton className="h-12 w-12 rounded-md" />
                <div className="ml-5 w-0 flex-1">
                  <Skeleton className="h-4 w-28 mb-2" />
                  <Skeleton className="h-7 w-20" />
                </div>
              </div>
            </CardContent>
            <CardFooter className="bg-gray-50 px-6 py-2">
              <Skeleton className="h-4 w-24" />
            </CardFooter>
          </Card>
        ))}
      </div>
    );
  }

  if (error) {
    return <div>Error loading stats</div>;
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
      <StatCard
        icon={<Users className="h-5 w-5" />}
        iconBgColor="bg-primary-100"
        iconTextColor="text-primary-600"
        title="Active Users"
        value={formatNumber(data.activeUsers)}
        trend={data.userGrowth}
        linkHref="/cohorts"
        linkText="View all"
      />
      
      <StatCard
        icon={<Bell className="h-5 w-5" />}
        iconBgColor="bg-secondary-100"
        iconTextColor="text-secondary-600"
        title="Campaigns Active"
        value={data.activeCampaigns}
        trend={data.campaignGrowth}
        linkHref="/campaigns"
        linkText="View campaigns"
      />
      
      <StatCard
        icon={<MousePointerClick className="h-5 w-5" />}
        iconBgColor="bg-primary-100"
        iconTextColor="text-primary-600"
        title="Conversion Rate"
        value={`${data.conversionRate}%`}
        trend={data.conversionTrend}
        linkHref="/funnels"
        linkText="View conversions"
      />
      
      <StatCard
        icon={<BarChart className="h-5 w-5" />}
        iconBgColor="bg-secondary-100"
        iconTextColor="text-secondary-600"
        title="Engagement Score"
        value={data.engagementScore}
        trend={data.engagementTrend}
        linkHref="/events"
        linkText="View details"
      />
    </div>
  );
};

export default QuickStats;
