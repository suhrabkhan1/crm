import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Link } from 'wouter';
import { useQuery } from '@tanstack/react-query';
import { Skeleton } from '@/components/ui/skeleton';
import { Zap } from 'lucide-react';
import { formatNumber } from '@/lib/utils';

interface Event {
  name: string;
  dailyAvg: number;
  trend: number;
}

// Sample event data since API doesn't return in format we need
const sampleEvents: Event[] = [
  { name: "App Opened", dailyAvg: 28450, trend: 12.4 },
  { name: "Product Viewed", dailyAvg: 18920, trend: 8.7 },
  { name: "Add to Cart", dailyAvg: 7840, trend: -3.2 },
  { name: "Checkout Started", dailyAvg: 4560, trend: 5.1 },
  { name: "Purchase Completed", dailyAvg: 2340, trend: 9.8 }
];

export const TopEvents: React.FC = () => {
  // We're not using the API data directly since it returns a Record<string, number>
  const [isLoading, setIsLoading] = React.useState(false);
  const eventData = sampleEvents;

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-lg font-medium">Top Events</CardTitle>
        <Link href="/events" className="text-sm font-medium text-primary-600 hover:text-primary-500">
          View all
        </Link>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="space-y-4">
            {Array(5).fill(0).map((_, i) => (
              <div key={i} className="flex justify-between items-center py-3">
                <div className="flex items-center">
                  <Skeleton className="h-10 w-10 rounded-md" />
                  <div className="ml-4">
                    <Skeleton className="h-4 w-24 mb-1" />
                    <Skeleton className="h-3 w-32" />
                  </div>
                </div>
                <Skeleton className="h-4 w-12" />
              </div>
            ))}
          </div>
        ) : (
          <ul className="divide-y divide-gray-200">
            {eventData.map((event, index) => (
              <li key={index} className="py-3 flex justify-between items-center">
                <div className="flex items-center">
                  <div className="flex-shrink-0 h-10 w-10 rounded-md bg-primary-100 flex items-center justify-center">
                    <Zap className="text-primary-600" />
                  </div>
                  <div className="ml-4">
                    <h4 className="text-sm font-medium text-gray-900">{event.name}</h4>
                    <p className="text-xs text-gray-500">Daily average: {formatNumber(event.dailyAvg)}</p>
                  </div>
                </div>
                <div className="text-sm text-gray-500 font-medium">
                  <span className={event.trend >= 0 ? 'text-green-600' : 'text-red-600'}>
                    {event.trend >= 0 ? '+' : ''}{event.trend}%
                  </span>
                </div>
              </li>
            ))}

            {!isLoading && eventData.length === 0 && (
              <li className="py-6 text-center text-sm text-gray-500">
                No events tracked yet. Set up event tracking to get started.
              </li>
            )}
          </ul>
        )}
      </CardContent>
    </Card>
  );
};

export default TopEvents;
