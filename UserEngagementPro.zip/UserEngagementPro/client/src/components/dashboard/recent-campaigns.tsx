import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Link } from 'wouter';
import { useQuery } from '@tanstack/react-query';
import { getStatusColor, getChannelIconJSX } from '@/lib/utils';
import { Skeleton } from '@/components/ui/skeleton';
import { Bell, Mail, MessageSquare, Smartphone, Globe } from 'lucide-react';

interface Campaign {
  id: number;
  name: string;
  status: string;
  channel: string;
  sentCount?: number;
  clickRate?: number;
}

// Implement a local version of the getChannelIconJSX function
const getLocalChannelIcon = (channel: string) => {
  switch (channel.toLowerCase()) {
    case 'push':
      return <Bell className="h-4 w-4 text-gray-400" />;
    case 'email':
      return <Mail className="h-4 w-4 text-gray-400" />;
    case 'sms':
      return <MessageSquare className="h-4 w-4 text-gray-400" />;
    case 'in-app':
      return <Smartphone className="h-4 w-4 text-gray-400" />;
    case 'web-push':
      return <Globe className="h-4 w-4 text-gray-400" />;
    default:
      return <Bell className="h-4 w-4 text-gray-400" />;
  }
};

export const RecentCampaigns: React.FC = () => {
  const { data, isLoading } = useQuery<Campaign[]>({
    queryKey: ['/api/campaigns'],
  });

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-lg font-medium">Recent Campaigns</CardTitle>
        <Link href="/campaigns" className="text-sm font-medium text-primary-600 hover:text-primary-500">
          View all
        </Link>
      </CardHeader>
      <CardContent className="px-0">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead>
              <tr>
                <th scope="col" className="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Campaign</th>
                <th scope="col" className="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                <th scope="col" className="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Sent</th>
                <th scope="col" className="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">CTR</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {isLoading ? (
                Array(5).fill(0).map((_, i) => (
                  <tr key={i} className="hover:bg-gray-50">
                    <td className="px-3 py-3 whitespace-nowrap">
                      <Skeleton className="h-4 w-48" />
                    </td>
                    <td className="px-3 py-3 whitespace-nowrap">
                      <Skeleton className="h-4 w-20" />
                    </td>
                    <td className="px-3 py-3 whitespace-nowrap">
                      <Skeleton className="h-4 w-16" />
                    </td>
                    <td className="px-3 py-3 whitespace-nowrap">
                      <Skeleton className="h-4 w-12" />
                    </td>
                  </tr>
                ))
              ) : (
                data?.map((campaign) => (
                  <tr key={campaign.id} className="hover:bg-gray-50">
                    <td className="px-3 py-3 whitespace-nowrap text-sm font-medium text-gray-900">
                      <div className="flex items-center">
                        {getLocalChannelIcon(campaign.channel)}
                        <span className="ml-2">{campaign.name}</span>
                      </div>
                    </td>
                    <td className="px-3 py-3 whitespace-nowrap text-sm text-gray-500">
                      <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${getStatusColor(campaign.status)}`}>
                        {campaign.status.charAt(0).toUpperCase() + campaign.status.slice(1)}
                      </span>
                    </td>
                    <td className="px-3 py-3 whitespace-nowrap text-sm text-gray-500">
                      {campaign.status === 'scheduled' ? '--' : (campaign.sentCount?.toLocaleString() || '0')}
                    </td>
                    <td className="px-3 py-3 whitespace-nowrap text-sm text-gray-500">
                      {campaign.status === 'scheduled' ? '--' : `${campaign.clickRate || 0}%`}
                    </td>
                  </tr>
                ))
              )}

              {!isLoading && (!data || data.length === 0) && (
                <tr>
                  <td colSpan={4} className="px-3 py-6 text-center text-sm text-gray-500">
                    No campaigns found. <Link href="/campaigns/create" className="text-primary-600 hover:text-primary-500">Create one</Link>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </CardContent>
    </Card>
  );
};

export default RecentCampaigns;
