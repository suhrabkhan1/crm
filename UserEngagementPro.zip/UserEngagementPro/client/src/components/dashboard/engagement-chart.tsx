import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend } from 'recharts';
import { useQuery } from '@tanstack/react-query';
import { Skeleton } from '@/components/ui/skeleton';
import { generateUserEngagementData } from '@/lib/charts';

type Period = 'daily' | 'weekly' | 'monthly';

export const EngagementChart: React.FC = () => {
  const [period, setPeriod] = useState<Period>('daily');
  
  // In a real app, we would fetch from API with the selected period
  // Here we're using mock data
  const { data, isLoading } = useQuery({
    queryKey: ['/api/analytics/engagement', period],
    queryFn: () => Promise.resolve(generateUserEngagementData(30))
  });

  return (
    <Card className="col-span-1 lg:col-span-2">
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-lg font-medium">User Engagement</CardTitle>
        <div className="flex space-x-2 text-sm">
          <Button 
            variant={period === 'daily' ? 'secondary' : 'ghost'} 
            size="sm"
            onClick={() => setPeriod('daily')}
          >
            Daily
          </Button>
          <Button 
            variant={period === 'weekly' ? 'secondary' : 'ghost'} 
            size="sm"
            onClick={() => setPeriod('weekly')}
          >
            Weekly
          </Button>
          <Button 
            variant={period === 'monthly' ? 'secondary' : 'ghost'} 
            size="sm"
            onClick={() => setPeriod('monthly')}
          >
            Monthly
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="w-full h-[280px] flex items-center justify-center">
            <Skeleton className="h-[280px] w-full" />
          </div>
        ) : (
          <div className="h-[280px]">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart
                data={data}
                margin={{
                  top: 5,
                  right: 30,
                  left: 20,
                  bottom: 5,
                }}
              >
                <CartesianGrid strokeDasharray="3 3" opacity={0.2} />
                <XAxis 
                  dataKey="label" 
                  tick={{ fontSize: 12 }} 
                  tickLine={false}
                  axisLine={{ stroke: '#e2e8f0' }}
                />
                <YAxis 
                  tickFormatter={(value) => value >= 1000 ? `${(value / 1000).toFixed(0)}k` : value}
                  tick={{ fontSize: 12 }}
                  tickLine={false}
                  axisLine={{ stroke: '#e2e8f0' }}
                />
                <Tooltip 
                  formatter={(value: number) => formatTooltipValue(value)}
                  labelFormatter={(label) => `Date: ${label}`}
                  contentStyle={{ 
                    backgroundColor: 'white', 
                    border: '1px solid #e2e8f0',
                    borderRadius: '6px',
                    boxShadow: '0 1px 2px 0 rgba(0, 0, 0, 0.05)'
                  }}
                />
                <Legend wrapperStyle={{ paddingTop: '10px' }} />
                <Line 
                  type="monotone" 
                  dataKey="activeUsers" 
                  name="Active Users"
                  stroke="#5046e5" 
                  strokeWidth={2}
                  dot={false}
                  activeDot={{ r: 6, fill: '#5046e5' }}
                  animationDuration={500}
                />
                <Line 
                  type="monotone" 
                  dataKey="sessions" 
                  name="Sessions"
                  stroke="#2dd4bf" 
                  strokeWidth={2}
                  dot={false}
                  activeDot={{ r: 6, fill: '#2dd4bf' }}
                  animationDuration={700}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

function formatTooltipValue(value: number): string {
  return value >= 1000 ? `${(value / 1000).toFixed(1)}k` : value.toString();
}

export default EngagementChart;
