import React, { useState } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { 
  Download, 
  Plus, 
  Filter, 
  RefreshCw,
  ChevronDown
} from "lucide-react";
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import { getDateRange, DateRangeOption, DateRange } from "@/lib/dates";
import { DateRangePicker } from "@/components/ui/date-range-picker";
import { addDays, subDays, startOfMonth, endOfMonth } from "date-fns";

interface HeaderProps {
  title: string;
  description?: string;
  actionButton?: {
    label: string;
    href: string;
    icon?: React.ReactNode;
  };
  showDateRangePicker?: boolean;
  onDateRangeChange?: (range: DateRange) => void;
  showFilters?: boolean;
  onRefresh?: () => void;
}

export const Header: React.FC<HeaderProps> = ({ 
  title, 
  description, 
  actionButton,
  showDateRangePicker = true,
  onDateRangeChange,
  showFilters = true,
  onRefresh
}) => {
  const today = new Date();
  const [dateRange, setDateRange] = useState<{ from: Date; to: Date }>({
    from: subDays(today, 29),
    to: today
  });
  
  const handleDateRangeChange = (range: { from?: Date; to?: Date } | undefined) => {
    if (range?.from && range?.to) {
      setDateRange({ from: range.from, to: range.to });
      onDateRangeChange?.({
        start: range.from,
        end: range.to,
        label: `${range.from.toLocaleDateString()} - ${range.to.toLocaleDateString()}`
      });
    }
  };
  
  const presets = [
    {
      name: "last30days",
      label: "Last 30 days",
      value: {
        from: subDays(today, 29),
        to: today
      }
    },
    {
      name: "last7days",
      label: "Last 7 days",
      value: {
        from: subDays(today, 6),
        to: today
      }
    },
    {
      name: "thisMonth",
      label: "This month",
      value: {
        from: startOfMonth(today),
        to: today
      }
    }
  ];
  
  return (
    <header className="bg-white shadow-sm">
      <div className="flex justify-between items-center px-4 py-4 sm:px-6 lg:px-8 border-b border-gray-200">
        <div>
          <h1 className="text-2xl font-semibold text-gray-900">{title}</h1>
          {description && <p className="text-sm text-gray-500">{description}</p>}
        </div>
        <div className="flex space-x-4">
          <Button
            variant="outline"
            size="sm"
            className="flex items-center"
          >
            <Download className="mr-2 h-4 w-4" /> Export
          </Button>
          
          {actionButton && (
            <Button
              size="sm"
              className="flex items-center"
              asChild
            >
              <Link href={actionButton.href}>
                {actionButton.icon || <Plus className="mr-2 h-4 w-4" />} {actionButton.label}
              </Link>
            </Button>
          )}
        </div>
      </div>
      
      {(showDateRangePicker || showFilters) && (
        <div className="flex flex-wrap justify-between items-center px-4 py-3 sm:px-6 lg:px-8 bg-white border-b border-gray-200">
          <div className="flex items-center space-x-4">
            {showDateRangePicker && (
              <DateRangePicker
                value={dateRange}
                onChange={handleDateRangeChange}
                presets={presets}
              />
            )}
            
            {showFilters && (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" size="sm" className="flex items-center">
                    <Filter className="mr-2 h-4 w-4 text-gray-500" />
                    <span>Filters</span>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent>
                  <DropdownMenuItem>Device Type</DropdownMenuItem>
                  <DropdownMenuItem>Country</DropdownMenuItem>
                  <DropdownMenuItem>Platform</DropdownMenuItem>
                  <DropdownMenuItem>User Type</DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            )}
          </div>
          
          <div className="flex items-center mt-2 sm:mt-0">
            <Button 
              variant="ghost" 
              size="sm" 
              className="text-gray-700 hover:text-primary-600"
              onClick={onRefresh}
            >
              <RefreshCw className="mr-2 h-4 w-4" /> Refresh
            </Button>
          </div>
        </div>
      )}
    </header>
  );
};

export default Header;
