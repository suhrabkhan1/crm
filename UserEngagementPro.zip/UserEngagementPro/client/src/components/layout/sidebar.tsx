import React from "react";
import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import {
  BarChart3,
  Filter,
  Users,
  TrendingUp,
  Grid,
  GitBranch,
  Zap,
  Target,
  Clock,
  Megaphone,
  Route,
  Layers,
  Bell,
  Globe,
  Smartphone,
  Layout,
  Inbox,
  MessageSquare,
  Mail,
  MessageCircle,
  Code,
  Settings,
  UserCog,
  Puzzle,
  CreditCard
} from "lucide-react";

interface SidebarItemProps {
  href: string;
  icon: React.ReactNode;
  label: string;
  active?: boolean;
}

const SidebarItem: React.FC<SidebarItemProps> = ({ href, icon, label, active }) => {
  return (
    <li>
      <Link href={href} className={cn(
        "flex items-center px-2 py-2 text-sm rounded-md",
        active 
          ? "bg-primary-600 text-white font-medium" 
          : "text-gray-300 hover:bg-gray-700 font-normal"
      )}>
        <div className="w-5">
          {icon}
        </div>
        <span className="ml-2">{label}</span>
      </Link>
    </li>
  );
};

interface SidebarSectionProps {
  title: string;
  children: React.ReactNode;
}

const SidebarSection: React.FC<SidebarSectionProps> = ({ title, children }) => {
  return (
    <div className="px-4 mb-2">
      <p className="text-xs uppercase tracking-wider text-gray-400 mb-2">{title}</p>
      <ul className="space-y-1">
        {children}
      </ul>
    </div>
  );
};

export const Sidebar: React.FC = () => {
  const [location] = useLocation();
  
  return (
    <aside className="hidden md:flex flex-col w-64 bg-gray-800 text-white">
      <div className="p-4 border-b border-gray-700">
        <h1 className="text-xl font-semibold">EngageIQ</h1>
        <p className="text-xs text-gray-400">Customer Engagement Platform</p>
      </div>
      
      <nav className="flex-1 overflow-y-auto py-4">
        <SidebarSection title="Analytics">
          <SidebarItem 
            href="/dashboard" 
            icon={<BarChart3 className="h-4 w-4" />} 
            label="Dashboard" 
            active={location === "/dashboard" || location === "/"} 
          />
          <SidebarItem 
            href="/funnels" 
            icon={<Filter className="h-4 w-4" />} 
            label="Funnels" 
            active={location === "/funnels"} 
          />
          <SidebarItem 
            href="/cohorts" 
            icon={<Users className="h-4 w-4" />} 
            label="Cohorts" 
            active={location === "/cohorts"} 
          />
          <SidebarItem 
            href="/trends" 
            icon={<TrendingUp className="h-4 w-4" />} 
            label="Trends" 
            active={location === "/trends"} 
          />
          <SidebarItem 
            href="/pivots" 
            icon={<Grid className="h-4 w-4" />} 
            label="Pivots" 
            active={location === "/pivots"} 
          />
          <SidebarItem 
            href="/flows" 
            icon={<GitBranch className="h-4 w-4" />} 
            label="Flows" 
            active={location === "/flows"} 
          />
          <SidebarItem 
            href="/events" 
            icon={<Zap className="h-4 w-4" />} 
            label="Events" 
            active={location === "/events"} 
          />
          <SidebarItem 
            href="/real-impact" 
            icon={<Target className="h-4 w-4" />} 
            label="Real Impact" 
            active={location === "/real-impact"} 
          />
          <SidebarItem 
            href="/sessions" 
            icon={<Clock className="h-4 w-4" />} 
            label="Sessions" 
            active={location === "/sessions"} 
          />
        </SidebarSection>
        
        <SidebarSection title="Engagement">
          <SidebarItem 
            href="/campaigns" 
            icon={<Megaphone className="h-4 w-4" />} 
            label="Campaigns" 
            active={location.startsWith("/campaigns")} 
          />
          <SidebarItem 
            href="/journeys" 
            icon={<Route className="h-4 w-4" />} 
            label="Journeys" 
            active={location.startsWith("/journeys")} 
          />
          <SidebarItem 
            href="/segments" 
            icon={<Layers className="h-4 w-4" />} 
            label="Segments" 
            active={location.startsWith("/segments")} 
          />
        </SidebarSection>
        
        <SidebarSection title="Channels">
          <SidebarItem 
            href="/push" 
            icon={<Bell className="h-4 w-4" />} 
            label="Push Notifications" 
            active={location === "/push"} 
          />
          <SidebarItem 
            href="/web-push" 
            icon={<Globe className="h-4 w-4" />} 
            label="Web Push" 
            active={location === "/web-push"} 
          />
          <SidebarItem 
            href="/in-app" 
            icon={<Smartphone className="h-4 w-4" />} 
            label="In-App" 
            active={location === "/in-app"} 
          />
          <SidebarItem 
            href="/web-popup" 
            icon={<Layout className="h-4 w-4" />} 
            label="Web Pop-up" 
            active={location === "/web-popup"} 
          />
          <SidebarItem 
            href="/app-inbox" 
            icon={<Inbox className="h-4 w-4" />} 
            label="App Inbox" 
            active={location === "/app-inbox"} 
          />
          <SidebarItem 
            href="/sms" 
            icon={<MessageSquare className="h-4 w-4" />} 
            label="SMS" 
            active={location === "/sms"} 
          />
          <SidebarItem 
            href="/email" 
            icon={<Mail className="h-4 w-4" />} 
            label="Email" 
            active={location === "/email"} 
          />
          <SidebarItem 
            href="/whatsapp" 
            icon={<MessageCircle className="h-4 w-4" />} 
            label="WhatsApp" 
            active={location === "/whatsapp"} 
          />
          <SidebarItem 
            href="/webhooks" 
            icon={<Code className="h-4 w-4" />} 
            label="Webhooks" 
            active={location === "/webhooks"} 
          />
        </SidebarSection>
        
        <SidebarSection title="Management">
          <SidebarItem 
            href="/settings" 
            icon={<Settings className="h-4 w-4" />} 
            label="Settings" 
            active={location === "/settings"} 
          />
          <SidebarItem 
            href="/users" 
            icon={<UserCog className="h-4 w-4" />} 
            label="Users & Teams" 
            active={location === "/users"} 
          />
          <SidebarItem 
            href="/add-ons" 
            icon={<Puzzle className="h-4 w-4" />} 
            label="Add-ons" 
            active={location === "/add-ons"} 
          />
          <SidebarItem 
            href="/billing" 
            icon={<CreditCard className="h-4 w-4" />} 
            label="Billing" 
            active={location === "/billing"} 
          />
        </SidebarSection>
      </nav>
      
      <div className="p-4 border-t border-gray-700">
        <div className="flex items-center">
          <div className="flex-shrink-0">
            <img 
              className="h-8 w-8 rounded-full" 
              src="https://ui-avatars.com/api/?name=Alex+Morgan&background=5046e5&color=fff" 
              alt="User avatar" 
            />
          </div>
          <div className="ml-3">
            <p className="text-sm font-medium text-white">Alex Morgan</p>
            <p className="text-xs text-gray-400">Administrator</p>
          </div>
        </div>
      </div>
    </aside>
  );
};

export default Sidebar;
