import React, { useState } from "react";
import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import {
  BarChart3,
  Filter,
  Users,
  TrendingUp,
  Grid,
  GitBranch,
  Zap,
  Target,
  Clock,
  Megaphone,
  Route,
  Layers,
  Bell,
  Globe,
  Smartphone,
  Layout,
  Inbox,
  MessageSquare,
  Mail,
  MessageCircle,
  Code,
  Settings,
  UserCog,
  Puzzle,
  CreditCard,
  Menu
} from "lucide-react";
import { Button } from "@/components/ui/button";

interface MobileSidebarItemProps {
  href: string;
  icon: React.ReactNode;
  label: string;
  active?: boolean;
  onClick: () => void;
}

const MobileSidebarItem: React.FC<MobileSidebarItemProps> = ({ href, icon, label, active, onClick }) => {
  return (
    <li>
      <Link href={href}>
        <a 
          className={cn(
            "flex items-center px-2 py-2 text-sm rounded-md",
            active 
              ? "bg-primary-600 text-white font-medium" 
              : "text-gray-700 hover:bg-gray-100 font-normal"
          )}
          onClick={onClick}
        >
          <div className="w-5">
            {icon}
          </div>
          <span className="ml-2">{label}</span>
        </a>
      </Link>
    </li>
  );
};

interface MobileSidebarSectionProps {
  title: string;
  children: React.ReactNode;
}

const MobileSidebarSection: React.FC<MobileSidebarSectionProps> = ({ title, children }) => {
  return (
    <div className="px-4 mb-2">
      <p className="text-xs uppercase tracking-wider text-gray-500 mb-2">{title}</p>
      <ul className="space-y-1">
        {children}
      </ul>
    </div>
  );
};

export const MobileSidebar: React.FC = () => {
  const [location] = useLocation();
  const [open, setOpen] = useState(false);
  
  const handleItemClick = () => {
    setOpen(false);
  };
  
  return (
    <div className="md:hidden fixed bottom-4 right-4 z-50">
      <Sheet open={open} onOpenChange={setOpen}>
        <SheetTrigger asChild>
          <Button className="flex items-center justify-center w-12 h-12 rounded-full bg-primary-600 text-white shadow-lg hover:bg-primary-700">
            <Menu />
          </Button>
        </SheetTrigger>
        <SheetContent side="left" className="w-80 p-0 bg-white">
          <div className="flex flex-col h-full">
            <div className="p-4 border-b border-gray-200">
              <h1 className="text-xl font-semibold text-gray-900">EngageIQ</h1>
              <p className="text-xs text-gray-500">Customer Engagement Platform</p>
            </div>
            
            <div className="flex-1 overflow-y-auto py-4">
              <MobileSidebarSection title="Analytics">
                <MobileSidebarItem 
                  href="/dashboard" 
                  icon={<BarChart3 className="h-4 w-4" />} 
                  label="Dashboard" 
                  active={location === "/dashboard" || location === "/"} 
                  onClick={handleItemClick}
                />
                <MobileSidebarItem 
                  href="/funnels" 
                  icon={<Filter className="h-4 w-4" />} 
                  label="Funnels" 
                  active={location === "/funnels"} 
                  onClick={handleItemClick}
                />
                <MobileSidebarItem 
                  href="/cohorts" 
                  icon={<Users className="h-4 w-4" />} 
                  label="Cohorts" 
                  active={location === "/cohorts"} 
                  onClick={handleItemClick}
                />
                <MobileSidebarItem 
                  href="/trends" 
                  icon={<TrendingUp className="h-4 w-4" />} 
                  label="Trends" 
                  active={location === "/trends"} 
                  onClick={handleItemClick}
                />
                <MobileSidebarItem 
                  href="/pivots" 
                  icon={<Grid className="h-4 w-4" />} 
                  label="Pivots" 
                  active={location === "/pivots"} 
                  onClick={handleItemClick}
                />
                <MobileSidebarItem 
                  href="/flows" 
                  icon={<GitBranch className="h-4 w-4" />} 
                  label="Flows" 
                  active={location === "/flows"} 
                  onClick={handleItemClick}
                />
                <MobileSidebarItem 
                  href="/events" 
                  icon={<Zap className="h-4 w-4" />} 
                  label="Events" 
                  active={location === "/events"} 
                  onClick={handleItemClick}
                />
                <MobileSidebarItem 
                  href="/real-impact" 
                  icon={<Target className="h-4 w-4" />} 
                  label="Real Impact" 
                  active={location === "/real-impact"} 
                  onClick={handleItemClick}
                />
                <MobileSidebarItem 
                  href="/sessions" 
                  icon={<Clock className="h-4 w-4" />} 
                  label="Sessions" 
                  active={location === "/sessions"} 
                  onClick={handleItemClick}
                />
              </MobileSidebarSection>
              
              <MobileSidebarSection title="Engagement">
                <MobileSidebarItem 
                  href="/campaigns" 
                  icon={<Megaphone className="h-4 w-4" />} 
                  label="Campaigns" 
                  active={location.startsWith("/campaigns")} 
                  onClick={handleItemClick}
                />
                <MobileSidebarItem 
                  href="/journeys" 
                  icon={<Route className="h-4 w-4" />} 
                  label="Journeys" 
                  active={location.startsWith("/journeys")} 
                  onClick={handleItemClick}
                />
                <MobileSidebarItem 
                  href="/segments" 
                  icon={<Layers className="h-4 w-4" />} 
                  label="Segments" 
                  active={location.startsWith("/segments")} 
                  onClick={handleItemClick}
                />
              </MobileSidebarSection>
              
              <MobileSidebarSection title="Channels">
                <MobileSidebarItem 
                  href="/push" 
                  icon={<Bell className="h-4 w-4" />} 
                  label="Push Notifications" 
                  active={location === "/push"} 
                  onClick={handleItemClick}
                />
                <MobileSidebarItem 
                  href="/web-push" 
                  icon={<Globe className="h-4 w-4" />} 
                  label="Web Push" 
                  active={location === "/web-push"} 
                  onClick={handleItemClick}
                />
                <MobileSidebarItem 
                  href="/in-app" 
                  icon={<Smartphone className="h-4 w-4" />} 
                  label="In-App" 
                  active={location === "/in-app"} 
                  onClick={handleItemClick}
                />
                <MobileSidebarItem 
                  href="/web-popup" 
                  icon={<Layout className="h-4 w-4" />} 
                  label="Web Pop-up" 
                  active={location === "/web-popup"} 
                  onClick={handleItemClick}
                />
                <MobileSidebarItem 
                  href="/app-inbox" 
                  icon={<Inbox className="h-4 w-4" />} 
                  label="App Inbox" 
                  active={location === "/app-inbox"} 
                  onClick={handleItemClick}
                />
                <MobileSidebarItem 
                  href="/sms" 
                  icon={<MessageSquare className="h-4 w-4" />} 
                  label="SMS" 
                  active={location === "/sms"} 
                  onClick={handleItemClick}
                />
                <MobileSidebarItem 
                  href="/email" 
                  icon={<Mail className="h-4 w-4" />} 
                  label="Email" 
                  active={location === "/email"} 
                  onClick={handleItemClick}
                />
                <MobileSidebarItem 
                  href="/whatsapp" 
                  icon={<MessageCircle className="h-4 w-4" />} 
                  label="WhatsApp" 
                  active={location === "/whatsapp"} 
                  onClick={handleItemClick}
                />
                <MobileSidebarItem 
                  href="/webhooks" 
                  icon={<Code className="h-4 w-4" />} 
                  label="Webhooks" 
                  active={location === "/webhooks"} 
                  onClick={handleItemClick}
                />
              </MobileSidebarSection>
              
              <MobileSidebarSection title="Management">
                <MobileSidebarItem 
                  href="/settings" 
                  icon={<Settings className="h-4 w-4" />} 
                  label="Settings" 
                  active={location === "/settings"} 
                  onClick={handleItemClick}
                />
                <MobileSidebarItem 
                  href="/users" 
                  icon={<UserCog className="h-4 w-4" />} 
                  label="Users & Teams" 
                  active={location === "/users"} 
                  onClick={handleItemClick}
                />
                <MobileSidebarItem 
                  href="/add-ons" 
                  icon={<Puzzle className="h-4 w-4" />} 
                  label="Add-ons" 
                  active={location === "/add-ons"} 
                  onClick={handleItemClick}
                />
                <MobileSidebarItem 
                  href="/billing" 
                  icon={<CreditCard className="h-4 w-4" />} 
                  label="Billing" 
                  active={location === "/billing"} 
                  onClick={handleItemClick}
                />
              </MobileSidebarSection>
            </div>
            
            <div className="p-4 border-t border-gray-200">
              <div className="flex items-center">
                <div className="flex-shrink-0">
                  <img 
                    className="h-8 w-8 rounded-full" 
                    src="https://ui-avatars.com/api/?name=Alex+Morgan&background=5046e5&color=fff" 
                    alt="User avatar" 
                  />
                </div>
                <div className="ml-3">
                  <p className="text-sm font-medium text-gray-900">Alex Morgan</p>
                  <p className="text-xs text-gray-500">Administrator</p>
                </div>
              </div>
            </div>
          </div>
        </SheetContent>
      </Sheet>
    </div>
  );
};

export default MobileSidebar;
