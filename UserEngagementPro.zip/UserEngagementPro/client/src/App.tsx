import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import Dashboard from "@/pages/dashboard";
import Funnels from "@/pages/funnels";
import CreateFunnel from "@/pages/funnels/create";
import Cohorts from "@/pages/cohorts";
import Trends from "@/pages/trends";
import Pivots from "@/pages/pivots";
import Flows from "@/pages/flows";
import Events from "@/pages/events";
import RealImpact from "@/pages/real-impact";
import Sessions from "@/pages/sessions";
import Campaigns from "@/pages/campaigns/index";
import CreateCampaign from "@/pages/campaigns/create";
import Journeys from "@/pages/journeys/index";
import CreateJourney from "@/pages/journeys/create";
import Segments from "@/pages/segments/index";
import CreateSegment from "@/pages/segments/create";
import Push from "@/pages/channels/push";
import WebPush from "@/pages/channels/web-push";
import InApp from "@/pages/channels/in-app";
import WebPopup from "@/pages/channels/web-popup";
import AppInbox from "@/pages/channels/app-inbox";
import SMS from "@/pages/channels/sms";
import Email from "@/pages/channels/email";
import WhatsApp from "@/pages/channels/whatsapp";
import Webhooks from "@/pages/channels/webhooks";
import Settings from "@/pages/settings/index";
import Users from "@/pages/settings/users";
import AddOns from "@/pages/settings/add-ons";
import Billing from "@/pages/settings/billing";

function Router() {
  return (
    <Switch>
      {/* Dashboard and Analytics */}
      <Route path="/" component={Dashboard} />
      <Route path="/dashboard" component={Dashboard} />
      <Route path="/funnels" component={Funnels} />
      <Route path="/funnels/create" component={CreateFunnel} />
      <Route path="/cohorts" component={Cohorts} />
      <Route path="/trends" component={Trends} />
      <Route path="/pivots" component={Pivots} />
      <Route path="/flows" component={Flows} />
      <Route path="/events" component={Events} />
      <Route path="/real-impact" component={RealImpact} />
      <Route path="/sessions" component={Sessions} />
      
      {/* Engagement */}
      <Route path="/campaigns" component={Campaigns} />
      <Route path="/campaigns/create" component={CreateCampaign} />
      <Route path="/journeys" component={Journeys} />
      <Route path="/journeys/create" component={CreateJourney} />
      <Route path="/segments" component={Segments} />
      <Route path="/segments/create" component={CreateSegment} />
      
      {/* Channels */}
      <Route path="/push" component={Push} />
      <Route path="/web-push" component={WebPush} />
      <Route path="/in-app" component={InApp} />
      <Route path="/web-popup" component={WebPopup} />
      <Route path="/app-inbox" component={AppInbox} />
      <Route path="/sms" component={SMS} />
      <Route path="/email" component={Email} />
      <Route path="/whatsapp" component={WhatsApp} />
      <Route path="/webhooks" component={Webhooks} />
      
      {/* Management */}
      <Route path="/settings" component={Settings} />
      <Route path="/users" component={Users} />
      <Route path="/add-ons" component={AddOns} />
      <Route path="/billing" component={Billing} />
      
      {/* Fallback to 404 */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
